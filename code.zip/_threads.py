"""Import this module first: fixes the number of BLAS/OpenMP threads to one.

Some samplers contain tie-breaking steps (duplicate points) whose outcome can depend on the
order of floating-point summation inside multi-threaded BLAS calls; with one thread every run
is bit-reproducible on the same software stack."""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
