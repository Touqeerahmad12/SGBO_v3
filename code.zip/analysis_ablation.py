"""
Real-data component ablation (results/ablation.csv) -> results/ablation_summary.json

Unit = independent source (as in the main benchmark).  For every variant the paired difference to the
full SGBO is reported (variant - SGBO; negative = removing the component hurts) for MCC, AUC-PR, F1 and
G-mean, with a cluster-bootstrap 95% interval, win/loss counts and a Holm-adjusted Wilcoxon p-value over
the 11 comparisons.  The same is done within regimes (high dimension, high imbalance, label noise ...).
"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.stats import unit_matrix, paired_summary, holm
from sgbo.datasets import task_registry
from sgbo.protocol import RES
from sgbo.variants import ORDER

ab = pd.read_csv(os.path.join(RES, "ablation.csv"), keep_default_na=False, na_values=[""])
reg = {t["name"]: t for t in task_registry()}
info = {n: dict(d=t["X"].shape[1], ir=float((t["y"] == 0).sum() / t["y"].sum()), n=len(t["y"]), n_pos=int(t["y"].sum()),
                syn=t["kind"] == "synthetic") for n, t in reg.items()}
REGIMES = {
    "all": lambda i: True,
    "d >= 20": lambda i: i["d"] >= 20,
    "d < 20": lambda i: i["d"] < 20,
    "IR >= 10": lambda i: i["ir"] >= 10,
    "IR < 10": lambda i: i["ir"] < 10,
    "n+ < 50": lambda i: i["n_pos"] < 50,
    "n >= 3000": lambda i: i["n"] >= 3000,
    "real data": lambda i: not i["syn"],
    "synthetic data": lambda i: i["syn"],
}
out = {"regimes": {}, "info": {k: v for k, v in info.items()}}
others = [v for v in ORDER if v != "SGBO"]
for rname, f in REGIMES.items():
    names = [n for n, i in info.items() if f(i)]
    out["regimes"][rname] = {"n_tasks": len(names)}
    for met in ["mcc", "aucpr", "f1", "gmean"]:
        M = unit_matrix(ab, met, methods=ORDER, datasets=names)
        ps = paired_summary(M, "SGBO", others)
        padj = holm([ps[v]["p"] for v in others])
        for v, pa in zip(others, padj):
            ps[v]["p_holm"] = float(pa)
        out["regimes"][rname][met] = dict(N=len(M), full=float(M["SGBO"].mean()), v=ps)
    print(rname, out["regimes"][rname]["n_tasks"], "tasks;", out["regimes"][rname]["mcc"]["N"], "sources")
# runtime and acceptance statistics of the variants (RF rows)
rt = ab[ab.clf == "RF"].groupby("method")[["t_resample"]].mean()
out["t_resample"] = rt["t_resample"].to_dict()
json.dump(out, open(os.path.join(RES, "ablation_summary.json"), "w"), indent=1, default=float)
for met in ["mcc", "aucpr"]:
    print("\n", met, "all tasks")
    r = out["regimes"]["all"][met]
    for v in ORDER[1:]:
        s = r["v"][v]
        print(f"  {v:34s} {s['mean']:+.4f} [{s['lo']:+.4f},{s['hi']:+.4f}] W/L {s['wins']}/{s['losses']} pH={s['p_holm']:.3f}")
