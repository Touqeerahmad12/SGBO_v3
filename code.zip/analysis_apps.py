"""Application panel (retrospective benchmark performance) from results/benchmark.csv -> results/apps_summary.json"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES
from sgbo.datasets import task_registry

APPS = [("bcancer", "Breast cancer Wisconsin (diagnostic): malignant vs benign, natural prevalence"),
        ("bcancer-ir10", "same, malignant subsampled to IR 10 (screening-like prevalence scenario)"),
        ("bcancer-ir20", "same, IR 20"),
        ("mammography", "Mammography: microcalcification vs none"),
        ("pima", "Pima: diabetes diagnosis"),
        ("haberman", "Haberman: death within 5 years after breast-cancer surgery"),
        ("new-thyroid1", "New-thyroid: hyperthyroidism vs rest"),
        ("diabetes-top20", "Diabetes progression (regression target thresholded at the 80th percentile)"),
        ("diabetes-top10", "same, 90th percentile"),
        ("diabetes-top5", "same, 95th percentile")]
METHODS = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
df = pd.read_csv(os.path.join(RES, "benchmark.csv"), keep_default_na=False, na_values=[""])
reg = {t["name"]: t for t in task_registry()}
names = [a for a, _ in APPS]
d = df[df.dataset.isin(names)].copy()
n_te = d.tp + d.fp + d.fn + d.tn
for c in (1, 5, 10, 20):
    d[f"cost{c}"] = (c * d.fn + d.fp) / n_te
d["ppv_hat"] = d.prec
cols = ["tpr", "tnr", "prec", "fpr", "f1", "mcc", "aucpr", "auc", "gmean", "cost1", "cost5", "cost10", "cost20"]
out = dict(apps={a: dict(desc=ds, n=len(reg[a]["y"]), d=int(reg[a]["X"].shape[1]), n_pos=int(reg[a]["y"].sum()),
                         ir=float((reg[a]["y"] == 0).sum() / reg[a]["y"].sum())) for a, ds in APPS})
# mean over folds, repetitions, classifiers (pooled) and for RF only
for tag, dd in (("pooled", d), ("RF", d[d.clf == "RF"]), ("kNN", d[d.clf == "kNN"])):
    g = dd.groupby(["dataset", "method"])[cols].mean()
    out[tag] = {a: {m: g.loc[(a, m)].to_dict() for m in METHODS} for a in names}
# SGBO against None / BDO / SMOTE: operating-point shifts, pooled
sh = {}
for ref in ("None", "BDO", "SMOTE"):
    sh[ref] = {a: {c: float(out["pooled"][a]["SGBO"][c] - out["pooled"][a][ref][c]) for c in ("tpr", "tnr", "prec", "fpr", "f1", "mcc", "aucpr", "cost5")} for a in names}
out["shift"] = sh
# best method per application and cost ratio (lowest mean cost), pooled
best = {}
for c in (1, 5, 10, 20):
    best[c] = {a: min(METHODS, key=lambda m: out["pooled"][a][m][f"cost{c}"]) for a in names}
out["best_cost"] = best
# average over the applications (unweighted)
out["avg"] = {m: {c: float(np.mean([out["pooled"][a][m][c] for a in names])) for c in cols} for m in METHODS}
# fold-level spread for SGBO and None (descriptive only)
sd = d.groupby(["dataset", "method"])[["tpr", "tnr", "mcc"]].std()
out["fold_sd"] = {a: {m: sd.loc[(a, m)].to_dict() for m in ("None", "BDO", "SGBO")} for a in names}
json.dump(out, open(os.path.join(RES, "apps_summary.json"), "w"), indent=1, default=float)
pd.set_option("display.width", 200)
print(pd.DataFrame(out["avg"]).T[["tpr", "tnr", "prec", "fpr", "f1", "mcc", "aucpr", "cost5"]].round(3))
