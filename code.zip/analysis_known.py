"""
Summaries of the mechanism-level studies of run_known.py -> results/known_summary.json
  consistency   accuracy of the boundary score vs n (mean, SE, log-log slope with bootstrap interval)
  quality       sample quality against the true model, per sampler and condition
  ablation      components under designed conditions: paired differences to the full method over seeds
  shrink        covariance conditioning and performance vs dimension
  langevin      effect of the Langevin temperature in repeated runs
"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES
from sgbo.stats import holm

OUT = {}
rd = lambda f: pd.read_csv(os.path.join(RES, f), keep_default_na=False, na_values=[""])


def slope(x, y, B=2000, seed=0, groups=None):
    """log-log OLS slope of y on x with a bootstrap interval over replications (rows of `groups`)."""
    lx = np.log(x)
    b = np.polyfit(lx, np.log(y), 1)[0]
    return float(b)


def consistency():
    d = rd("known_consistency.csv")
    out = {}
    for q in sorted(d.q.unique()):
        for met in ["mae_b", "mae_eta", "prec10", "rho_b", "bias_eta"]:
            g = d[d.q == q].groupby(["rule", "n"])[met].agg(["mean", "std", "count"]).reset_index()
            g["se"] = g["std"] / np.sqrt(g["count"])
            out[f"q{q}_{met}"] = {r: dict(n=sub.n.tolist(), mean=sub["mean"].tolist(), se=sub["se"].tolist()) for r, sub in g.groupby("rule")}
        # log-log slope of the MAE of b on n, bootstrap over replications
        rng = np.random.default_rng(0); sl = {}
        for r, sub in d[d.q == q].groupby("rule"):
            piv = sub.pivot_table(index="rep", columns="n", values="mae_b")
            ns = np.array(piv.columns, float)
            bs = []
            for _ in range(1000):
                idx = rng.integers(0, len(piv), len(piv)); bs.append(np.polyfit(np.log(ns), np.log(piv.values[idx].mean(0)), 1)[0])
            sl[r] = dict(slope=float(np.polyfit(np.log(ns), np.log(piv.values.mean(0)), 1)[0]), lo=float(np.quantile(bs, .025)), hi=float(np.quantile(bs, .975)))
        out[f"q{q}_slope_mae_b"] = sl
        # paired comparison at the largest n between rules
        big = d[(d.q == q) & (d.n == d.n.max())].pivot_table(index="rep", columns="rule", values="mae_b")
        out[f"q{q}_paired_largest_n"] = {r: dict(diff=float((big[r] - big["SGBO (k=sqrt(n), weighted)"]).mean()),
                                                p=float(stats.wilcoxon(big[r], big["SGBO (k=sqrt(n), weighted)"]).pvalue))
                                         for r in big.columns if r != "SGBO (k=sqrt(n), weighted)"}
    OUT["consistency"] = out


def quality():
    d = rd("known_quality.csv")
    cols = ["mean_eta", "deep", "offsupp", "logp1_diff", "between", "c1_share", "in_band", "mmd_true", "prec_true", "rec_true", "bnd_cov", "below_half"]
    g = d.groupby(["tag", "variant"])[cols].mean()
    OUT["quality"] = {t: {v: g.loc[(t, v)].to_dict() for v in g.loc[t].index} for t in g.index.get_level_values(0).unique()}
    ov = d.groupby("variant")[cols].mean()
    OUT["quality_overall"] = ov.to_dict("index")
    # SGBO share of rejected candidates and unfinished chains
    s = d[d.variant == "SGBO"]
    OUT["quality_sgbo_diag"] = {c: s.groupby("tag")[c].mean().to_dict() for c in ["rej_share", "unfinished", "fill_share"] if c in s}


def ablation():
    d = rd("known_ablation.csv")
    out = {}
    for met in ["mcc", "aucpr", "f1", "gmean"]:
        t = d.groupby(["tag", "seed", "variant"])[met].mean().unstack("variant")       # mean over classifiers
        res = {}
        for tag, sub in t.groupby(level=0):
            r = {}
            for v in [c for c in t.columns if c != "SGBO"]:
                diff = (sub[v] - sub["SGBO"]).values
                se = diff.std(ddof=1) / np.sqrt(len(diff))
                p = stats.wilcoxon(diff).pvalue if np.any(np.abs(diff) > 1e-12) else 1.0
                r[v] = dict(mean=float(diff.mean()), se=float(se), p=float(p), full=float(sub["SGBO"].mean()))
            padj = holm([r[v]["p"] for v in r])
            for v, pa in zip(r, padj):
                r[v]["p_holm"] = float(pa)
            res[tag] = r
        out[met] = res
    mech = ["mean_eta", "deep", "offsupp", "logp1_diff", "between", "mmd_true", "prec_true", "rec_true", "bnd_cov", "rej_share", "unfinished", "spread_new", "in_band"]
    m = d[d.clf == "RF"].groupby(["tag", "variant"])[[c for c in mech if c in d]].mean()
    OUT["ablation_mech"] = {t: {v: m.loc[(t, v)].to_dict() for v in m.loc[t].index} for t in m.index.get_level_values(0).unique()}
    OUT["ablation"] = out


def shrink():
    d = rd("known_shrink.csv")
    d["dim"] = d["q"] + 2
    cols = ["cond_med", "cond_p95", "cond_gt1e8", "rankdef_frac", "rho_mean", "offsupp", "deep", "mmd_true", "prec_true", "rec_true", "rej_share",
            "mean_eta", "logp1_diff", "spread_new", "fill_share"]
    g = d[d.clf == "RF"].groupby(["dim", "variant"])[[c for c in cols if c in d]].median()
    gm = d[d.clf == "RF"].groupby(["dim", "variant"])[[c for c in cols if c in d]].mean()
    OUT["shrink_median"] = {int(k): {v: g.loc[(k, v)].to_dict() for v in g.loc[k].index} for k in g.index.get_level_values(0).unique()}
    OUT["shrink_mean"] = {int(k): {v: gm.loc[(k, v)].to_dict() for v in gm.loc[k].index} for k in gm.index.get_level_values(0).unique()}
    perf = {}
    for met in ["mcc", "aucpr"]:
        t = d.groupby(["dim", "seed", "variant"])[met].mean().unstack("variant")
        r = {}
        for k, sub in t.groupby(level=0):
            r[int(k)] = {v: dict(mean=float(sub[v].mean()), se=float(sub[v].std(ddof=1) / np.sqrt(len(sub)))) for v in sub.columns}
            for v in sub.columns:
                if v != "LW + floor (default)":
                    diff = (sub[v] - sub["LW + floor (default)"]).values
                    r[int(k)][v]["diff_vs_default"] = float(diff.mean())
                    r[int(k)][v]["p_vs_default"] = float(stats.wilcoxon(diff).pvalue) if np.any(np.abs(diff) > 1e-12) else 1.0
        perf[met] = r
    OUT["shrink_perf"] = perf


def langevin():
    d = rd("langevin_runs.csv")
    out = {}
    cols = ["div_nn", "cover_real", "bnd_cov", "prec", "rec", "unfinished"]
    g = d[d.clf == "RF"].groupby(["dataset", "fold", "tau"])[cols].mean().groupby(["dataset", "tau"]).mean()
    out["by_tau"] = {c: g[c].groupby("tau").mean().to_dict() for c in cols}
    # classification: average over runs first (per dataset-fold), then over folds -> unit = dataset
    for met in ["aucpr", "mcc", "f1", "gmean"]:
        u = d.groupby(["dataset", "fold", "tau", "clf"])[met].mean().groupby(["dataset", "tau"]).mean().unstack("tau")
        row = {"mean": u.mean().to_dict()}
        for tau in [t for t in u.columns if t != 0.0]:
            diff = (u[tau] - u[0.0]).values
            row[f"diff_{tau}"] = dict(mean=float(diff.mean()), wins=int((diff > 1e-12).sum()), losses=int((diff < -1e-12).sum()),
                                      p=float(stats.wilcoxon(diff).pvalue) if np.any(np.abs(diff) > 1e-12) else 1.0)
        # run-to-run standard deviation of the metric (same training set, different random streams)
        sd = d.groupby(["dataset", "fold", "tau", "clf"])[met].std(ddof=1).groupby(["dataset", "tau"]).mean().unstack("tau")
        row["run_sd"] = sd.mean().to_dict()
        out[met] = row
    # paired differences of diversity / coverage metrics over datasets
    pd_ = {}
    for c in ["div_nn", "cover_real", "bnd_cov", "rec", "prec"]:
        u = d[d.clf == "RF"].groupby(["dataset", "fold", "tau"])[c].mean().groupby(["dataset", "tau"]).mean().unstack("tau")
        pd_[c] = {"mean": u.mean().to_dict(), **{f"diff_{t}": dict(mean=float((u[t] - u[0.0]).mean()), p=float(stats.wilcoxon((u[t] - u[0.0]).dropna()).pvalue),
                                                                  wins=int(((u[t] - u[0.0]) > 1e-12).sum()), n=int(u[t].notna().sum())) for t in u.columns if t != 0.0}}
    out["paired_struct"] = pd_
    OUT["langevin"] = out


if __name__ == "__main__":
    which = sys.argv[1:] or ["consistency", "quality", "ablation", "shrink", "langevin"]
    for w in which:
        if os.path.exists(os.path.join(RES, {"consistency": "known_consistency.csv", "quality": "known_quality.csv", "ablation": "known_ablation.csv",
                                             "shrink": "known_shrink.csv", "langevin": "langevin_runs.csv"}[w])):
            globals()[w](); print(w, "ok")
    p = os.path.join(RES, "known_summary.json")
    old = json.load(open(p)) if os.path.exists(p) else {}
    old.update(OUT); json.dump(old, open(p, "w"), indent=1, default=float)
