"""
Statistics of the main benchmark (results/benchmark.csv) -> results/stats_main.json, results/extra_main.json,
results/reproduction.json.

  stats_main.json    Friedman / Iman-Davenport / Nemenyi / Holm-Wilcoxon for 5 metrics, pooled and per classifier,
                     for all sources, for the primary task of each source, and for the 26 sources of the
                     previous version (robustness of the conclusions to the added sources)
  extra_main.json    real-only / synthetic-only comparisons, task-level counts, sensitivity / specificity, timing
  reproduction.json  comparison with the archived results of the previous version (identical rows, differences)
"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.stats import unit_matrix, friedman, posthoc, METHODS, METRICS, CLFS
from sgbo.datasets import task_registry
from sgbo.protocol import RES

NEW_SOURCES = {"Mammography", "Oil spill"}


def load(path=None):
    return pd.read_csv(path or os.path.join(RES, "benchmark.csv"), keep_default_na=False, na_values=[""])


def analyse(df, datasets=None, sources=None):
    out = {}
    for met in METRICS:
        M = unit_matrix(df, met, datasets=datasets)
        if sources is not None:
            M = M.loc[[s for s in M.index if s in sources]]
        fr = friedman(M); fr["posthoc"] = posthoc(M); fr["mean"] = M.mean().to_dict(); fr["std"] = M.std().to_dict()
        out[met] = fr
        for c in CLFS:
            Mc = unit_matrix(df, met, clf=c, datasets=datasets)
            if sources is not None:
                Mc = Mc.loc[[s for s in Mc.index if s in sources]]
            frc = friedman(Mc); frc["posthoc"] = posthoc(Mc); frc["mean"] = Mc.mean().to_dict()
            out[f"{met}_{c}"] = frc
    return out


def main():
    df = load()
    reg = task_registry()
    prim = [t["name"] for t in reg if t["primary"]]
    kind = {t["source"]: t["kind"] for t in reg}
    old_sources = {s for s in kind if s not in NEW_SOURCES}
    stats = dict(all_tasks=analyse(df), primary_only=analyse(df, datasets=prim), previous_26_sources=analyse(df, sources=old_sources))
    json.dump(stats, open(os.path.join(RES, "stats_main.json"), "w"), indent=1, default=float)
    full = stats["all_tasks"]
    ex = {}
    real_src = [s for s, k in kind.items() if not k.startswith("synthetic")]
    syn_src = [s for s, k in kind.items() if k.startswith("synthetic")]
    ex["n_sources"], ex["n_real_src"], ex["n_syn_src"], ex["n_tasks"] = len(kind), len(real_src), len(syn_src), len(reg)
    for met in METRICS:
        M = unit_matrix(df, met)
        for tag, srcs in (("real", real_src), ("synthetic", syn_src)):
            Ms = M.loc[[s for s in srcs if s in M.index]]
            fr = friedman(Ms); ph = posthoc(Ms) if tag == "real" else {}
            ex[f"{tag}_{met}"] = dict(N=fr["N"], ranks=fr["ranks"], mean=Ms.mean().to_dict(), p_FF=fr["p_FF"],
                                      posthoc={k: dict(mean=v["mean"], ci=[v["ci_lo"], v["ci_hi"]], wins=v["wins"], losses=v["losses"],
                                                       p_holm=v["p_holm"], r_rb=v["r_rb"]) for k, v in ph.items()})
    for met in ["aucpr", "mcc", "f1", "gmean"]:
        t = df.groupby(["dataset", "clf", "method"])[met].mean().groupby(["dataset", "method"]).mean().unstack()[METHODS]
        ex[f"best_{met}"] = t.idxmax(axis=1).value_counts().to_dict()
        ex[f"top3_{met}"] = (t.rank(axis=1, ascending=False) <= 3).sum().to_dict()
        for other, key in (("BDO", "bdo"), ("SMOTE", "smote"), ("SVM-SMOTE", "svmsm"), ("None", "none")):
            ex[f"sgbo_ge_{key}_{met}"] = int((t["SGBO"] >= t[other]).sum())
    for met in ["tpr", "tnr", "prec", "fpr"]:
        ex[f"mean_{met}"] = unit_matrix(df, met).mean().to_dict()
    ex["sgbo_avg_rank4"] = float(np.mean([full[m]["ranks"]["SGBO"] for m in ["aucpr", "mcc", "f1", "gmean"]]))
    M = unit_matrix(df, "mcc"); ex["mcc_spread_excl_none"] = float(M.drop(columns="None").mean().max() - M.drop(columns="None").mean().min())
    ex["t_resample"] = df[df.clf == "RF"].groupby("method")["t_resample"].mean().to_dict()
    ex["t_fit"] = df[df.clf == "RF"].groupby("method")["t_fit"].mean().to_dict()
    ex["n_rows"] = len(df)
    # SGBO exceptional-event counts over all SGBO resampling calls (one RF row per call)
    s = df[(df.method == "SGBO") & (df.clf == "RF")]
    ex["sgbo_calls"] = len(s)
    for c in [c for c in s.columns if c.startswith("diag_")]:
        ex[c] = dict(sum=float(s[c].sum()), calls_with=int((s[c] > 0).sum()))
    ex["rej_share_mean"] = float((1 - s["diag_n_acc"] / s["diag_n_cand"].clip(lower=1)).mean())
    ex["unfinished_share_mean"] = float((s["diag_chains_unfinished"] / s["diag_chains"].clip(lower=1)).mean())
    json.dump(ex, open(os.path.join(RES, "extra_main.json"), "w"), indent=1, default=float)

    # reproduction of the archived results of the previous version (identical settings except the corrections)
    old_path = os.path.join(RES, "archive_v2", "benchmark.csv")
    if os.path.exists(old_path):
        old = load(old_path)
        key = ["dataset", "rep", "fold", "method", "clf"]
        m = old.merge(df, on=key, suffixes=("_old", "_new"))
        rep = {}
        for meth, g in m.groupby("method"):
            d = np.max(np.abs(np.vstack([g[f"{c}_old"] - g[f"{c}_new"] for c in ["gmean", "f1", "aucpr", "auc", "mcc"]])), axis=0)
            rep[meth] = dict(rows=len(g), identical=float(np.mean(d < 1e-9)), max_abs_diff=float(d.max()))
        # tasks in which a method differs at all
        diff_tasks = {}
        for meth in ["SGBO", "BDO"]:
            g = m[m.method == meth]
            dd = np.max(np.abs(np.vstack([g[f"{c}_old"] - g[f"{c}_new"] for c in ["gmean", "f1", "aucpr", "auc", "mcc"]])), axis=0)
            diff_tasks[meth] = sorted(g.dataset[dd > 1e-9].unique().tolist())
        json.dump(dict(per_method=rep, differing_tasks=diff_tasks, rows_compared=len(m)), open(os.path.join(RES, "reproduction.json"), "w"), indent=1)
    for met in METRICS:
        fr = full[met]
        print(f"\n== {met}: N={fr['N']} k={fr['k']} chi2={fr['chi2']:.2f} FF={fr['FF']:.2f} p={fr['p_FF']:.2e} CD={fr['cd']:.3f}")
        for mth, r in sorted(fr["ranks"].items(), key=lambda x: x[1]):
            ph = fr["posthoc"].get(mth)
            extra = "" if ph is None else f"  d={ph['mean']:+.4f} [{ph['ci_lo']:+.4f},{ph['ci_hi']:+.4f}] W/L={ph['wins']}/{ph['losses']} pH={ph['p_holm']:.3f}"
            print(f"   {mth:10s} rank={r:5.2f} mean={fr['mean'][mth]:.4f}{extra}")


if __name__ == "__main__":
    main()
