"""Sample-quality summaries on the benchmark tasks (results/quality_tasks.csv) -> results/quality_summary.json"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES
from sgbo.stats import holm, boot_ci

q = pd.read_csv(os.path.join(RES, "quality_tasks.csv"), keep_default_na=False, na_values=[""])
q["deep_excess"] = q["deep_frac"] - q["deep_frac_ho"]            # synthetic points deep in the majority region, relative to new real minority points
q["bnd_excess"] = q["bnd_frac"] - q["bnd_frac_ho"]
q["share_gap"] = q["share_mean"] - q["share_mean_ho"]
q["log_nn_ratio"] = np.log(q["nn_ratio"].clip(lower=1e-3))
q["log_maj_ratio"] = np.log(q["maj_ratio"].clip(lower=1e-3))
METS = ["nn_ratio", "log_nn_ratio", "dup_frac", "prec", "rec", "mmd_ho", "edist_ho", "logdens_diff", "deep_frac", "deep_excess", "bnd_frac", "bnd_excess",
        "share_mean", "share_gap", "maj_ratio", "log_maj_ratio", "sd_per_dim", "nn_min_med"]
refs = ["deep_frac_ho", "bnd_frac_ho", "share_mean_ho", "deep_frac_tr", "bnd_frac_tr", "share_mean_tr", "b_mean_ho", "b_mean_tr"]
# unit: source (average folds, then related tasks)
u = q.groupby(["source", "dataset", "method"])[METS + refs].mean().groupby(["source", "method"]).mean()
out = dict(n_sources=int(u.index.get_level_values(0).nunique()), n_tasks=int(q.dataset.nunique()), methods=list(u.index.get_level_values(1).unique()))
out["mean"] = {m: u.xs(m, level="method")[METS].mean().to_dict() for m in out["methods"]}
out["median"] = {m: u.xs(m, level="method")[METS].median().to_dict() for m in out["methods"]}
out["reference"] = u.xs("SGBO", level="method")[refs].mean().to_dict()
# paired SGBO comparisons (lower is better for the first group)
res = {}
for met, better in (("mmd_ho", "lower"), ("deep_excess", "lower"), ("log_nn_ratio", "closer to 0"), ("log_maj_ratio", "closer to 0"), ("prec", "higher"), ("rec", "higher"), ("edist_ho", "lower")):
    M = u[met].unstack("method").dropna()
    if better == "closer to 0":
        M = M.abs()
    r = {}
    for m in M.columns:
        if m == "SGBO":
            continue
        d = (M["SGBO"] - M[m]).values
        p = float(stats.wilcoxon(d).pvalue) if np.any(np.abs(d) > 1e-12) else 1.0
        r[m] = dict(mean=float(d.mean()), p=p, sgbo_better=int((d < -1e-12).sum() if better in ("lower", "closer to 0") else (d > 1e-12).sum()), n=len(d))
    for m, pa in zip(r, holm([r[m]["p"] for m in r])):
        r[m]["p_holm"] = float(pa)
    res[met] = dict(better=better, vs=r, ranks=M.rank(axis=1, ascending=(better != "higher")).mean().to_dict())
out["paired"] = res
s = q[q.method == "SGBO"]
out["sgbo"] = dict(rej_share_mean=float(s.rej_share.mean()), rej_share_median=float(s.rej_share.median()), rej_share_max=float(s.rej_share.max()),
                   unfinished_mean=float(s.unfinished.mean()), unfinished_median=float(s.unfinished.median()), unfinished_max=float(s.unfinished.max()),
                   fill_share_mean=float(s.fill_share.mean()), fill_share_max=float(s.fill_share.max()), n_calls=len(s),
                   calls_with_fill=int((s.fill_share > 0).sum()), calls_unfinished_gt_half=int((s.unfinished > 0.5).sum()), calls_rej_gt_half=int((s.rej_share > 0.5).sum()),
                   by_task={d: dict(rej=float(g.rej_share.mean()), unf=float(g.unfinished.mean()), fill=float(g.fill_share.mean())) for d, g in s.groupby("dataset")})
json.dump(out, open(os.path.join(RES, "quality_summary.json"), "w"), indent=1, default=float)
print(pd.DataFrame(out["mean"]).T[["nn_ratio", "dup_frac", "prec", "rec", "mmd_ho", "deep_excess", "bnd_excess", "share_gap", "maj_ratio", "logdens_diff"]].round(3))
print(out["sgbo"] | {"by_task": "..."})
