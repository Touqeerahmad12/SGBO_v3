"""Scalability summaries (results/scalability.csv, scalability_memory.csv) -> results/scalability_summary.json"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES

t = pd.read_csv(os.path.join(RES, "scalability.csv"))
out = dict(slopes={}, times={}, stages={}, clf={})
for sweep, g in t.groupby("sweep"):
    out["slopes"][sweep] = {}; out["times"][sweep] = {}
    for m, h in g.groupby("method"):
        h = h.sort_values("value"); h = h[h.t_med > 0.02]
        if len(h) >= 3:
            x, y = np.log(h["value"].astype(float).values), np.log(h.t_med.values)
            r = stats.linregress(x, y); tc = stats.t.ppf(0.975, len(x) - 2) if len(x) > 2 else np.nan
            # slope over the upper half of the range (asymptotic behaviour)
            k = max(3, len(x) // 2 + 1); r2 = stats.linregress(x[-k:], y[-k:])
            out["slopes"][sweep][m] = dict(slope=float(r.slope), lo=float(r.slope - tc * r.stderr), hi=float(r.slope + tc * r.stderr),
                                           slope_upper=float(r2.slope), npts=len(x), vmax=float(h["value"].max()))
        out["times"][sweep][m] = {str(int(v)): float(tm) for v, tm in zip(h["value"], h.t_med)}
        allh = g[g.method == m].sort_values("value")
        out["times"][sweep][m] = {str(int(v)): float(tm) for v, tm in zip(allh["value"], allh.t_med)}
sg = t[t.method == "SGBO"].dropna(subset=["t_stage1"])
for sweep, g in sg.groupby("sweep"):
    g = g.sort_values("value")
    out["stages"][sweep] = {str(int(v)): [float(a), float(b), float(c)] for v, a, b, c in zip(g["value"], g.t_stage1, g.t_stage2, g.t_stage3)}
# resampling vs classifier training at the reference configuration (n = 4000, d = 10, IR = 10)
ref = t[(t.sweep == "n") & (t.value == 4000)]
cl = ref.iloc[0][[c for c in ref.columns if c.startswith("t_fit_")]].to_dict()
out["clf"] = dict(fit=cl, prep=float(ref.iloc[0].t_prep), resample={r.method: float(r.t_med) for r in ref.itertuples()})
mp = os.path.join(RES, "scalability_memory.csv")
if os.path.exists(mp):
    m = pd.read_csv(mp)
    out["memory"] = {sw: {str(int(v)): {r.method: float(r.peak_mb) for r in g.itertuples()} for v, g in gg.groupby("value")} for sw, gg in m.groupby("sweep")}
json.dump(out, open(os.path.join(RES, "scalability_summary.json"), "w"), indent=1, default=float)
for sw in out["slopes"]:
    print(sw, {m: round(v["slope"], 2) for m, v in out["slopes"][sw].items()})
