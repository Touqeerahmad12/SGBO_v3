"""
Parameter sensitivity (results/sensitivity.csv, sensitivity_grid.csv) -> results/sensitivity_summary.json

For every parameter and value: change of the (fold- and classifier-averaged) MCC / AUC-PR with respect to the
default setting, per task, per task group (imbalance x dimension) and over all tasks; acceptance statistics.
Recommended range = values whose mean MCC is within 0.01 of the best value of the parameter in every group.
"""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.datasets import task_registry
from sgbo.protocol import RES
from sgbo.stats import boot_ci
from run_sensitivity import DEFAULTS, GRID

s = pd.read_csv(os.path.join(RES, "sensitivity.csv"), keep_default_na=False, na_values=[""])
reg = {t["name"]: t for t in task_registry()}
info = {n: dict(d=reg[n]["X"].shape[1], ir=float((reg[n]["y"] == 0).sum() / reg[n]["y"].sum())) for n in s.dataset.unique()}
grp = {n: f"{'IR>=10' if i['ir'] >= 10 else 'IR<10'}, {'d>=20' if i['d'] >= 20 else 'd<20'}" for n, i in info.items()}
out = dict(tasks={n: dict(info[n], group=grp[n]) for n in info}, params={})
MET = ["mcc", "aucpr", "f1", "gmean"]
base = s[s.param == "default"].groupby(["dataset", "clf"])[MET].mean().groupby("dataset").mean()
for p, vals in GRID.items():
    d = s[s.param == p].copy(); d["value"] = d["value"].astype(float)
    t = d.groupby(["dataset", "value", "clf"])[MET].mean().groupby(["dataset", "value"]).mean()
    acc = d[d.clf == "RF"].groupby(["dataset", "value"])[["acc_rate", "fill_share", "rounds_used", "unfinished", "t_stage1", "t_stage2", "t_stage3", "k_used", "h_used", "theta_used"]].mean()
    res = {}
    for v in vals:
        rec = {}
        for met in MET:
            dv = (t.xs(float(v), level="value")[met] - base[met])
            by_group = {g: float(dv[[n for n in dv.index if grp[n] == g]].mean()) for g in sorted(set(grp.values()))}
            lo, hi = boot_ci(dv.values, B=4000)
            rec[met] = dict(mean=float(dv.mean()), lo=lo, hi=hi, groups=by_group, per_task=dv.to_dict(), abs_mean=float(t.xs(float(v), level="value")[met].mean()))
        rec["acc"] = acc.xs(float(v), level="value").mean().to_dict()
        res[str(v)] = rec
    # tolerance region
    groups = sorted(set(grp.values())); tol = {}
    for met in ("mcc", "aucpr"):
        ok = {str(v): True for v in vals}
        for g in groups + ["all"]:
            vals_g = {str(v): (res[str(v)][met]["mean"] if g == "all" else res[str(v)][met]["groups"][g]) for v in vals}
            if g != "all" and any(np.isnan(x) for x in vals_g.values()):
                continue
            best = max(vals_g.values())
            for k, x in vals_g.items():
                if x < best - 0.01:
                    ok[k] = False
        tol[met] = [k for k, v in ok.items() if v]
    out["params"][p] = dict(default=DEFAULTS[p], values=res, tolerance=tol)
    print(p, "default", DEFAULTS[p], "tolerance MCC", tol["mcc"], "AUC-PR", tol["aucpr"])
g = pd.read_csv(os.path.join(RES, "sensitivity_grid.csv"), keep_default_na=False, na_values=[""])
gm = g.groupby(["dataset", "eta", "tau", "clf"])["mcc"].mean().groupby(["dataset", "eta", "tau"]).mean().groupby(["eta", "tau"]).mean().unstack("tau")
out["grid_mcc"] = dict(eta=[float(x) for x in gm.index], tau=[float(x) for x in gm.columns], z=gm.values.tolist())
ga = g.groupby(["dataset", "eta", "tau", "clf"])["aucpr"].mean().groupby(["dataset", "eta", "tau"]).mean().groupby(["eta", "tau"]).mean().unstack("tau")
out["grid_aucpr"] = dict(eta=[float(x) for x in ga.index], tau=[float(x) for x in ga.columns], z=ga.values.tolist())
out["default_mean"] = {m: float(base[m].mean()) for m in MET}
json.dump(out, open(os.path.join(RES, "sensitivity_summary.json"), "w"), indent=1, default=float)
