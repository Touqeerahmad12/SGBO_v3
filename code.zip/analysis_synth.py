"""Robustness sweeps on the known model (results/synthetic_study.csv) -> results/synth_summary.json

For every factor (separation s, label noise rho, irrelevant features q, imbalance ratio IR) and value: mean and standard
error over seeds (classifiers averaged) of MCC / AUC-PR / F1 / G-mean for every method; paired differences SGBO - comparator
with a 95% bootstrap interval over seeds; fidelity of the synthetic points (deep share, mean true posterior)."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES
from sgbo.stats import boot_ci

s = pd.read_csv(os.path.join(RES, "synthetic_study.csv"), keep_default_na=False, na_values=[""])
MET = ["mcc", "aucpr", "f1", "gmean"]
FACT = ["s", "rho", "q", "ir"]
COMP = ["None", "SMOTE", "SVM-SMOTE", "BDO", "MWMOTE", "CCR"]
u = s.groupby(["factor", "value", "seed", "method"])[MET + ["wrong_side", "deep_majority", "mean_eta_new", "near_flipped"]].mean()
out = dict(n_seeds=int(s.seed.nunique()), curve={}, diff={}, fidelity={}, pooled={}, boundary={})
for f in FACT:
    d = u.xs(f, level="factor")
    vals = sorted(d.index.get_level_values("value").unique())
    out["curve"][f] = {}
    for met in MET:
        M = d[met].unstack("method")
        out["curve"][f][met] = {m: dict(x=[float(v) for v in vals], mean=[float(M.loc[v, m].mean()) for v in vals],
                                        se=[float(M.loc[v, m].std(ddof=1) / np.sqrt(len(M.loc[v]))) for v in vals]) for m in M.columns}
    out["diff"][f] = {}
    for c in COMP:
        out["diff"][f][c] = {}
        for met in ("mcc", "aucpr"):
            M = d[met].unstack("method")
            rec = {}
            for v in vals:
                x = (M.loc[v, "SGBO"] - M.loc[v, c]).values
                lo, hi = boot_ci(x, B=4000)
                rec[str(v)] = dict(mean=float(x.mean()), lo=float(lo), hi=float(hi), wins=int((x > 0).sum()), n=len(x))
            allx = np.concatenate([(M.loc[v, "SGBO"] - M.loc[v, c]).values for v in vals])
            lo, hi = boot_ci(allx, B=4000)
            rec["all"] = dict(mean=float(allx.mean()), lo=float(lo), hi=float(hi), wins=int((allx > 0).sum()), n=len(allx))
            out["diff"][f][c][met] = rec
    # fidelity of the synthetic points (clean-label factors) and boundary-score error
    for col in ("wrong_side", "deep_majority", "mean_eta_new", "near_flipped"):
        M = d[col].unstack("method")
        out["fidelity"].setdefault(f, {})[col] = {m: {str(v): float(M.loc[v, m].mean()) for v in vals} for m in M.columns if M[m].notna().any()}
    b = s[(s.factor == f) & (s.method == "None") & (s.clf == "RF")].groupby("value")[["err_BDO", "err_SGBO", "rho_BDO", "rho_SGBO", "n_pos"]].mean()
    out["boundary"][f] = {str(v): b.loc[v].to_dict() for v in b.index}
for met in MET:
    M = u[met].unstack("method")
    out["pooled"][met] = dict(mean={m: float(M[m].mean()) for m in M.columns}, rank={m: float(x) for m, x in M.rank(axis=1, ascending=False).mean().items()},
                             sgbo_gt_smote=float((M.SGBO > M.SMOTE).mean()), sgbo_gt_svm=float((M.SGBO > M["SVM-SMOTE"]).mean()), sgbo_gt_bdo=float((M.SGBO > M.BDO).mean()),
                             n_settings=int(len(M)))
json.dump(out, open(os.path.join(RES, "synth_summary.json"), "w"), indent=1)
print("synth_summary.json written; pooled MCC ranks:", {k: round(v, 2) for k, v in out["pooled"]["mcc"]["rank"].items()})
