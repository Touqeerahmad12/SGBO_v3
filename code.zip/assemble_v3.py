"""Assemble manuscript_v3/main.tex (single file) and supplement.tex from parts, tables and generated facts."""
import os, re, sys, subprocess, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

M = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "manuscript_v3")
P = os.path.join(M, "parts")
T = os.path.join(M, "tables")


def tab(name):
    p = os.path.join(T, name)
    return open(p).read().strip() if os.path.exists(p) else "% missing " + name



AUX = {}
def load_aux():
    p = os.path.join(M, "main.aux")
    if os.path.exists(p):
        for m in re.finditer(r"\\newlabel\{([^}]*)\}\{\{([^}]*)\}", open(p).read()):
            AUX[m.group(1)] = m.group(2)

NAMES = (("thm:", "Theorem"), ("prop:", "Proposition"), ("def:", "Definition"), ("ass:", "Assumption"), ("rem:", "Remark"), ("ex:", "Example"),
         ("sec:", "Section"), ("fig:", "Figure"), ("tab:", "Table"), ("alg:", "Algorithm"))
SUPP_BIB_PLACEHOLDER = [""]

def ref_text(lab, eq=False):
    n = AUX.get(lab, "??")
    if lab.startswith("eq:"):
        return "(" + n + ")"
    for pre, nm in NAMES:
        if lab.startswith(pre):
            return f"{nm}~{n}"
    return n

def build_proofs():
    load_aux()
    raw = open(os.path.join(P, "supp_proofs.tex")).read()
    blocks = [b for b in raw.split("%%LAB:") if b.strip()]
    local = set()
    out = []
    for b in blocks:
        lab, body = b.split("\n", 1)
        local |= {x for x in re.findall(r"\\label\{([^}]*)\}", body) if x.startswith("eq:")}
    keys = []
    for b in blocks:
        lab, body = b.split("\n", 1)
        num = AUX.get(lab, "??")
        m = re.match(r"\\begin\{(theorem|proposition)\}(?:\[([^\]]*)\])?\\label\{[^}]*\}", body)
        env, title = m.group(1), m.group(2)
        head = f"{env.capitalize()}~{num}" + (f", {title}" if title else "")
        body = body[m.end():]
        body = re.sub(r"\\end\{(theorem|proposition)\}", r"\\end{restated}", body, count=1)
        body = f"\\begin{{restated}}[{head}]" + body
        # replace references to main-text labels by their numbers
        def sub_cref(mm):
            labs = [x.strip() for x in mm.group(1).split(",")]
            return ", ".join(x if False else ref_text(x) for x in labs) if not all(x in local for x in labs) else mm.group(0)
        body = re.sub(r"\\[cC]ref\{([^}]*)\}", sub_cref, body)
        body = re.sub(r"\\eqref\{([^}]*)\}", lambda mm: mm.group(0) if mm.group(1) in local else ref_text(mm.group(1)), body)
        keys += [k.strip() for mm in re.finditer(r"\\cite(?:\[[^\]]*\])?\{([^}]*)\}", body) for k in mm.group(1).split(",")]
        out.append(body)
    keys = list(dict.fromkeys(keys))
    if keys:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_bib.py")).read()
        ns = {}
        exec(src[src.index("REFS = {"):src.index("\n}\n", src.index("REFS = {")) + 2], ns)
        SUPP_BIB_PLACEHOLDER[0] = "\\begin{thebibliography}{9}\n" + "\n".join(f"\\bibitem{{{k}}} {ns['REFS'][k]}" for k in keys) + "\n\\end{thebibliography}\n"
    return "\n\n".join(out)

SUPP_FIGS = r"""
\begin{figure}[!htbp]
\centering
\includegraphics[width=0.93\linewidth]{figures/fig_heatmap.pdf}
\caption{Mean MCC of the 12 methods on the 28 sources (average over the related tasks of a source, five repetitions of five-fold cross-validation and four classifiers). Frames mark the best method of each source. The first four rows belong to the scikit-learn sources, the next six to the synthetic tasks, and the remaining rows to the real sources.}
\label{figS:heatmap}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.93\linewidth]{figures/fig_classifier_ranks.pdf}
\caption{Average rank (over the 28 sources) of every method for each of the four classifiers, for MCC and AUC-PR (lower is better).}
\label{figS:clf}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=\linewidth]{figures/fig_imbalance.pdf}
\caption{(a) Difference in MCC between SGBO and three methods for each task against its imbalance ratio (lines: running medians over nine neighbouring tasks); (b) average MCC rank of selected methods within four imbalance groups (descriptive; the groups contain different tasks).}
\label{figS:imb}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=\linewidth]{figures/fig_effects.pdf}
\caption{Paired differences SGBO $-$ method over the 28 sources (box: quartiles; line: median) for MCC and AUC-PR.}
\label{figS:effects}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=\linewidth]{figures/fig_shrink_langevin.pdf}
\caption{Covariance shrinkage and Langevin noise. (a) Median condition number of the local covariances and (b) change in MCC relative to the default, against the dimension (known model, $n=800$, IR $=10$, 20 training sets per dimension); crosses: singular covariances. (c) Diversity (mean nearest-neighbour distance among the synthetic points relative to the real minority spacing) and (d) coverage of the class-boundary region by the synthetic points, against the temperature $\tau$ (12 data sets, 20 repeated runs on each training set).}
\label{figS:shrink}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.93\linewidth]{figures/fig_known_visual.pdf}
\caption{Synthetic points (purple) of four methods on the known model in two settings (red: real minority points; blue: majority points; green: contours of the true minority density at the levels 0.02 (dotted) and 0.1 (solid); black: Bayes boundary $\eta=1/2$, which exists only in the first row). Top: $s=2$, IR 10; bottom: $s=1.2$, IR 30, where the two clusters touch and the minority class is almost nowhere more probable than the majority class.}
\label{figS:known}
\end{figure}
"""

order = ["a_front.tex", "b_related.tex", "c_method.tex", "d_setup.tex", "e1_illus.tex", "e2_ablation.tex", "e3_quality.tex", "e4_bench.tex",
         "e5_robust.tex", "e6_sens.tex", "e7_cost.tex", "e8_apps.tex", "f_end.tex"]
tex = "\n".join(open(os.path.join(P, p)).read() for p in order if os.path.exists(os.path.join(P, p)))
tex = tex.replace("%ABSTRACT%", open(os.path.join(P, "abstract.txt")).read().strip())
for key, f in (("%TAB_DATASUM%", "tab_datasum.tex"), ("%EXCEPTIONS%", "tab_exceptions.tex"), ("%TAB_MAIN%", "tab_main.tex"),
               ("%TAB_FRIEDMAN%", "tab_friedman.tex"), ("%TAB_POSTHOC%", "tab_posthoc.tex"), ("%TAB_APPS%", "tab_apps.tex"),
               ("%TAB_SENS%", "tab_sens.tex"), ("%TAB_SCALE%", "tab_scale.tex"), ("%TAB_QUAL%", "tab_quality.tex"), ("%TAB_ABL%", "tab_ablation_bench.tex"),
               ("%TAB_TUNING%", "tab_tuning.tex")):
    if key in tex:
        tex = tex.replace(key, tab(f))
for key, f in (("%TUNING_PARA%", "para_tuning.tex"), ("%ABLATION_BENCH%", "para_ablation_bench.tex")):
    p = os.path.join(P, f)
    if key in tex:
        tex = tex.replace(key, open(p).read().strip() if os.path.exists(p) else "[pending]")
open(os.path.join(M, "main.tex"), "w").write(tex)
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_bib.py"), os.path.join(M, "main.tex")], check=True)

# supplement
sp = os.path.join(M, "supp_template.tex")
if os.path.exists(sp):
    sup = open(sp).read()
    LAB = {"mcc": "MCC", "aucpr": "AUC-PR", "f1": "F1", "gmean": "G-mean"}
    heads = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SM", "SM-ENN", "$k$M-SM", "MWMOTE", "CCR", "BDO", "SGBO"]
    blocks = []
    blocks.append(
        "\\begin{center}\\footnotesize\n\\begin{longtable}{p{5.5cm}p{9.5cm}p{5cm}}\n"
        "\\caption{Behaviour of SGBO in exceptional situations and how often each situation occurred in the main benchmark (all tasks, repetitions and folds; events are counted per resampling call or per chain).}\\\\\n"
        "\\toprule\nSituation & Behaviour & Observed frequency \\\\\n\\midrule\n\\endfirsthead\n" + tab("tab_exceptions.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
    blocks.append(
        "\\begin{center}\\scriptsize\n\\begin{longtable}{@{}l l l r r r r r p{4.6cm}@{}}\n"
        "\\caption{The 45 tasks. $n$: size; $d$: number of features after encoding; $n^+$, $n^-$: minority and majority counts; IR $=n^-/n^+$. $^\\ast$: primary task of its source; $^\\dagger$: official training/test split.}\\\\\n"
        "\\toprule\nID & Task & Source & $n$ & $d$ & $n^+$ & $n^-$ & IR & Minority class \\\\\n\\midrule\n\\endfirsthead\n"
        "\\toprule\nID & Task & Source & $n$ & $d$ & $n^+$ & $n^-$ & IR & Minority class \\\\\n\\midrule\n\\endhead\n"
        + tab("tab_data.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n\\clearpage\n")
    for met in ["aucpr", "mcc", "f1", "gmean"]:
        body = tab(f"supp_{met}.tex")
        blocks.append(
            "\\begin{center}\\scriptsize\n\\begin{longtable}{l" + "r" * 12 + "}\n"
            f"\\caption{{Per-task {LAB[met]} (mean over repetitions, folds and classifiers; standard deviation in small type).}}\\\\\n"
            "\\toprule\nTask & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endfirsthead\n"
            "\\toprule\nTask & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endhead\n"
            + body + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n\\clearpage\n")
    blocks.append(
        "\\begin{center}\\scriptsize\n\\begin{longtable}{ll" + "r" * 12 + "}\n"
        "\\caption{Average Friedman ranks per classifier over the 28 independent sources (lower is better; best in bold).}\\\\\n"
        "\\toprule\nMetric & Classifier & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endfirsthead\n"
        + tab("supp_classifier_ranks.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
    blocks.append(
        "\\begin{center}\\scriptsize\n\\begin{longtable}{l ccc ccc}\n"
        "\\caption{SGBO against each method for F1 and G-mean (28 sources, pooled over classifiers): mean difference with 95\\% bootstrap interval, wins/losses of SGBO, Holm-adjusted Wilcoxon $p$-value (bold: significant at 0.05).}\\\\\n"
        "\\toprule\n & \\multicolumn{3}{c}{F1} & \\multicolumn{3}{c}{G-mean} \\\\\n\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}\nMethod & $\\Delta$ [95\\% CI] & W/L & $p_{\\mathrm{H}}$ & $\\Delta$ [95\\% CI] & W/L & $p_{\\mathrm{H}}$ \\\\\n\\midrule\n"
        + tab("supp_posthoc.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
    blocks.append(
        "\\begin{center}\\footnotesize\n\\begin{longtable}{l cccc cccc}\n"
        "\\caption{Default and training-only tuned results on the 25 primary tasks with $n\\le3000$ (first repetition, RF and $k$NN; mean over tasks). $\\Delta$: tuned minus default. Rank: average rank over the tasks among all 12 methods, using the tuned version where one exists. ROS, None and BDO were not tuned.}\\\\\n"
        "\\toprule\n & \\multicolumn{4}{c}{MCC} & \\multicolumn{4}{c}{AUC-PR} \\\\\n\\cmidrule(lr){2-5}\\cmidrule(lr){6-9}\nMethod & default & tuned & $\\Delta$ & rank & default & tuned & $\\Delta$ & rank \\\\\n\\midrule\n\\endfirsthead\n"
        + tab("tab_tuning.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
    for extra in ("supp_extra.tex",):
        p = os.path.join(T, extra)
        if os.path.exists(p):
            blocks.append(open(p).read())
    sup = sup.replace("%SUPP_TABLES%", "\n".join(blocks))
    sup = sup.replace("%SUPP_MEAS%", open(os.path.join(P, "supp_measures.tex")).read()).replace("%SUPP_PROOFS%", build_proofs()).replace("%SUPP_FIGS%", SUPP_FIGS)
    keys = []
    for mm in re.finditer(r"\\cite(?:\[[^\]]*\])?\{([^}]*)\}", sup):
        keys += [k.strip() for k in mm.group(1).split(",")]
    keys = list(dict.fromkeys(keys))
    _dp = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dois_verified.json')
    DOIS_S = json.load(open(_dp)) if os.path.exists(_dp) else {}
    srcb = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_bib.py")).read()
    nsb = {}
    exec(srcb[srcb.index("REFS = {"):srcb.index("\n}\n", srcb.index("REFS = {")) + 2], nsb)
    bib = ("\\section*{References}\n\\begin{thebibliography}{9}\n" + "\n".join(f"\\bibitem{{{k}}} " + (nsb['REFS'][k] + (". Preprint: " if DOIS_S[k].startswith("10.48550/") else ". ") + "\\doi{" + DOIS_S[k] + "}" if k in DOIS_S and "doi.org" not in nsb['REFS'][k] else nsb['REFS'][k] + ".") for k in keys) + "\n\\end{thebibliography}\n") if keys else ""
    sup = sup.replace("%SUPP_BIB%", bib)
    open(os.path.join(M, "supplement.tex"), "w").write(sup)
print("assembled")
