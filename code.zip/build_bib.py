"""Insert the reference list into main.tex, ordered by first citation."""
import re, sys

REFS = {
"japkowicz2002": r"Japkowicz N, Stephen S (2002) The class imbalance problem: a systematic study. Intelligent Data Analysis 6(5):429--449",
"chawla2002": r"Chawla NV, Bowyer KW, Hall LO, Kegelmeyer WP (2002) SMOTE: synthetic minority over-sampling technique. Journal of Artificial Intelligence Research 16:321--357",
"batista2004": r"Batista GEAPA, Prati RC, Monard MC (2004) A study of the behavior of several methods for balancing machine learning training data. ACM SIGKDD Explorations Newsletter 6(1):20--29",
"han2005": r"Han H, Wang WY, Mao BH (2005) Borderline-SMOTE: a new over-sampling method in imbalanced data sets learning. In: Advances in Intelligent Computing (ICIC 2005), Lecture Notes in Computer Science, vol 3644. Springer, Berlin, pp 878--887",
"he2008": r"He H, Bai Y, Garcia EA, Li S (2008) ADASYN: adaptive synthetic sampling approach for imbalanced learning. In: Proceedings of the IEEE International Joint Conference on Neural Networks (IJCNN 2008), pp 1322--1328",
"he2009": r"He H, Garcia EA (2009) Learning from imbalanced data. IEEE Transactions on Knowledge and Data Engineering 21(9):1263--1284",
"nguyen2011": r"Nguyen HM, Cooper EW, Kamei K (2011) Borderline over-sampling for imbalanced data classification. International Journal of Knowledge Engineering and Soft Data Paradigms 3(1):4--21",
"barua2014": r"Barua S, Islam MM, Yao X, Murase K (2014) MWMOTE---majority weighted minority oversampling technique for imbalanced data set learning. IEEE Transactions on Knowledge and Data Engineering 26(2):405--425",
"saez2015": r"S{\'a}ez JA, Luengo J, Stefanowski J, Herrera F (2015) SMOTE--IPF: addressing the noisy and borderline examples problem in imbalanced classification by a re-sampling method with filtering. Information Sciences 291:184--203",
"napierala2016": r"Napiera{\l}a K, Stefanowski J (2016) Types of minority class examples and their influence on learning classifiers from imbalanced data. Journal of Intelligent Information Systems 46(3):563--597",
"krawczyk2016": r"Krawczyk B (2016) Learning from imbalanced data: open challenges and future directions. Progress in Artificial Intelligence 5(4):221--232",
"koziarski2017": r"Koziarski M, Wo{\'z}niak M (2017) CCR: a combined cleaning and resampling algorithm for imbalanced data classification. International Journal of Applied Mathematics and Computer Science 27(4):727--736",
"douzas2017": r"Douzas G, Bacao F (2017) Self-organizing map oversampling (SOMO) for imbalanced data set learning. Expert Systems with Applications 82:40--52",
"rivera2017": r"Rivera WA (2017) Noise reduction a priori synthetic over-sampling for class imbalanced data sets. Information Sciences 408:146--161",
"douzas2018": r"Douzas G, Bacao F, Last F (2018) Improving imbalanced learning through a heuristic oversampling method based on k-means and SMOTE. Information Sciences 465:1--20",
"fernandez2018": r"Fern{\'a}ndez A, Garc{\'i}a S, Herrera F, Chawla NV (2018) SMOTE for learning from imbalanced data: progress and challenges, marking the 15-year anniversary. Journal of Artificial Intelligence Research 61:863--905",
"elreedy2019": r"Elreedy D, Atiya AF (2019) A comprehensive analysis of synthetic minority oversampling technique (SMOTE) for handling class imbalance. Information Sciences 505:32--64",
"kovacs2019": r"Kov{\'a}cs G (2019) smote-variants: a Python implementation of 85 minority oversampling techniques. Neurocomputing 366:352--354",
"kunakorntum2020": r"Kunakorntum I, Hinthong W, Phunchongharn P (2020) A synthetic minority based on probabilistic distribution (SyMProD) oversampling for imbalanced datasets. IEEE Access 8:114692--114704",
"wang2021": r"Wang X, Xu J, Zeng T, Jing L (2021) Local distribution-based adaptive minority oversampling for imbalanced data classification. Neurocomputing 422:200--213",
"dablain2023": r"Dablain D, Krawczyk B, Chawla NV (2023) DeepSMOTE: fusing deep learning and SMOTE for imbalanced data. IEEE Transactions on Neural Networks and Learning Systems 34(9):6390--6404",
"liu2023": r"Liu Y, Liu Y, Yu BXB, Zhong S, Hu Z (2023) Noise-robust oversampling for imbalanced data classification. Pattern Recognition 133:109008",
"ren2023": r"Ren J, Wang Y, Cheung YM, Gao XZ, Guo X (2023) Grouping-based oversampling in kernel space for imbalanced data classification. Pattern Recognition 133:108992",
"li2023": r"Li T, Wang Y, Liu L, Chen L, Chen CLP (2023) Subspace-based minority oversampling for imbalance classification. Information Sciences 621:371--388",
"kotelnikov2023": r"Kotelnikov A, Baranchuk D, Rubachev I, Babenko A (2023) TabDDPM: modelling tabular data with diffusion models. In: Proceedings of the 40th International Conference on Machine Learning, PMLR 202:17564--17579",
"chen2023bdo": r"Chen Y, Pedrycz W, Yang J (2023) A new boundary-degree-based oversampling method for imbalanced data. Applied Intelligence 53:26518--26541",
"fukunaga1975": r"Fukunaga K, Hostetler L (1975) The estimation of the gradient of a density function, with applications in pattern recognition. IEEE Transactions on Information Theory 21(1):32--40",
"cheng1995": r"Cheng Y (1995) Mean shift, mode seeking, and clustering. IEEE Transactions on Pattern Analysis and Machine Intelligence 17(8):790--799",
"comaniciu2002": r"Comaniciu D, Meer P (2002) Mean shift: a robust approach toward feature space analysis. IEEE Transactions on Pattern Analysis and Machine Intelligence 24(5):603--619",
"roberts1996": r"Roberts GO, Tweedie RL (1996) Exponential convergence of Langevin distributions and their discrete approximations. Bernoulli 2(4):341--363",
"welling2011": r"Welling M, Teh YW (2011) Bayesian learning via stochastic gradient Langevin dynamics. In: Proceedings of the 28th International Conference on Machine Learning (ICML 2011), pp 681--688",
"durmus2017": r"Durmus A, Moulines {\'E} (2017) Nonasymptotic convergence analysis for the unadjusted Langevin algorithm. The Annals of Applied Probability 27(3):1551--1587",
"song2019": r"Song Y, Ermon S (2019) Generative modeling by estimating gradients of the data distribution. In: Advances in Neural Information Processing Systems 32 (NeurIPS 2019)",
"ledoit2004": r"Ledoit O, Wolf M (2004) A well-conditioned estimator for large-dimensional covariance matrices. Journal of Multivariate Analysis 88(2):365--411",
"devroye1996": r"Devroye L, Gy{\"o}rfi L, Lugosi G (1996) A Probabilistic Theory of Pattern Recognition. Springer, New York",
"shannon1948": r"Shannon CE (1948) A mathematical theory of communication. Bell System Technical Journal 27(3):379--423",
"cover2006": r"Cover TM, Thomas JA (2006) Elements of Information Theory, 2nd edn. Wiley, Hoboken",
"silverman1986": r"Silverman BW (1986) Density Estimation for Statistics and Data Analysis. Chapman and Hall, London",
"dalalyan2017": r"Dalalyan AS (2017) Theoretical guarantees for approximate sampling from smooth and log-concave densities. Journal of the Royal Statistical Society: Series B 79(3):651--676",
"hyvarinen2005": r"Hyv{\"a}rinen A (2005) Estimation of non-normalized statistical models by score matching. Journal of Machine Learning Research 6:695--709",
"ho2020": r"Ho J, Jain A, Abbeel P (2020) Denoising diffusion probabilistic models. In: Advances in Neural Information Processing Systems 33 (NeurIPS 2020), pp 6840--6851",
"pavliotis2014": r"Pavliotis GA (2014) Stochastic Processes and Applications: Diffusion Processes, the Fokker--Planck and Langevin Equations. Texts in Applied Mathematics, vol 60. Springer, New York",
"pedregosa2011": r"Pedregosa F, Varoquaux G, Gramfort A, et al (2011) Scikit-learn: machine learning in Python. Journal of Machine Learning Research 12:2825--2830",
"street1993": r"Street WN, Wolberg WH, Mangasarian OL (1993) Nuclear feature extraction for breast tumor diagnosis. In: Biomedical Image Processing and Biomedical Visualization, Proceedings of SPIE, vol 1905, pp 861--870",
"dua2019": r"Dua D, Graff C (2019) UCI Machine Learning Repository. University of California, Irvine, School of Information and Computer Sciences. \url{http://archive.ics.uci.edu/ml}",
"fisher1936": r"Fisher RA (1936) The use of multiple measurements in taxonomic problems. Annals of Eugenics 7(2):179--188",
"efron2004": r"Efron B, Hastie T, Johnstone I, Tibshirani R (2004) Least angle regression. The Annals of Statistics 32(2):407--499",
"wilson1972": r"Wilson DL (1972) Asymptotic properties of nearest neighbor rules using edited data. IEEE Transactions on Systems, Man, and Cybernetics SMC-2(3):408--421",
"lemaitre2017": r"Lema{\^{\i}}tre G, Nogueira F, Aridas CK (2017) Imbalanced-learn: a Python toolbox to tackle the curse of imbalanced datasets in machine learning. Journal of Machine Learning Research 18(17):1--5",
"breiman2001": r"Breiman L (2001) Random forests. Machine Learning 45(1):5--32",
"cortes1995": r"Cortes C, Vapnik V (1995) Support-vector networks. Machine Learning 20(3):273--297",
"saito2015": r"Saito T, Rehmsmeier M (2015) The precision-recall plot is more informative than the ROC plot when evaluating binary classifiers on imbalanced datasets. PLoS ONE 10(3):e0118432",
"chicco2020": r"Chicco D, Jurman G (2020) The advantages of the Matthews correlation coefficient (MCC) over F1 score and accuracy in binary classification evaluation. BMC Genomics 21:6",
"friedman1937": r"Friedman M (1937) The use of ranks to avoid the assumption of normality implicit in the analysis of variance. Journal of the American Statistical Association 32(200):675--701",
"iman1980": r"Iman RL, Davenport JM (1980) Approximations of the critical region of the Friedman statistic. Communications in Statistics -- Theory and Methods 9(6):571--595",
"holm1979": r"Holm S (1979) A simple sequentially rejective multiple test procedure. Scandinavian Journal of Statistics 6(2):65--70",
"demsar2006": r"Dem{\v{s}}ar J (2006) Statistical comparisons of classifiers over multiple data sets. Journal of Machine Learning Research 7:1--30",
"garcia2010": r"Garc{\'i}a S, Fern{\'a}ndez A, Luengo J, Herrera F (2010) Advanced nonparametric tests for multiple comparisons in the design of experiments in computational intelligence and data mining: experimental analysis of power. Information Sciences 180(10):2044--2064",
"alcala2011": r"Alcal{\'a}-Fdez J, Fern{\'a}ndez A, Luengo J, Derrac J, Garc{\'i}a S, S{\'a}nchez L, Herrera F (2011) KEEL data-mining software tool: data set repository, integration of algorithms and experimental analysis framework. Journal of Multiple-Valued Logic and Soft Computing 17(2--3):255--287",
"koziarski2019rbo": r"Koziarski M, Krawczyk B, Wo{\'z}niak M (2019) Radial-Based oversampling for noisy imbalanced data classification. Neurocomputing 343:19--33",
"bellinger2020swim": r"Bellinger C, Sharma S, Japkowicz N, Za{\"i}ane OR (2020) Framework for extreme imbalance classification: SWIM---sampling with the majority class. Knowledge and Information Systems 62:841--866",
"kamalov2020": r"Kamalov F (2020) Kernel density estimation based sampling for imbalanced class distribution. Information Sciences 512:1192--1201",
"kim2022sos": r"Kim J, Lee C, Shin Y, Park S, Kim M, Park N, Cho J (2022) SOS: score-based oversampling for tabular data. In: Proceedings of the 28th ACM SIGKDD Conference on Knowledge Discovery and Data Mining (KDD '22). ACM, New York. \url{https://doi.org/10.1145/3534678.3539454}",
"douzas2019gsmote": r"Douzas G, Bacao F (2019) Geometric SMOTE a geometrically enhanced drop-in replacement for SMOTE. Information Sciences 501:118--135",
"bej2021loras": r"Bej S, Davtyan N, Wolfien M, Nassar M, Wolkenhauer O (2021) LoRAS: an oversampling approach for imbalanced datasets. Machine Learning 110:279--301",
"bunkhumpornpat2012": r"Bunkhumpornpat C, Sinapiromsaran K, Lursinsap C (2012) DBSMOTE: density-based synthetic minority over-sampling technique. Applied Intelligence 36(3):664--684",
"gao2014pdfos": r"Gao M, Hong X, Chen S, Harris CJ, Khalaf E (2014) PDFOS: PDF estimation based over-sampling for imbalanced two-class problems. Neurocomputing 138:248--259",
"das2015racog": r"Das B, Krishnan NC, Cook DJ (2015) RACOG and wRACOG: two probabilistic oversampling techniques. IEEE Transactions on Knowledge and Data Engineering 27(1):222--234",
"xu2019ctgan": r"Xu L, Skoularidou M, Cuesta-Infante A, Veeramachaneni K (2019) Modeling tabular data using conditional GAN. In: Advances in Neural Information Processing Systems 32 (NeurIPS 2019)",
"benavoli2016": r"Benavoli A, Corani G, Mangili F (2016) Should we really use post-hoc tests based on mean-ranks? Journal of Machine Learning Research 17(5):1--10",
"kynkaanniemi2019": r"Kynk{\"a}{\"a}nniemi T, Karras T, Laine S, Lehtinen J, Aila T (2019) Improved precision and recall metric for assessing generative models. In: Advances in Neural Information Processing Systems 32 (NeurIPS 2019)",
"gretton2012": r"Gretton A, Borgwardt KM, Rasch MJ, Sch{\"o}lkopf B, Smola A (2012) A kernel two-sample test. Journal of Machine Learning Research 13:723--773",
"szekely2013": r"Sz{\'e}kely GJ, Rizzo ML (2013) Energy statistics: a class of statistics based on distances. Journal of Statistical Planning and Inference 143:1249--1272",
"frenay2014": r"Fr{\'e}nay B, Verleysen M (2014) Classification in the presence of label noise: a survey. IEEE Transactions on Neural Networks and Learning Systems 25(5):845--869",
"beyer1999": r"Beyer K, Goldstein J, Ramakrishnan R, Shaft U (1999) When is ``nearest neighbor'' meaningful? In: Database Theory --- ICDT'99, Lecture Notes in Computer Science, vol 1540. Springer, Berlin, pp 217--235",
"aggarwal2001": r"Aggarwal CC, Hinneburg A, Keim DA (2001) On the surprising behavior of distance metrics in high dimensional space. In: Database Theory --- ICDT 2001, Lecture Notes in Computer Science, vol 1973. Springer, Berlin, pp 420--434",
"malkov2020": r"Malkov YA, Yashunin DA (2020) Efficient and robust approximate nearest neighbor search using hierarchical navigable small world graphs. IEEE Transactions on Pattern Analysis and Machine Intelligence 42(4):824--836",
"woods1993": r"Woods K, Doss C, Bowyer K, Solka J, Priebe C, Kegelmeyer P (1993) Comparative evaluation of pattern recognition techniques for detection of microcalcifications in mammography. International Journal of Pattern Recognition and Artificial Intelligence 7(6):1417--1436",
"kubat1998": r"Kubat M, Holte RC, Matwin S (1998) Machine learning for the detection of oil spills in satellite radar images. Machine Learning 30(2--3):195--215",
"gower1971": r"Gower JC (1971) A general coefficient of similarity and some of its properties. Biometrics 27(4):857--871",
"wilson1997": r"Wilson DR, Martinez TR (1997) Improved heterogeneous distance functions. Journal of Artificial Intelligence Research 6:1--34",
}

src = sys.argv[1] if len(sys.argv) > 1 else "../manuscript/main.tex"
tex = open(src).read()
body = tex.split("\\begin{thebibliography}")[0]
order = []
for m in re.finditer(r"\\cite(?:\[[^\]]*\])?\{([^}]*)\}", body):
    for k in m.group(1).split(","):
        k = k.strip()
        if k not in order:
            order.append(k)
missing = [k for k in order if k not in REFS]
unused = [k for k in REFS if k not in order]
if missing:
    sys.exit(f"missing references: {missing}")
import json, os
_dp = os.path.join(os.path.dirname(os.path.abspath(__file__)), "dois_verified.json")
DOIS = json.load(open(_dp)) if os.path.exists(_dp) else {}


def entry(k, text, dois=DOIS):
    """reference text with its verified DOI (resolver link) at the end; entries without DOI keep the final full stop"""
    if k in dois and "doi.org" not in text:
        return text + (". Preprint: " if dois[k].startswith("10.48550/") else ". ") + "\\doi{" + dois[k] + "}"
    return text + "."


items = "\n".join(f"\\bibitem{{{k}}} {entry(k, REFS[k])}" for k in order)
start = tex.index("\\begin{thebibliography}{99}") + len("\\begin{thebibliography}{99}")
end = tex.index("\\end{thebibliography}")
tex = tex[:start] + "\n" + items + "\n" + tex[end:]
open(src, "w").write(tex)
print(f"{len(order)} references inserted; unused (dropped): {unused}")
