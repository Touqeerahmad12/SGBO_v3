"""Operating points of the application tasks (retrospective benchmark performance): sensitivity against
false-positive rate for the main methods, one panel per application, and the expected cost for several
false-negative/false-positive cost ratios."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from sgbo.protocol import RES

A = json.load(open(os.path.join(RES, "apps_summary.json")))
SHOW = ["None", "SMOTE", "SVM-SMOTE", "SMOTE-ENN", "BDO", "SGBO"]
MK = {"None": "X", "SMOTE": "o", "SVM-SMOTE": "D", "SMOTE-ENN": "s", "BDO": "^", "SGBO": "*"}
PANELS = [("bcancer-ir10", "Breast cancer (IR 10)"), ("bcancer-ir20", "Breast cancer (IR 20)"), ("mammography", "Mammography (IR 42)"),
          ("diabetes-top10", "Diabetes progression, top 10%"), ("diabetes-top5", "Diabetes progression, top 5%"), ("pima", "Pima diabetes diagnosis")]


def fig_apps():
    fig, axs = plt.subplots(2, 3, figsize=(6.9, 3.5))
    for ax, (app, ttl) in zip(axs.ravel(), PANELS):
        P = A["pooled"][app]
        for m in SHOW:
            ax.scatter(P[m]["fpr"], P[m]["tpr"], marker=MK[m], s=48 if m == "SGBO" else 26, color=COL[m], edgecolor="k", linewidths=0.4, zorder=5 if m == "SGBO" else 3, label=m)
        # iso-MCC is not a straight line; show the segment from None to SGBO (the operating-point shift)
        ax.annotate("", xy=(P["SGBO"]["fpr"], P["SGBO"]["tpr"]), xytext=(P["None"]["fpr"], P["None"]["tpr"]),
                    arrowprops=dict(arrowstyle="-|>", lw=0.5, color="#777777", shrinkA=3, shrinkB=4))
        ax.set_title(ttl, fontsize=7.8)
        ax.grid(alpha=0.25, lw=0.4)
        ax.set_xlabel("false-positive rate", fontsize=7)
        ax.tick_params(labelsize=6.5)
    for ax in axs[:, 0]:
        ax.set_ylabel("sensitivity", fontsize=7)
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=6, frameon=False, fontsize=6.8, bbox_to_anchor=(0.5, -0.025))
    fig.tight_layout(rect=(0, 0.04, 1, 1), h_pad=0.8, w_pad=0.4)
    save(fig, "fig_apps")


if __name__ == "__main__":
    fig_apps()
