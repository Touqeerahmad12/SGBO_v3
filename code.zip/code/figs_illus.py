"""Illustrative figures that need no benchmark results (written with the final sgbo package).

    python figs_illus.py [method] [known]

  method -> fig_method.pdf   score fields, move trajectories and the acceptance filter on a two-cluster example
  known  -> fig_known_visual.pdf  generated points of SMOTE / BDO / SGBO against the true model (class-conditional
            densities known): true Bayes boundary, true minority density, and the training data
"""
import _threads  # noqa: F401
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL, NEG, POS, NEW, ANC
import style
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from sgbo import SGBO, make_sampler
from sgbo.bdo import BDO
from sgbo.common import binary_entropy
from sgbo.datasets import two_cluster
from run_known import comps_logpdf, log_p1
from run_synthetic import sample, eta


def _fields(X, y):
    xs = np.linspace(-3.2, 3.4, 200); ys = np.linspace(-3.2, 3.2, 200)
    XX, YY = np.meshgrid(xs, ys); G = np.c_[XX.ravel(), YY.ravel()]
    k = int(y.sum())
    nb = NearestNeighbors(n_neighbors=k).fit(X).kneighbors(G, return_distance=False)
    f1 = binary_entropy(np.mean(y[nb] == 1, axis=1)).reshape(XX.shape)
    s = SGBO(); s.y_ = y; s.k_ = s._k(len(X), int(y.sum())); s.nn_ = NearestNeighbors().fit(X)
    f2 = binary_entropy(s.posterior(G)).reshape(XX.shape)
    return xs, ys, XX, YY, f1, f2, s.k_


def fig_method():
    X, y = two_cluster(n_neg=800, n_pos=40, seed=2)
    xs, ys, XX, YY, f1, f2, k = _fields(X, y)
    fig, axs = plt.subplots(2, 3, figsize=(6.9, 4.5), sharex=True, sharey=True)
    def base(ax, s_neg=2.5):
        ax.scatter(X[y == 0, 0], X[y == 0, 1], s=s_neg, c=NEG, edgecolors="none", alpha=0.7)
        ax.scatter(X[y == 1, 0], X[y == 1, 1], s=9, c=POS, edgecolors="k", linewidths=0.3, zorder=4)
    for ax, F, ttl in ((axs[0, 0], f1, r"(a) BDO degree, $k=n^+=40$"), (axs[0, 1], f2, rf"(b) SGBO score $b(x)$, $k={k}$")):
        im = ax.imshow(F, origin="lower", extent=[xs[0], xs[-1], ys[0], ys[-1]], cmap="YlOrRd", vmin=0, vmax=1, aspect="auto", interpolation="bilinear")
        ax.contour(XX, YY, F, levels=[0.5, 0.9], colors="k", linewidths=0.5, linestyles=["--", "-"])
        ax.scatter(X[y == 0, 0], X[y == 0, 1], s=2, c=NEG, edgecolors="none", alpha=0.7)
        ax.scatter(X[y == 1, 0], X[y == 1, 1], s=9, c=POS, edgecolors="k", linewidths=0.3)
        ax.set_title(ttl)
    # (c) SMOTE
    Xs, ys_ = make_sampler("SMOTE").fit_resample(X, y, np.random.default_rng(3))
    base(axs[0, 2]); axs[0, 2].scatter(Xs[len(X):, 0], Xs[len(X):, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none"); axs[0, 2].set_title("(c) SMOTE")
    # (d) BDO
    bdo = BDO(return_info=True); bi = bdo.fit_resample(X, y, np.random.default_rng(3))[2]
    base(axs[1, 0]); axs[1, 0].scatter(bi["new"][:, 0], bi["new"][:, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none")
    for a, b in zip(bi["seeds"], bi["aided"]):
        axs[1, 0].annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="-|>", lw=0.6, color=ANC, mutation_scale=5))
    axs[1, 0].scatter(bi["seeds"][:, 0], bi["seeds"][:, 1], s=7, facecolors="none", edgecolors=ANC, linewidths=0.5, zorder=5)
    axs[1, 0].set_title("(d) BDO: straight aided moves")
    # (e) SGBO paths, (f) acceptance filter
    s = SGBO(return_info=True, record=True); info = s.fit_resample(X, y, np.random.default_rng(3))[2]
    paths = np.stack(s.paths_)
    base(axs[1, 1]); axs[1, 1].scatter(info["new"][:, 0], info["new"][:, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none")
    for j in range(paths.shape[1]):
        axs[1, 1].plot(paths[:, j, 0], paths[:, j, 1], "-", color=ANC, lw=0.45, alpha=0.8)
    axs[1, 1].scatter(info["seeds"][:, 0], info["seeds"][:, 1], s=7, facecolors="none", edgecolors=ANC, linewidths=0.5, zorder=5)
    axs[1, 1].scatter(info["anchors"][:, 0], info["anchors"][:, 1], s=6, marker="x", c=ANC, linewidths=0.6, zorder=5)
    axs[1, 1].set_title("(e) SGBO: Langevin paths")
    base(axs[1, 2])
    rej = s.rejected_
    axs[1, 2].scatter(rej[:, 0], rej[:, 1], s=4, marker="x", c="#7f7f7f", linewidths=0.4, alpha=0.8, label=f"rejected ({len(rej)})", zorder=3)
    axs[1, 2].scatter(info["new"][:, 0], info["new"][:, 1], s=2.5, c=NEW, alpha=0.5, edgecolors="none", label=f"accepted ({len(info['new'])})", zorder=2)
    axs[1, 2].legend(frameon=True, loc="lower left", fontsize=6.5, borderpad=0.3, handletextpad=0.2)
    axs[1, 2].set_title(rf"(f) acceptance, $\theta={info['theta']:.2f}$")
    for ax in axs.ravel():
        ax.set_xlim(-3.3, 3.4); ax.set_ylim(-3.2, 3.3)
    for ax in axs[1]:
        ax.set_xlabel(r"$x_1$")
    for ax in axs[:, 0]:
        ax.set_ylabel(r"$x_2$")
    fig.tight_layout(h_pad=0.4, w_pad=0.3)
    fig.colorbar(im, ax=axs[0, :2], fraction=0.03, pad=0.01, label="boundary score")
    save(fig, "fig_method")
    return dict(k=k, n_rej=len(rej), n_new=len(info["new"]), theta=info["theta"], h=info["h"])


def fig_known_visual(seed=11):
    cfgs = [dict(s=2.0, ir=10, n=1000, lab=r"$s=2$, IR$\,=\,$10"), dict(s=1.2, ir=30, n=1500, lab=r"$s=1.2$, IR$\,=\,$30")]
    names = ["SMOTE", "MWMOTE", "BDO", "SGBO"]
    fig, axs = plt.subplots(len(cfgs), len(names), figsize=(6.9, 3.5 * len(cfgs) / 2 + 0.2), sharex=True, sharey=True)
    xs = np.linspace(-3.4, 4.0, 220); ys = np.linspace(-3.0, 3.6, 220); XX, YY = np.meshgrid(xs, ys); G = np.c_[XX.ravel(), YY.ravel()]
    for r, cfg in enumerate(cfgs):
        rng = np.random.default_rng(seed + r)
        X, yv = sample(cfg["n"], cfg["s"], cfg["ir"], 0, rng)
        while yv.sum() < 12:
            X, yv = sample(cfg["n"], cfg["s"], cfg["ir"], 0, rng)
        sc = StandardScaler().fit(X); Z = sc.transform(X)
        et = eta(G, cfg["s"], cfg["ir"]).reshape(XX.shape)
        lp = log_p1(G, cfg["s"], 0).reshape(XX.shape)
        for c, nm in enumerate(names):
            ax = axs[r, c]
            smp = make_sampler(nm)
            Xr, yr = smp.fit_resample(Z, yv, np.random.default_rng(5))
            new = sc.inverse_transform(Xr[len(Z):])
            ax.contour(XX, YY, lp, levels=[np.log(0.02), np.log(0.1)], colors="#6b8e23", linewidths=0.6, linestyles=[":", "-"])
            ax.contour(XX, YY, et, levels=[0.5], colors="k", linewidths=0.9)
            ax.scatter(X[yv == 0, 0], X[yv == 0, 1], s=1.5, c=NEG, edgecolors="none", alpha=0.55)
            ax.scatter(new[:, 0], new[:, 1], s=4, c=NEW, edgecolors="none", alpha=0.6)
            ax.scatter(X[yv == 1, 0], X[yv == 1, 1], s=7, c=POS, edgecolors="k", linewidths=0.25, zorder=4)
            ax.set_xlim(-3.4, 4.0); ax.set_ylim(-3.0, 3.6)
            if r == 0:
                ax.set_title(nm)
            if r == len(cfgs) - 1:
                ax.set_xlabel(r"$x_1$")
        axs[r, 0].set_ylabel(cfg["lab"] + "\n" + r"$x_2$")
    fig.tight_layout(h_pad=0.3, w_pad=0.2)
    save(fig, "fig_known_visual")


if __name__ == "__main__":
    which = sys.argv[1:] or ["method", "known"]
    if "folder" in which:
        pass
    import json
    if "method" in which:
        info = fig_method(); print(info)
        json.dump({k: float(v) for k, v in info.items()}, open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results", "illus_summary.json"), "w"))
    if "known" in which:
        fig_known_visual(); print("known visual")
