"""Figures of the mechanism-level studies on the known model (results/known_summary.json, known_*.csv)."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from sgbo.protocol import RES

K = json.load(open(os.path.join(RES, "known_summary.json")))
RD = lambda f: pd.read_csv(os.path.join(RES, f), keep_default_na=False, na_values=[""])

RULE_STY = {
    "BDO (k=n+, uniform)": ("BDO degree ($k=n^+$)", COL["BDO"], "o", "-"),
    "k=n+, weighted": (r"$k=n^+$, weighted", "#c9a16b", "v", ":"),
    "k=5, uniform": (r"$k=5$, uniform", "#6f9a6e", "s", "--"),
    "k=sqrt(n), uniform": (r"$k=\lceil\sqrt{n}\rceil$, uniform", "#5f86a6", "D", "--"),
    "SGBO (k=sqrt(n), weighted)": ("SGBO score", COL["SGBO"], "^", "-"),
}


def fig_consistency():
    C = K["consistency"]
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.5), sharey=True)
    for ax, q, ttl in ((axs[0], 0, "(a) two relevant features"), (axs[1], 8, "(b) plus 8 irrelevant features")):
        for rule, v in C[f"q{q}_mae_b"].items():
            lab, c, mk, ls = RULE_STY[rule]
            n = np.array(v["n"]); m = np.array(v["mean"]); se = np.array(v["se"])
            sl = C[f"q{q}_slope_mae_b"][rule]["slope"]
            ax.plot(n, m, ls, color=c, marker=mk, ms=3.5, lw=1.1, label=f"{lab} ({sl:+.2f})")
            ax.fill_between(n, m - 2 * se, m + 2 * se, color=c, alpha=0.15, lw=0)
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel(r"training size $n$"); ax.set_title(ttl)
        ax.set_ylim(0.0095, 0.3); ax.grid(alpha=0.25, lw=0.4, which="both"); ax.legend(frameon=False, fontsize=6.1, loc="lower left", title="rule (log-log slope)", title_fontsize=6.1, labelspacing=0.25)
    axs[0].set_ylabel(r"mean $|\hat b(x)-H_2(\eta(x))|$")
    fig.tight_layout(w_pad=0.5)
    save(fig, "fig_consistency")


ABL_ORDER = ["k = n+ (no adaptive k)", "uniform weights", "k = n+, uniform (BDO score)", "uniform seeds", "uniform allocation",
             "sigma-rule seeds, uniform alloc.", "no movement", "BDO movement", "no noise (tau=0)", "no shrinkage", "no acceptance test"]
ABL_LAB = {"k = n+ (no adaptive k)": r"fixed $k=n^+$", "uniform weights": "uniform weights", "k = n+, uniform (BDO score)": "BDO score (both)",
           "uniform seeds": "uniform seeds", "uniform allocation": "uniform allocation", "sigma-rule seeds, uniform alloc.": r"$\sigma$-rule seeds",
           "no movement": "no movement", "BDO movement": "BDO movement", "no noise (tau=0)": r"no noise ($\tau=0$)",
           "no shrinkage": "no shrinkage", "no acceptance test": "no acceptance test"}
COND_ORDER = ["small n (n=300)", "base", "large n (n=8000, IR 20)", "extreme IR (100)", "overlap (s=1)", "label noise (10%)", "high dim (d=40)"]
COND_LAB = {"small n (n=300)": "small $n$\n(300)", "base": "base", "large n (n=8000, IR 20)": "large $n$\n(8000)", "extreme IR (100)": "IR\n100",
            "overlap (s=1)": "strong\noverlap", "label noise (10%)": "10%\nlabel noise", "high dim (d=40)": "$d=40$"}


def fig_ablation():
    A = K["ablation"]
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.4), sharey=True)
    for ax, met, ttl in ((axs[0], "mcc", r"(a) MCC benefit ($\times 100$)"), (axs[1], "aucpr", r"(b) AUC-PR benefit ($\times 100$)")):
        M = np.array([[-A[met][c][v]["mean"] * 100 for c in COND_ORDER] for v in ABL_ORDER])
        P = np.array([[A[met][c][v]["p_holm"] for c in COND_ORDER] for v in ABL_ORDER])
        lim = 4.0
        im = ax.imshow(np.clip(M, -lim, lim), cmap="RdBu", vmin=-lim, vmax=lim, aspect="auto")
        for i in range(M.shape[0]):
            for j in range(M.shape[1]):
                s = f"{M[i, j]:+.1f}" if abs(M[i, j]) < 10 else f"{M[i, j]:+.0f}"
                ax.text(j, i, s + ("*" if P[i, j] < 0.05 else ""), ha="center", va="center", fontsize=6.2,
                        color="white" if abs(M[i, j]) > 2.6 else "black", fontweight="bold" if P[i, j] < 0.05 else "normal")
        ax.set_xticks(range(len(COND_ORDER))); ax.set_xticklabels([COND_LAB[c] for c in COND_ORDER], fontsize=6.3)
        ax.set_yticks(range(len(ABL_ORDER))); ax.set_yticklabels([ABL_LAB[v] for v in ABL_ORDER], fontsize=7)
        ax.set_title(ttl)
        ax.tick_params(length=0)
    fig.tight_layout(w_pad=0.5)
    fig.colorbar(im, ax=axs, fraction=0.025, pad=0.015, label="full SGBO minus variant (blue: component helps)")
    save(fig, "fig_ablation")


def fig_shrink_langevin():
    S = K["shrink_median"]; P = K["shrink_perf"]["mcc"]
    dims = sorted(int(k) for k in S)
    sty = {"LW + floor (default)": (COL["SGBO"], "o", "-", "Ledoit-Wolf (default)"),
           "no shrinkage": ("#555555", "s", "--", "no shrinkage"),
           "rho = 0.05": ("#5f86a6", "^", "-.", r"fixed $\rho=0.05$"),
           "rho = 0.5": ("#6f9a6e", "v", ":", r"fixed $\rho=0.5$")}
    fig, axs = plt.subplots(1, 4, figsize=(6.9, 2.25))
    for v, (c, mk, ls, lab) in sty.items():
        cond = np.array([S[str(d)][v]["cond_med"] if str(d) in S else np.nan for d in dims], float)
        axs[0].plot(dims, np.where(np.isfinite(cond), cond, np.nan), ls, color=c, marker=mk, ms=3, lw=1.1, label=lab)
        if v == "no shrinkage":
            inf_d = [d for d, cv in zip(dims, cond) if not np.isfinite(cv)]
            axs[0].plot(inf_d, [2e8] * len(inf_d), "x", color=c, ms=5, label="singular (rank-deficient)")
        diff = [P[str(d)][v].get("diff_vs_default", 0.0) if v != "LW + floor (default)" else 0.0 for d in dims]
        axs[1].plot(dims, np.array(diff) * 100, ls, color=c, marker=mk, ms=3, lw=1.1)
    axs[0].set_yscale("log"); axs[0].set_xscale("log"); axs[0].set_ylim(0.8, 1e9)
    axs[0].set_xlabel("dimension $d$"); axs[0].set_ylabel("median condition number"); axs[0].set_title("(a) conditioning")
    axs[1].set_xscale("log"); axs[1].axhline(0, color="k", lw=0.5); axs[1].set_xlabel("dimension $d$"); axs[1].set_ylabel(r"$\Delta$MCC vs default ($\times100$)"); axs[1].set_title("(b) classification")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=5, frameon=False, fontsize=6.5, bbox_to_anchor=(0.3, -0.07))
    # Langevin
    L = K.get("langevin")
    if L:
        taus = sorted(float(t) for t in L["paired_struct"]["div_nn"]["mean"])
        for ax, key, ttl, yl in ((axs[2], "div_nn", "(c) diversity", "median NN distance"),
                                 (axs[3], "bnd_cov", "(d) coverage of boundary", "boundary coverage")):
            m = L["paired_struct"][key]["mean"]
            ax.plot(range(len(taus)), [m[str(t)] if str(t) in m else m[repr(t)] for t in taus], "-o", color=COL["SGBO"], ms=3, lw=1.1)
            ax.set_xticks(range(len(taus))); ax.set_xticklabels([f"{t:g}" for t in taus]); ax.set_xlabel(r"temperature $\tau$"); ax.set_title(ttl); ax.set_ylabel(yl, fontsize=7)
            ax.grid(alpha=0.25, lw=0.4)
    fig.tight_layout(w_pad=0.4)
    save(fig, "fig_shrink_langevin")


if __name__ == "__main__":
    which = sys.argv[1:] or ["consistency", "ablation", "shrink"]
    if "consistency" in which: fig_consistency()
    if "ablation" in which: fig_ablation()
    if "shrink" in which: fig_shrink_langevin()
