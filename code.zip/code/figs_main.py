"""Figures of the benchmark results (heatmap, radar, effect sizes, network of critical differences, imbalance, flows)."""
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style
from style import plt, COL, MLAB
from analysis_main import load
from sgbo.stats import unit_matrix, friedman, METHODS, CLFS
import networkx as nx

RES = "../results"
OUT = style.FIG
SHORT = {"None": "None", "ROS": "ROS", "SMOTE": "SMOTE", "B-SMOTE": "B-SMOTE", "ADASYN": "ADASYN",
         "SVM-SMOTE": "SVM-SM", "SMOTE-ENN": "SM-ENN", "KM-SMOTE": "KM-SM", "MWMOTE": "MWMOTE",
         "CCR": "CCR", "BDO": "BDO", "SGBO": "SGBO"}
LINE = ["None", "SMOTE", "B-SMOTE", "SVM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MK = {"None": "x", "SMOTE": "o", "B-SMOTE": "s", "SVM-SMOTE": "D", "MWMOTE": "v", "CCR": "P", "BDO": "^", "SGBO": "*"}


def save(fig, name):
    style.save(fig, name, OUT)


# ---------------------------------------------------------------------------- F5
def fig_heatmap(df, metric="mcc"):
    M = unit_matrix(df, metric)
    from sgbo.datasets import task_registry
    order = []
    for t in task_registry(include_new=True):
        if t["source"] not in order:
            order.append(t["source"])
    M = M.loc[[o for o in order if o in M.index]]
    R = M.rank(axis=1, ascending=False)
    fig, ax = plt.subplots(figsize=(6.9, 5.6))
    im = ax.imshow(M.values, cmap="RdYlBu_r", aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{M.values[i, j]:.2f}", ha="center", va="center", fontsize=5.6)
            if R.values[i, j] == 1:
                ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fill=False, ec="k", lw=0.9))
    ax.set_xticks(range(M.shape[1])); ax.set_xticklabels([SHORT[m] for m in M.columns], rotation=35, ha="right", fontsize=7)
    ax.set_yticks(range(M.shape[0])); ax.set_yticklabels(M.index, fontsize=6.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.015); cb.set_label(f"mean {MLAB[metric]} per source (4 classifiers)")
    save(fig, "fig_heatmap")
    return M


# ---------------------------------------------------------------------------- F6
def fig_classifier_ranks(df):
    fig, axs = plt.subplots(2, 1, figsize=(6.9, 3.9), sharex=True)
    shades = {"RF": "#3b3b3b", "SVM": "#7a7a7a", "kNN": "#b0b0b0", "LR": "#dcdcdc"}
    hatch = {"RF": "", "SVM": "///", "kNN": "...", "LR": "xx"}
    x = np.arange(len(METHODS)); w = 0.2
    out = {}
    for ax, met in zip(axs, ["mcc", "aucpr"]):
        for i, c in enumerate(CLFS):
            r = friedman(unit_matrix(df, met, clf=c))["ranks"]
            out[(met, c)] = r
            vals = [r[m] for m in METHODS]
            bars = ax.bar(x + (i - 1.5) * w, vals, w, color=shades[c], edgecolor="k", lw=0.35, hatch=hatch[c], label=c)
            bars[-1].set_facecolor(COL["SGBO"]); bars[-1].set_alpha(0.45 + 0.15 * i)
        ax.set_ylabel(f"avg. rank ({MLAB[met]})"); ax.grid(axis="y", alpha=0.3, lw=0.4)
        ax.axhline((len(METHODS) + 1) / 2, color="k", lw=0.5, ls=":")
    axs[1].set_xticks(x); axs[1].set_xticklabels([SHORT[m] for m in METHODS], fontsize=7)
    axs[0].legend(ncol=4, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.28), fontsize=7)
    save(fig, "fig_classifier_ranks")
    return out


# ---------------------------------------------------------------------------- F7
def fig_radar(df):
    ms = ["aucpr", "mcc", "f1", "gmean", "auc"]
    show = ["SMOTE", "B-SMOTE", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    means = {m: unit_matrix(df, m).mean() for m in ms}
    ang = np.linspace(0, 2 * np.pi, len(ms), endpoint=False).tolist(); ang += ang[:1]
    fig = plt.figure(figsize=(6.6, 2.9))
    for p, (title, norm) in enumerate(((f"(a) mean over {len(unit_matrix(df, 'mcc'))} sources", False), ("(b) min--max normalised", True))):
        ax = fig.add_subplot(1, 2, p + 1, polar=True)
        for k in show:
            v = []
            for m in ms:
                sv = means[m][show]; val = means[m][k]
                v.append((val - sv.min()) / (sv.max() - sv.min() + 1e-12) if norm else val)
            v += v[:1]
            ax.plot(ang, v, color=COL[k], lw=1.6 if k == "SGBO" else 0.9, label=SHORT[k],
                    ls="-" if k in ("SGBO", "BDO") else "--")
            if k == "SGBO":
                ax.fill(ang, v, color=COL[k], alpha=0.15)
        ax.set_xticks(ang[:-1]); ax.set_xticklabels([MLAB[m] for m in ms], fontsize=7.5)
        ax.tick_params(axis="y", labelsize=6); ax.set_title(title, pad=12)
        if norm:
            ax.set_ylim(0, 1.05); ax.set_yticks([0.25, 0.5, 0.75, 1.0])
        else:
            lo = min(means[m][show].min() for m in ms); ax.set_ylim(lo - 0.08, None)
    fig.legend(*ax.get_legend_handles_labels(), loc="lower center", ncol=8, frameon=False, bbox_to_anchor=(0.5, -0.06), fontsize=6.8)
    save(fig, "fig_radar")


# ---------------------------------------------------------------------------- F8
def fig_effects(df, stats_all):
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.9), sharey=False)
    comp = [m for m in METHODS if m != "SGBO"]
    for ax, met in zip(axs, ["mcc", "aucpr"]):
        M = unit_matrix(df, met)
        D = [(M["SGBO"] - M[m]).values for m in comp]
        bp = ax.boxplot(D, widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color="k", lw=0.9),
                        boxprops=dict(lw=0.5), whiskerprops=dict(lw=0.5), capprops=dict(lw=0.5))
        for patch, m in zip(bp["boxes"], comp):
            patch.set_facecolor(COL[m]); patch.set_alpha(0.55)
        rng = np.random.default_rng(0)
        for i, d in enumerate(D):
            ax.scatter(i + 1 + rng.uniform(-0.17, 0.17, len(d)), d, s=2.5, c="k", alpha=0.45, lw=0, zorder=3)
            ph = stats_all[met]["posthoc"][comp[i]]
            ax.errorbar(i + 1.32, ph["mean"], yerr=[[ph["mean"] - ph["ci_lo"]], [ph["ci_hi"] - ph["mean"]]],
                        fmt="D", ms=2.8, color=COL["SGBO"], lw=0.9, capsize=1.5, zorder=4)
            if ph["reject"]:
                ax.text(i + 1, ax.get_ylim()[1] if False else max(d.max(), ph["ci_hi"]) + 0.01, "*", ha="center", fontsize=8)
        ax.axhline(0, color="k", lw=0.6, ls="--")
        ax.set_xticks(range(1, len(comp) + 1)); ax.set_xticklabels([SHORT[m] for m in comp], rotation=55, ha="right", fontsize=6.5)
        ax.set_title(f"({'a' if met == 'mcc' else 'b'}) $\\Delta${MLAB[met]} = SGBO $-$ method"); ax.grid(axis="y", alpha=0.3, lw=0.4)
    save(fig, "fig_effects")


# ---------------------------------------------------------------------------- F9
def fig_network(df):
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.1))
    out = {}
    for ax, met, ttl in ((axs[0], "mcc", "(a) MCC"), (axs[1], "aucpr", "(b) AUC-PR")):
        fr = friedman(unit_matrix(df, met)); cd, r = fr["cd"], fr["ranks"]
        # directed edge A -> B: A has a lower (better) mean rank than B by more than the Nemenyi CD
        G = nx.DiGraph(); G.add_nodes_from(METHODS)
        for a in METHODS:
            for b in METHODS:
                if r[b] - r[a] > cd:
                    G.add_edge(a, b)
        srt = sorted(METHODS, key=lambda k: r[k])
        ang = np.linspace(np.pi / 2, np.pi / 2 - 2 * np.pi, len(srt), endpoint=False)
        pos = {k: (np.cos(a), np.sin(a)) for k, a in zip(srt, ang)}
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#555555", width=0.7, arrows=True, arrowsize=6,
                               arrowstyle="-|>", node_size=300, connectionstyle="arc3,rad=0.08")
        sizes = [420 * (fr["k"] + 1 - r[k]) / fr["k"] for k in METHODS]
        nx.draw_networkx_nodes(G, pos, ax=ax, nodelist=METHODS, node_size=sizes, node_color=[COL[k] for k in METHODS],
                               edgecolors="k", linewidths=0.5)
        for k, (x, y) in pos.items():
            ha = "left" if x > 0.2 else ("right" if x < -0.2 else "center")
            ax.text(1.2 * x + (0.06 if x > 0.2 else -0.06 if x < -0.2 else 0), (1.22 if abs(x) > 0.2 else 1.34) * y,
                    f"{SHORT[k]} ({r[k]:.2f})", ha=ha, va="center", fontsize=6.3)
        ax.set_xlim(-2.1, 2.1); ax.set_ylim(-1.5, 1.5); ax.set_aspect("equal"); ax.axis("off")
        ax.set_title(f"{ttl}: CD = {cd:.2f}")
        out[met] = dict(cd=cd, ranks=r)
    save(fig, "fig_network")
    return out


# ---------------------------------------------------------------------------- F10
def fig_ir(df):
    from sgbo.datasets import task_registry
    IR = {t["name"]: (len(t["y"]) - t["y"].sum()) / t["y"].sum() for t in task_registry()}
    t = df.groupby(["dataset", "method"])["mcc"].mean().unstack()
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.7), gridspec_kw=dict(width_ratios=[1.1, 1]))
    ax = axs[0]
    for comp, mk in (("SVM-SMOTE", "D"), ("SMOTE", "o"), ("BDO", "^")):
        d = (t["SGBO"] - t[comp]); x = np.array([IR[k] for k in d.index])
        ax.scatter(x, d.values, s=10, marker=mk, color=COL[comp], alpha=0.75, label=f"SGBO $-$ {SHORT[comp]}", lw=0.3, edgecolors="k")
        o = np.argsort(x); lx = np.log(x[o]); yy = d.values[o]
        # running median over IR (window of 9 tasks)
        med = [np.median(yy[max(0, i - 4):i + 5]) for i in range(len(yy))]
        ax.plot(x[o], med, "-", color=COL[comp], lw=1.1)
    ax.axhline(0, color="k", lw=0.6, ls="--"); ax.set_xscale("log"); ax.set_xlabel("imbalance ratio (task)")
    ax.set_ylabel(r"$\Delta$MCC"); ax.set_title("(a) difference per task (lines: running median)"); ax.legend(frameon=False, fontsize=6.3)
    ax.grid(alpha=0.25, lw=0.4)
    ax = axs[1]
    bins = [(0, 3, "IR$<$3"), (3, 10, "3--10"), (10, 20, "10--20"), (20, 1e9, "$>$20")]
    show = ["SMOTE", "SVM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    res = {}
    for lo, hi, lab in bins:
        names = [k for k in t.index if lo <= IR[k] < hi]
        sub = df[df.dataset.isin(names)]
        M = sub.groupby(["dataset", "clf", "method"])["mcc"].mean().groupby(["dataset", "method"]).mean().unstack()[METHODS]
        rk = M.rank(axis=1, ascending=False).mean()
        res[lab] = (len(names), rk)
    xs = np.arange(len(bins))
    for m in show:
        ax.plot(xs, [res[b[2]][1][m] for b in bins], "-", marker=MK.get(m, "o"), color=COL[m], lw=1.5 if m == "SGBO" else 0.9,
                ms=5 if m == "SGBO" else 3.5, label=SHORT[m])
    ax.set_xticks(xs); ax.set_xticklabels([f"{b[2]}\n({res[b[2]][0]} tasks)" for b in bins], fontsize=6.8)
    ax.invert_yaxis(); ax.set_ylabel("avg. rank (MCC)"); ax.set_title("(b) rank by imbalance group (descriptive)")
    ax.grid(alpha=0.25, lw=0.4); ax.legend(frameon=False, fontsize=6, ncol=2)
    save(fig, "fig_imbalance")
    return {k: (v[0], v[1].round(2).to_dict()) for k, v in res.items()}


# ---------------------------------------------------------------------------- F12
def _band(ax, x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.45):
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path
    xm = (x0 + x1) / 2
    verts = [(x0, y0a), (xm, y0a), (xm, y1a), (x1, y1a), (x1, y1b), (xm, y1b), (xm, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), fc=color, ec="none", alpha=alpha))


def sankey(ax, columns, flows, colors, title, width=0.07, gap=0.035):
    columns = [[(n, v) for n, v in col if v > 0] for col in columns]
    flows = [f for f in flows if f[2] > 0]
    tot = max(sum(v for _, v in col) for col in columns)
    pos = {}; xs = np.linspace(0, 1, len(columns))
    for ci, col in enumerate(columns):
        n = len(col); scale = (1 - gap * (n - 1)) / tot
        y = 1 - (1 - (sum(v for _, v in col) * scale + gap * (n - 1))) / 2
        for name, v in col:
            h = v * scale
            pos[name] = dict(x=xs[ci], out=y, inn=y, scale=scale)
            ax.add_patch(plt.Rectangle((xs[ci] - width / 2, y - h), width, h, fc=colors.get(name, "#555"), ec="k", lw=0.4, zorder=3))
            last = ci == len(columns) - 1
            ax.text(xs[ci] + (-width / 2 - 0.01 if last else width / 2 + 0.01), y - h / 2, f"{name}\n{v:,}",
                    ha="right" if last else "left", va="center", fontsize=5.6, zorder=4,
                    bbox=dict(fc="white", ec="none", alpha=0.7, pad=0.5))
            y -= h + gap
    for s_, d_, v in flows:
        ps, pd_ = pos[s_], pos[d_]
        hs, hd = v * ps["scale"], v * pd_["scale"]
        _band(ax, ps["x"] + width / 2, ps["out"], ps["out"] - hs, pd_["x"] - width / 2, pd_["inn"], pd_["inn"] - hd, colors.get(d_, "#888"))
        ps["out"] -= hs; pd_["inn"] -= hd
    ax.set_xlim(-0.06, 1.06); ax.set_ylim(-0.02, 1.02); ax.axis("off"); ax.set_title(title, fontsize=7.6)




def fig_summary(df):
    """Radar of the min-max normalised metric means (a) and critical-difference networks for MCC and AUC-PR (b, c)."""
    ms = ["aucpr", "mcc", "f1", "gmean", "auc"]
    show = ["SMOTE", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    means = {m: unit_matrix(df, m).mean() for m in ms}
    ang = np.linspace(0, 2 * np.pi, len(ms), endpoint=False).tolist(); ang += ang[:1]
    fig = plt.figure(figsize=(6.9, 2.9))
    gs = fig.add_gridspec(1, 3, width_ratios=[0.8, 1.1, 1.1], wspace=0.1)
    ax = fig.add_subplot(gs[0], projection="polar")
    for k in show:
        v = []
        for m in ms:
            sv = means[m][show]
            v.append((means[m][k] - sv.min()) / (sv.max() - sv.min() + 1e-12))
        v += v[:1]
        ax.plot(ang, v, color=COL[k], lw=1.6 if k == "SGBO" else 0.9, label=SHORT[k], ls="-" if k in ("SGBO", "BDO") else "--")
        if k == "SGBO":
            ax.fill(ang, v, color=COL[k], alpha=0.12)
    ax.set_xticks(ang[:-1]); ax.set_xticklabels([MLAB[m] for m in ms], fontsize=6.5); ax.tick_params(axis="x", pad=-2)
    ax.set_ylim(0, 1.05); ax.set_yticks([0.25, 0.5, 0.75, 1.0]); ax.set_yticklabels(["", "", "", ""]); ax.set_title("(a) normalised means", pad=11, fontsize=8.5)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.1), ncol=3, frameon=False, fontsize=5.8, columnspacing=0.8, handlelength=1.4)
    out = {}
    for j, (met, ttl) in enumerate((("mcc", "(b) MCC"), ("aucpr", "(c) AUC-PR"))):
        ax = fig.add_subplot(gs[j + 1])
        fr = friedman(unit_matrix(df, met)); cd, r = fr["cd"], fr["ranks"]
        G = nx.DiGraph(); G.add_nodes_from(METHODS)
        for a in METHODS:
            for b in METHODS:
                if r[b] - r[a] > cd:
                    G.add_edge(a, b)
        srt = sorted(METHODS, key=lambda k: r[k])
        angs = np.linspace(np.pi / 2, np.pi / 2 - 2 * np.pi, len(srt), endpoint=False)
        pos = {k: (np.cos(a), np.sin(a)) for k, a in zip(srt, angs)}
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#555555", width=0.6, arrows=True, arrowsize=5, arrowstyle="-|>", node_size=220,
                               connectionstyle="arc3,rad=0.08")
        sizes = [190 * (fr["k"] + 1 - r[k]) / fr["k"] for k in METHODS]
        nx.draw_networkx_nodes(G, pos, ax=ax, nodelist=METHODS, node_size=sizes, node_color=[COL[k] for k in METHODS], edgecolors="k", linewidths=0.5)
        for k, (x, y) in pos.items():
            ha = "left" if x > 0.2 else ("right" if x < -0.2 else "center")
            ax.text(1.28 * x + (0.05 if x > 0.2 else -0.05 if x < -0.2 else 0), (1.28 if abs(x) > 0.2 else 1.36) * y,
                    f"{SHORT[k]} ({r[k]:.1f})", ha=ha, va="center", fontsize=5.6)
        ax.set_xlim(-2.3, 2.3); ax.set_ylim(-1.55, 1.55); ax.set_aspect("equal"); ax.axis("off")
        ax.set_title(f"{ttl}, CD = {cd:.2f}", fontsize=8.5)
        out[met] = dict(cd=cd, ranks=r, edges=[list(e) for e in G.edges])
    save(fig, "fig_summary")
    return out


if __name__ == "__main__":
    import json
    df = load()
    st = json.load(open(f"{RES}/stats_main.json"))["all_tasks"]
    which = sys.argv[1:] or ["heatmap", "summary", "effects", "ranks", "ir"]
    out = {}
    if "heatmap" in which: fig_heatmap(df)
    if "radar" in which: fig_radar(df)
    if "summary" in which: out["summary"] = fig_summary(df)
    if "network" in which: out["network"] = fig_network(df)
    if "effects" in which: fig_effects(df, st)
    if "ranks" in which: out["ranks"] = {f"{k[0]}_{k[1]}": v for k, v in fig_classifier_ranks(df).items()}
    if "ir" in which: out["ir_groups"] = fig_ir(df)
    json.dump(out, open(f"{RES}/fig_main_summary.json", "w"), indent=1, default=float)
