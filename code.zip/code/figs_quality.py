"""Quality of the synthetic samples: (a, b) known model against the true distribution; (c) benchmark tasks,
excess of 'deep' synthetic points over held-out real minority points; (d) Sankey of the fate of SGBO's candidates."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from sgbo.protocol import RES
from figs_main import sankey

K = json.load(open(os.path.join(RES, "known_summary.json")))["quality"]
SHOW = ["ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MK = {"ROS": "x", "SMOTE": "o", "B-SMOTE": "v", "ADASYN": "P", "SVM-SMOTE": "D", "KM-SMOTE": "s", "MWMOTE": "<", "CCR": ">", "BDO": "^", "SGBO": "*"}
LAB = {"KM-SMOTE": "$k$M-SM", "SVM-SMOTE": "SVM-SM", "B-SMOTE": "B-SM"}
CONDS = ["base", "separated (s=3)", "IR 50", "label noise (10%)", "high dim (d=10)", "high dim (d=40)"]
CL = ["base", "$s{=}3$", "IR 50", "noise", "$d{=}10$", "$d{=}40$"]


def fig_quality():
    qt = os.path.join(RES, "quality_tasks.csv")
    have = os.path.exists(qt)
    fig, axs = plt.subplots(2, 2, figsize=(6.9, 4.6))
    # (a) fidelity/coverage against the true model, base condition
    ax = axs[0, 0]
    for m in SHOW:
        r = K["base"][m]
        ax.scatter(r["rec_true"], r["prec_true"], marker=MK[m], s=70 if m == "SGBO" else 28, color=COL[m], edgecolor="k", linewidths=0.4, zorder=5 if m == "SGBO" else 3)
        off = {"SGBO": (5, -9), "ADASYN": (-6, 5), "SVM-SMOTE": (4, 3)}.get(m, (4, 3))
        ax.annotate(LAB.get(m, m), (r["rec_true"], r["prec_true"]), textcoords="offset points", xytext=off, fontsize=5.8, ha="right" if m == "ADASYN" else "left")
    ax.set_xlabel("recall against the true minority law (coverage)"); ax.set_ylabel("precision (fidelity)")
    ax.set_title("(a) known model, base setting"); ax.grid(alpha=0.25, lw=0.4)
    # (b) boundary coverage across conditions
    ax = axs[0, 1]
    x = np.arange(len(CONDS))
    for m in SHOW:
        y = [K[c][m]["bnd_cov"] for c in CONDS]
        ax.plot(x, y, "-", marker=MK[m], color=COL[m], lw=1.8 if m == "SGBO" else 0.7, ms=6 if m == "SGBO" else 3, label=LAB.get(m, m), zorder=5 if m == "SGBO" else 2)
    ax.set_xticks(x); ax.set_xticklabels(CL, fontsize=6.8); ax.set_ylabel(r"coverage of the band $0.3\leq\eta\leq0.7$")
    ax.set_title("(b) boundary coverage, known model"); ax.grid(alpha=0.25, lw=0.4)
    hb, lb = ax.get_legend_handles_labels()
    if have:
        q = pd.read_csv(qt, keep_default_na=False, na_values=[""])
        u = q.groupby(["source", "dataset", "method"])["nn_ratio"].mean().groupby(["source", "method"]).mean().unstack()
        order = [m for m in SHOW if m in u.columns and m != "ROS"]
        ax = axs[1, 0]
        bp = ax.boxplot([u[m].dropna().values for m in order], orientation="vertical", patch_artist=True, widths=0.6, showfliers=True,
                        flierprops=dict(marker=".", ms=2.5), medianprops=dict(color="k", lw=0.9), whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6), boxprops=dict(lw=0.6))
        for b, m in zip(bp["boxes"], order):
            b.set_facecolor(COL[m]); b.set_alpha(0.85)
        ax.axhline(1, color="k", lw=0.6, ls="--"); ax.set_yscale("log"); ax.set_ylim(0.05, 20)
        ax.set_xticks(range(1, len(order) + 1)); ax.set_xticklabels([LAB.get(m, m) for m in order], rotation=40, ha="right", fontsize=6.3)
        ax.set_ylabel("spacing relative to held-out points")
        ax.set_title("(c) benchmark: spacing of new points"); ax.grid(alpha=0.25, lw=0.4, axis="y")
        # (d) Sankey: fate of the candidates of SGBO, grouped by imbalance ratio
        s = q[q.method == "SGBO"].copy()
        s["A"] = s.n_new * (1 - s.fill_share); s["F"] = s.n_new * s.fill_share
        s["C"] = s.A / (1 - s.rej_share).clip(lower=1e-6); s["R"] = (s.C - s.A).clip(lower=0)
        s["g"] = pd.cut(s.ir, [0, 5, 15, 1e9], labels=["IR$<$5", "IR 5--15", "IR$>$15"])
        g = s.groupby("g", observed=True)[["A", "R", "F", "C"]].sum()
        Rd = {k: int(round(g.loc[k, "R"])) for k in g.index}
        cols = [[(str(k), int(round(g.loc[k, "C"]))) for k in g.index],
                [("accepted", int(round(g.A.sum()))), ("rejected", int(round(g.R.sum())))],
                [("kept", int(round(g.A.sum()))), ("fallback", int(round(g.F.sum()))), ("discarded", int(round(max(g.R.sum() - g.F.sum(), 0))))]]
        flows = []
        for k in g.index:
            flows += [(str(k), "accepted", int(round(g.loc[k, "A"]))), (str(k), "rejected", int(round(g.loc[k, "R"])))]
        flows += [("accepted", "kept", int(round(g.A.sum()))), ("rejected", "fallback", int(round(g.F.sum()))), ("rejected", "discarded", int(round(max(g.R.sum() - g.F.sum(), 0))))]
        colors = {"IR$<$5": "#9bb79a", "IR 5--15": "#7f9fb8", "IR$>$15": "#8e7cc3", "accepted": "#6f9a6e", "rejected": "#c2a878", "kept": "#6f9a6e", "fallback": "#d08c3c", "discarded": "#aaaaaa"}
        sankey(axs[1, 1], cols, flows, colors, "(d) fate of SGBO candidates (benchmark, repetition 0)")
        info = dict(g=g.round(0).to_dict())
    else:
        axs[1, 0].axis("off"); axs[1, 1].axis("off"); info = {}
    fig.legend(hb, lb, loc="lower center", ncol=10, frameon=False, fontsize=5.8, bbox_to_anchor=(0.5, 0.0), columnspacing=0.9, handletextpad=0.3)
    fig.tight_layout(rect=(0, 0.03, 1, 1), h_pad=1.0, w_pad=0.8)
    save(fig, "fig_quality")
    return info


if __name__ == "__main__":
    print(fig_quality())
