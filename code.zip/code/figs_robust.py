"""Robustness sweeps on the known model: MCC against separation, label noise, irrelevant features and imbalance ratio."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from sgbo.protocol import RES

S = json.load(open(os.path.join(RES, "synth_summary.json")))
SHOW = ["None", "SMOTE", "SVM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MK = {"None": "x", "SMOTE": "o", "SVM-SMOTE": "D", "MWMOTE": "<", "CCR": ">", "BDO": "^", "SGBO": "*"}
PAN = [("s", r"class separation $s$", False), ("rho", r"label-noise rate $\rho$", False), ("q", r"irrelevant features $q$", False), ("ir", "imbalance ratio", True)]


def fig_robust():
    fig, axs = plt.subplots(1, 4, figsize=(6.9, 2.35))
    for ax, (f, lab, lg) in zip(axs, PAN):
        for m in SHOW:
            c = S["curve"][f]["mcc"][m]
            x, y, e = np.array(c["x"]), np.array(c["mean"]), np.array(c["se"])
            if f == "q":
                x = x + 2.0
            ax.plot(x, y, "-", marker=MK[m], color=COL[m], lw=1.8 if m == "SGBO" else 0.8, ms=6 if m == "SGBO" else 3, zorder=5 if m == "SGBO" else 2, label=m)
            if m in ("SGBO", "BDO"):
                ax.fill_between(x, y - 2 * e, y + 2 * e, color=COL[m], alpha=0.18, lw=0)
        if lg or f == "q":
            ax.set_xscale("log")
        if f == "q":
            ax.set_xticks([2, 5, 10, 20, 40, 80]); ax.set_xticklabels(["2", "5", "10", "20", "40", "80"]); ax.minorticks_off()
        if f == "ir":
            ax.set_xticks([5, 10, 20, 50, 100]); ax.set_xticklabels(["5", "10", "20", "50", "100"]); ax.minorticks_off()
        ax.set_xlabel(lab if f != "q" else r"dimension $d=2+q$", fontsize=7.5)
        ax.grid(alpha=0.25, lw=0.4); ax.tick_params(labelsize=6.5)
    axs[0].set_ylabel("MCC (test sample of 5000)")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=7, frameon=False, fontsize=6.6, bbox_to_anchor=(0.5, -0.07))
    fig.tight_layout(rect=(0, 0.05, 1, 1), w_pad=0.5)
    save(fig, "fig_robust")


if __name__ == "__main__":
    fig_robust()
