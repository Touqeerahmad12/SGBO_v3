"""Scalability: running time against n and d (all methods), SGBO stage shares, peak memory against n."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from sgbo.protocol import RES

S = json.load(open(os.path.join(RES, "scalability_summary.json")))
SHOW = ["SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MK = {"SMOTE": "o", "B-SMOTE": "v", "ADASYN": "P", "SVM-SMOTE": "D", "SMOTE-ENN": "s", "KM-SMOTE": "X", "MWMOTE": "<", "CCR": ">", "BDO": "^", "SGBO": "*"}
LAB = {"KM-SMOTE": "$k$M-SM", "SVM-SMOTE": "SVM-SM", "B-SMOTE": "B-SM", "SMOTE-ENN": "SM-ENN"}


def lines(ax, sweep, xl, key="times"):
    for m in SHOW:
        d = S[key][sweep].get(m) if key == "times" else None
        if d is None:
            continue
        x = np.array([float(k) for k in d]); y = np.array(list(d.values()))
        ax.plot(x, y, "-", marker=MK[m], color=COL[m], lw=1.8 if m == "SGBO" else 0.8, ms=6 if m == "SGBO" else 3, zorder=5 if m == "SGBO" else 2, label=LAB.get(m, m))
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel(xl, fontsize=7.5); ax.grid(alpha=0.25, lw=0.4, which="both"); ax.tick_params(labelsize=6.5)


def fig_scale():
    fig, axs = plt.subplots(1, 4, figsize=(6.9, 2.45))
    lines(axs[0], "n", r"training size $n$ ($d=10$, IR 10)"); axs[0].set_ylabel("resampling time (s)", fontsize=7.5)
    lines(axs[1], "d", r"dimension $d$ ($n=4000$)")
    # (c) stages of SGBO against n
    ax = axs[2]
    st = S["stages"]["n"]; ks = sorted(st, key=float)
    a = np.array([st[k] for k in ks]); tot = a.sum(1)
    x = np.arange(len(ks)); bot = np.zeros(len(ks))
    for j, (nm, c) in enumerate((("score", "#e6b87a"), ("transport", "#c0392b"), ("generation + test", "#7d3c98"))):
        ax.bar(x, a[:, j] / tot, bottom=bot, color=c, edgecolor="k", lw=0.3, width=0.75, label=nm); bot += a[:, j] / tot
    ax.set_xticks(x); ax.set_xticklabels([f"{int(float(k))//1000}k" if float(k) >= 1000 else k for k in ks], fontsize=6.3)
    ax.set_xlabel(r"training size $n$", fontsize=7.5); ax.set_ylabel("share of SGBO time", fontsize=7.5); ax.set_ylim(0, 1.3); ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0]); ax.legend(frameon=False, fontsize=5.6, loc="upper center", ncol=3, columnspacing=0.6, handlelength=1.0, handletextpad=0.3)
    ax.tick_params(labelsize=6.5)
    # (d) peak memory against n
    ax = axs[3]
    if "memory" in S:
        mm = S["memory"]["n"]
        for m in SHOW:
            xs = [float(k) for k in mm if m in mm[k]]; ys = [mm[k][m] for k in mm if m in mm[k]]
            if xs:
                ax.plot(xs, ys, "-", marker=MK[m], color=COL[m], lw=1.8 if m == "SGBO" else 0.8, ms=6 if m == "SGBO" else 3, zorder=5 if m == "SGBO" else 2)
        ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlabel(r"training size $n$", fontsize=7.5); ax.set_ylabel("peak memory (MB)", fontsize=7.5)
        ax.grid(alpha=0.25, lw=0.4, which="both"); ax.tick_params(labelsize=6.5)
    for i, t in enumerate("abcd"):
        axs[i].set_title(f"({t})", fontsize=8, pad=3)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=10, frameon=False, fontsize=6.2, bbox_to_anchor=(0.5, -0.06), columnspacing=0.9, handletextpad=0.3)
    fig.tight_layout(rect=(0, 0.05, 1, 1), w_pad=0.5)
    save(fig, "fig_scale")


if __name__ == "__main__":
    fig_scale()
