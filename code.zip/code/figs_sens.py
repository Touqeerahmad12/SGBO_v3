"""Parameter sensitivity of SGBO: heat map of the change of MCC for every parameter and tested value, eta x tau surface,
dependence of the effect of tau and of the bandwidth on the regime, and the acceptance threshold against accepted share and cost."""
import _threads  # noqa: F401
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL
from matplotlib import cm
from matplotlib.colors import TwoSlopeNorm

S = json.load(open(os.path.join(RES := os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results"), "sensitivity_summary.json")))
ORDER = [("k0", r"$k_0$"), ("k_scale", r"$k$ scale"), ("h_mult", "bandwidth $\\times$"), ("eta", r"step $\eta$"), ("tau", r"temperature $\tau$"), ("T", r"$T$"),
         ("k_gen", r"$k_g$"), ("rho_fixed", r"fixed $\rho$"), ("rho_min", r"$\rho_{\min}$"), ("theta_q", r"$\theta$ quantile"), ("theta", r"fixed $\theta$"), ("rounds", "rounds")]
GR = {"IR<10, d<20": "#6f9a6e", "IR<10, d>=20": "#4a7c8c", "IR>=10, d<20": "#d08c3c", "IR>=10, d>=20": "#b2182b"}
GL = {"IR<10, d<20": "IR$<$10, $d<$20", "IR<10, d>=20": "IR$<$10, $d\\geq$20", "IR>=10, d<20": "IR$\\geq$10, $d<$20", "IR>=10, d>=20": "IR$\\geq$10, $d\\geq$20"}


def fmt(v):
    v = float(v)
    return f"{v:g}"


def fig_sens():
    fig = plt.figure(figsize=(6.9, 4.9))
    gs = fig.add_gridspec(2, 6, height_ratios=[1.25, 1], hspace=0.36, wspace=1.2)
    # (a) heat map
    ax = fig.add_subplot(gs[0, :4])
    Z = np.full((len(ORDER), 6), np.nan); T = [[""] * 6 for _ in ORDER]
    for i, (p, _) in enumerate(ORDER):
        vals = list(S["params"][p]["values"].items())
        for j, (v, r) in enumerate(vals):
            Z[i, j] = r["mcc"]["mean"]; T[i][j] = fmt(v)
    norm = TwoSlopeNorm(vmin=-0.04, vcenter=0.0, vmax=0.04)
    im = ax.imshow(np.clip(Z, -0.04, 0.04), cmap="RdBu", norm=norm, aspect="auto")
    for i in range(Z.shape[0]):
        for j in range(Z.shape[1]):
            if T[i][j]:
                dflt = S["params"][ORDER[i][0]]["default"]
                is_def = dflt is not None and abs(float(T[i][j]) - float(dflt)) < 1e-12
                ax.text(j, i, T[i][j], ha="center", va="center", fontsize=6.3, fontweight="bold" if is_def else "normal",
                        color="k", bbox=dict(boxstyle="square,pad=0.08", fc="white", ec="k", lw=0.5) if is_def else None)
    ax.set_yticks(range(len(ORDER))); ax.set_yticklabels([o[1] for o in ORDER], fontsize=7)
    ax.set_xticks([]); ax.set_title("(a) change of MCC (all 15 tasks) when one parameter is changed; boxed: default", fontsize=7.6)
    cb = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.015); cb.ax.tick_params(labelsize=6); cb.set_label(r"$\Delta$MCC", fontsize=7)
    # (b) 3D surface
    ax = fig.add_subplot(gs[0, 4:], projection="3d")
    g = S["grid_mcc"]; E, Ta = np.meshgrid(np.arange(len(g["tau"])), np.arange(len(g["eta"])))
    Zg = np.array(g["z"])
    ax.plot_surface(E, Ta, Zg, cmap="viridis", edgecolor="k", linewidth=0.2, alpha=0.95)
    ax.set_xticks(range(len(g["tau"]))); ax.set_xticklabels([fmt(t) for t in g["tau"]], fontsize=5.5)
    ax.set_yticks(range(len(g["eta"]))); ax.set_yticklabels([fmt(e) for e in g["eta"]], fontsize=5.5)
    ax.tick_params(axis="z", labelsize=5.5, pad=0)
    ax.set_xlabel(r"$\tau$", fontsize=7, labelpad=-4); ax.set_ylabel(r"$\eta$", fontsize=7, labelpad=-4); ax.set_zlabel("MCC", fontsize=7, labelpad=-3)
    ax.view_init(elev=24, azim=-58); ax.set_title(r"(b) MCC over $\eta\times\tau$", fontsize=7.6, pad=-2)
    # (c, d) regime dependence
    for k, (p, ttl, lab) in enumerate((("tau", "(c) temperature", r"$\tau$"), ("h_mult", "(d) bandwidth multiplier", "multiplier"))):
        ax = fig.add_subplot(gs[1, 2 * k:2 * k + 2])
        vals = list(S["params"][p]["values"])
        x = np.arange(len(vals))
        for gname, c in GR.items():
            ax.plot(x, [S["params"][p]["values"][v]["mcc"]["groups"][gname] for v in vals], "-o", ms=2.5, lw=1.0, color=c, label=GL[gname])
        m = S["params"][p]["values"]
        ax.plot(x, [m[v]["mcc"]["mean"] for v in vals], "-k", lw=1.8, label="mean")
        ax.axhline(0, color="gray", lw=0.5, ls="--")
        ax.set_xticks(x); ax.set_xticklabels([fmt(v) for v in vals], fontsize=6.5); ax.set_xlabel(lab, fontsize=7)
        ax.set_title(ttl, fontsize=7.6); ax.tick_params(labelsize=6.3); ax.grid(alpha=0.25, lw=0.4)
        if k == 0:
            ax.set_ylabel(r"$\Delta$MCC", fontsize=7)
            ax.legend(frameon=False, fontsize=5.4, loc="lower left")
    # (e) acceptance threshold
    ax = fig.add_subplot(gs[1, 4:])
    th = S["params"]["theta"]["values"]; keys = list(th)
    x = np.arange(len(keys) + 1)
    d = S["params"]["theta_q"]["values"]["0.25"]["acc"]
    acc = [d["acc_rate"]] + [th[k]["acc"]["acc_rate"] for k in keys]; fill = [d["fill_share"]] + [th[k]["acc"]["fill_share"] for k in keys]
    t3 = [d["t_stage3"] / d["t_stage3"]] + [th[k]["acc"]["t_stage3"] / d["t_stage3"] for k in keys]
    ax.plot(x, acc, "-o", ms=3, color="#4a7c8c", label="accepted share")
    ax.plot(x, fill, "-s", ms=3, color="#d08c3c", label="fall-back share")
    ax.set_ylim(0, 1.05); ax.set_xticks(x); ax.set_xticklabels(["default"] + [fmt(k) for k in keys], fontsize=6.3); ax.set_xlabel(r"fixed threshold $\theta$", fontsize=7)
    ax2 = ax.twinx(); ax2.plot(x, t3, "-^", ms=3, color="#7d3c98", label="stage-3 time"); ax2.tick_params(labelsize=6.3); ax2.set_ylabel("stage-3 time (default = 1)", fontsize=6.5)
    ax.tick_params(labelsize=6.3); ax.set_title("(e) acceptance threshold", fontsize=7.6); ax.grid(alpha=0.25, lw=0.4)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, frameon=False, fontsize=5.4, loc="upper center")
    save(fig, "fig_sens")


if __name__ == "__main__":
    fig_sens()
