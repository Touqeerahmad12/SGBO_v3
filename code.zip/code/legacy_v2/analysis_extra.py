"""Additional descriptive/robustness summaries used in the Results section."""
import os, json, sys
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis_v2 import load, unit_matrix, friedman, posthoc, METHODS, CLFS, RES
from datasets import task_registry

df = load()
reg = task_registry()
kind = {t["source"]: t["kind"] for t in reg}
out = {}
real_src = [s for s, k in kind.items() if not k.startswith("synthetic")]
syn_src = [s for s, k in kind.items() if k.startswith("synthetic")]
out["n_real_src"], out["n_syn_src"] = len(real_src), len(syn_src)
for met in ["aucpr", "mcc", "f1", "gmean", "auc"]:
    M = unit_matrix(df, met)
    for tag, srcs in (("real", real_src), ("synthetic", syn_src)):
        Ms = M.loc[[s for s in srcs if s in M.index]]
        fr = friedman(Ms)
        ph = posthoc(Ms) if tag == "real" else {}
        out[f"{tag}_{met}"] = dict(N=fr["N"], ranks=fr["ranks"], mean=Ms.mean().to_dict(), p_FF=fr["p_FF"],
                                   posthoc={k: dict(mean=v["mean"], ci=[v["ci_lo"], v["ci_hi"]], wins=v["wins"], losses=v["losses"],
                                                    p_holm=v["p_holm"], r_rb=v["r_rb"]) for k, v in ph.items()})
# per-task wins / best counts (task level, pooled over classifiers), descriptive only
for met in ["aucpr", "mcc", "f1", "gmean"]:
    t = df.groupby(["dataset", "clf", "method"])[met].mean().groupby(["dataset", "method"]).mean().unstack()[METHODS]
    best = t.idxmax(axis=1).value_counts().to_dict()
    top3 = (t.rank(axis=1, ascending=False) <= 3).sum().to_dict()
    out[f"best_{met}"] = best; out[f"top3_{met}"] = top3
    out[f"sgbo_ge_bdo_{met}"] = int((t["SGBO"] >= t["BDO"]).sum()); out["n_tasks"] = len(t)
    out[f"sgbo_ge_smote_{met}"] = int((t["SGBO"] >= t["SMOTE"]).sum())
    out[f"sgbo_ge_svmsm_{met}"] = int((t["SGBO"] >= t["SVM-SMOTE"]).sum())
# tpr / tnr summaries (pooled, source-level means)
for met in ["tpr", "tnr"]:
    M = unit_matrix(df, met); out[f"mean_{met}"] = M.mean().to_dict()
# grand mean of the four main metrics rank
avg = sum(friedman(unit_matrix(df, m))["ranks"][k] for m in ["aucpr", "mcc", "f1", "gmean"] for k in ["SGBO"]) / 4
out["sgbo_avg_rank4"] = avg
# MCC range over methods excluding None
M = unit_matrix(df, "mcc"); out["mcc_spread_excl_none"] = float(M.drop(columns="None").mean().max() - M.drop(columns="None").mean().min())
# mean run time of resampling per fold (seconds), RF rows only
rt = df[df.clf == "RF"].groupby("method")["t_resample"].mean().to_dict(); out["t_resample"] = rt
json.dump(out, open(f"{RES}/extra_v2.json", "w"), indent=1, default=float)
for k in ["real_aucpr", "real_mcc", "real_f1", "real_gmean"]:
    o = out[k]; r = o["ranks"]
    print(k, "N", o["N"], "pFF", round(o["p_FF"], 4), "SGBO rank", round(r["SGBO"], 2), "best", min(r, key=r.get), round(min(r.values()), 2))
for k in ["synthetic_mcc", "synthetic_aucpr"]:
    r = out[k]["ranks"]; print(k, {m: round(v, 2) for m, v in sorted(r.items(), key=lambda x: x[1])})
for met in ["aucpr", "mcc", "f1", "gmean"]:
    print(met, "best", out[f"best_{met}"], "sgbo>=bdo", out[f"sgbo_ge_bdo_{met}"], "of", out["n_tasks"], ">=smote", out[f"sgbo_ge_smote_{met}"], ">=svmsm", out[f"sgbo_ge_svmsm_{met}"])
print(out["mean_tpr"], out["mean_tnr"]); print(rt)
