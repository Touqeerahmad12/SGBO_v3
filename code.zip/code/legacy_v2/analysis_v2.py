"""
Source-level statistics for the main benchmark.

Experimental unit = independent data source (26 units: 20 real sources and 6 synthetic
generators). Related tasks of one source are averaged first, then repetitions/folds.
Pooled analysis: the unit score is also averaged over the four classifiers.
Per-classifier analysis: one Friedman test per classifier (N = 26 units).
Post-hoc: Wilcoxon signed-rank tests of SGBO against each method with Holm correction
(Benavoli et al., 2016), plus effect sizes (mean and median difference, cluster bootstrap
95% CI over units, matched-pairs rank-biserial correlation).
"""
import os, json
import numpy as np, pandas as pd
from scipy import stats
from scipy.stats import studentized_range

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
METHODS = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN",
           "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
METRICS = ["aucpr", "mcc", "f1", "gmean", "auc"]
CLFS = ["RF", "SVM", "kNN", "LR"]


def load(path=None):
    return pd.read_csv(path or os.path.join(RES, "benchmark.csv"), keep_default_na=False, na_values=[""])


def unit_matrix(df, metric, clf=None, methods=METHODS, primary_only=None):
    d = df if clf is None else df[df.clf == clf]
    if primary_only is not None:
        d = d[d.dataset.isin(primary_only)]
    t = d.groupby(["source", "dataset", "clf", "method"])[metric].mean()      # over reps and folds
    t = t.groupby(["source", "clf", "method"]).mean()                          # over related tasks
    t = t.groupby(["source", "method"]).mean().unstack("method")              # over classifiers
    return t[methods]


def friedman(M):
    R = M.rank(axis=1, ascending=False).values
    N, k = R.shape
    Rbar = R.mean(0)
    chi2 = 12 * N / (k * (k + 1)) * (np.sum(Rbar ** 2) - k * (k + 1) ** 2 / 4)
    FF = (N - 1) * chi2 / (N * (k - 1) - chi2)
    q = studentized_range.ppf(0.95, k, 1e6) / np.sqrt(2)
    return dict(N=N, k=k, ranks=dict(zip(M.columns, Rbar)), chi2=chi2, p_chi2=stats.chi2.sf(chi2, k - 1),
                FF=FF, p_FF=stats.f.sf(FF, k - 1, (k - 1) * (N - 1)),
                Fcrit=stats.f.ppf(0.95, k - 1, (k - 1) * (N - 1)), q05=q, cd=q * np.sqrt(k * (k + 1) / (6 * N)))


def boot_ci(d, B=10000, seed=0):
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(d), size=(B, len(d)))
    m = d[idx].mean(1)
    return float(np.quantile(m, 0.025)), float(np.quantile(m, 0.975))


def posthoc(M, control="SGBO"):
    rows = []
    for m in M.columns:
        if m == control:
            continue
        d = (M[control] - M[m]).values
        nz = d[np.abs(d) > 1e-12]
        if len(nz) == 0:
            p, rrb = 1.0, 0.0
        else:
            p = float(stats.wilcoxon(M[control], M[m], zero_method="wilcox").pvalue)
            rk = stats.rankdata(np.abs(nz))
            Wp, Wm = rk[nz > 0].sum(), rk[nz < 0].sum()
            rrb = float((Wp - Wm) / (Wp + Wm))
        lo, hi = boot_ci(d)
        rows.append(dict(method=m, mean=float(d.mean()), median=float(np.median(d)), ci_lo=lo, ci_hi=hi,
                         wins=int((d > 1e-12).sum()), losses=int((d < -1e-12).sum()), p=p, r_rb=rrb))
    rows.sort(key=lambda r: r["p"])
    k = len(rows); prev = 0.0
    for i, r in enumerate(rows):
        adj = min(1.0, max(prev, (k - i) * r["p"])); r["p_holm"] = adj; prev = adj
        r["reject"] = adj < 0.05
    return {r["method"]: r for r in rows}


def analyse(df, primary_only=None):
    out = {}
    for met in METRICS:
        M = unit_matrix(df, met, primary_only=primary_only)
        fr = friedman(M); fr["posthoc"] = posthoc(M); fr["mean"] = M.mean().to_dict(); fr["std"] = M.std().to_dict()
        out[met] = fr
        for c in CLFS:
            Mc = unit_matrix(df, met, clf=c, primary_only=primary_only)
            frc = friedman(Mc); frc["posthoc"] = posthoc(Mc); frc["mean"] = Mc.mean().to_dict()
            out[f"{met}_{c}"] = frc
    return out


if __name__ == "__main__":
    df = load()
    from datasets import task_registry
    reg = task_registry()
    prim = [t["name"] for t in reg if t["primary"]]
    full = analyse(df)
    prim_res = analyse(df, primary_only=prim)
    json.dump({"all_tasks": full, "primary_only": prim_res}, open(os.path.join(RES, "stats_v2.json"), "w"),
              indent=1, default=float)
    for met in ["aucpr", "mcc", "f1", "gmean", "auc"]:
        fr = full[met]
        print(f"\n== {met}: N={fr['N']} k={fr['k']} chi2={fr['chi2']:.2f} FF={fr['FF']:.2f} p={fr['p_FF']:.2e} CD={fr['cd']:.3f}")
        for m, r in sorted(fr["ranks"].items(), key=lambda x: x[1]):
            ph = fr["posthoc"].get(m)
            extra = "" if ph is None else f"  d={ph['mean']:+.4f} [{ph['ci_lo']:+.4f},{ph['ci_hi']:+.4f}] W/L={ph['wins']}/{ph['losses']} pH={ph['p_holm']:.3f} rrb={ph['r_rb']:+.2f}"
            print(f"   {m:10s} rank={r:5.2f} mean={fr['mean'][m]:.4f}{extra}")
        pr = prim_res[met]["ranks"]
        print("   primary-only SGBO rank", round(pr["SGBO"], 2), "best", min(pr, key=pr.get), round(min(pr.values()), 2))
    for met in ["mcc", "aucpr", "f1", "gmean"]:
        print(met, {c: (round(full[f'{met}_{c}']['ranks']['SGBO'], 2), min(full[f'{met}_{c}']['ranks'], key=full[f'{met}_{c}']['ranks'].get)) for c in CLFS})
