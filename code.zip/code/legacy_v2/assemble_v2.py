"""Assemble the revised manuscript (single main.tex) and the supplement from parts and tables."""
import os, re, sys, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

M = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "manuscript_v2")
P = os.path.join(M, "parts")
T = os.path.join(M, "tables")


def tab(name):
    return open(os.path.join(T, name)).read().strip()


parts = ["a_front.tex", "b_related.tex", "c_method.tex", "d_setup.tex", "e_results.tex", "f_end.tex"]
tex = "\n".join(open(os.path.join(P, p)).read() for p in parts)
abstract = open(os.path.join(P, "abstract.txt")).read().strip()
tex = tex.replace("%ABSTRACT%", abstract)
for key, f in (("%TAB_DATA%", "tab_data.tex"), ("%EXCEPTIONS%", "tab_exceptions.tex"), ("%TAB_MAIN%", "tab_main.tex"),
               ("%TAB_FRIEDMAN%", "tab_friedman.tex"), ("%TAB_POSTHOC%", "tab_posthoc.tex"), ("%TAB_TUNING%", "tab_tuning.tex")):
    if key in tex:
        tex = tex.replace(key, tab(f))
open(os.path.join(M, "main.tex"), "w").write(tex)
# references ordered by first citation
subprocess.run([sys.executable, os.path.join(os.path.dirname(os.path.abspath(__file__)), "build_bib.py"), os.path.join(M, "main.tex")], check=True)

# supplement
sup = open(os.path.join(M, "supp_template.tex")).read()
LAB = {"mcc": "MCC", "aucpr": "AUC-PR", "f1": "F1", "gmean": "G-mean"}
heads = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SM", "SM-ENN", "$k$M-SM", "MWMOTE", "CCR", "BDO", "SGBO"]
blocks = []
for i, met in enumerate(["aucpr", "mcc", "f1", "gmean"], 1):
    body = tab(f"supp_{met}.tex")
    blocks.append(
        "\\begin{center}\\scriptsize\n\\begin{longtable}{l" + "r" * 12 + "}\n"
        f"\\caption{{Per-task {LAB[met]} (mean over repetitions, folds and classifiers; standard deviation in small type).}}\\\\\n"
        "\\toprule\nTask & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endfirsthead\n"
        "\\toprule\nTask & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endhead\n"
        + body + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n\\clearpage\n")
blocks.append(
    "\\begin{center}\\scriptsize\n\\begin{longtable}{ll" + "r" * 12 + "}\n"
    "\\caption{Average Friedman ranks per classifier over the 26 independent sources (lower is better; best in bold).}\\\\\n"
    "\\toprule\nMetric & Classifier & " + " & ".join(heads) + " \\\\\n\\midrule\n\\endfirsthead\n"
    + tab("supp_classifier_ranks.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
blocks.append(
    "\\begin{center}\\scriptsize\n\\begin{longtable}{l ccc ccc}\n"
    "\\caption{SGBO against each method for F1 and G-mean (26 sources, pooled over classifiers): mean difference with 95\\% bootstrap interval, wins/losses of SGBO, Holm-adjusted Wilcoxon $p$-value (bold: significant at 0.05).}\\\\\n"
    "\\toprule\n & \\multicolumn{3}{c}{F1} & \\multicolumn{3}{c}{G-mean} \\\\\n\\cmidrule(lr){2-4}\\cmidrule(lr){5-7}\nMethod & $\\Delta$ [95\\% CI] & W/L & $p_{\\mathrm{H}}$ & $\\Delta$ [95\\% CI] & W/L & $p_{\\mathrm{H}}$ \\\\\n\\midrule\n"
    + tab("supp_posthoc.tex") + "\n\\bottomrule\n\\end{longtable}\n\\end{center}\n")
if os.path.exists(os.path.join(T, "supp_tuning_choices.tex")):
    blocks.append(tab("supp_tuning_choices.tex"))
sup = sup.replace("%SUPP_TABLES%", "\n".join(blocks))
open(os.path.join(M, "supplement.tex"), "w").write(sup)
print("assembled")
