"""Illustrative figures for the revised manuscript (written to manuscript_v2/figures)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style
style.FIG = "../manuscript_v2/figures"
import figs_illustrative as fi
if __name__ == "__main__":
    which = sys.argv[1:] or ["field", "traj", "cons"]
    if "field" in which: fi.fig_score_field(); print("field")
    if "traj" in which: print("k=", fi.fig_trajectories()["k"])
    if "cons" in which: fi.fig_consistency(); print("consistency")
