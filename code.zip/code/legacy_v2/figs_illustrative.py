"""Figures that illustrate the method (do not depend on the benchmark)."""
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from style import plt, save, COL, NEG, POS, NEW, ANC
from matplotlib.patches import PathPatch
from matplotlib.path import Path
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from samplers import SGBO, BDO, SMOTE, binary_entropy
from datasets import two_cluster, all_tasks
from scipy.stats import spearmanr

RES = "../results"


def bdo_field(X, y, G):
    k = int(y.sum())
    nb = NearestNeighbors(n_neighbors=k).fit(X).kneighbors(G, return_distance=False)
    return binary_entropy(np.mean(y[nb] == 1, axis=1))


def sgbo_field(X, y, G):
    s = SGBO(); s.y_ = y; s.k_ = s._k(len(X), int(y.sum())); s.nn_ = NearestNeighbors().fit(X)
    return binary_entropy(s.posterior(G)), s.k_


def fig_score_field():
    X, y = two_cluster(n_neg=800, n_pos=40, seed=2)
    xs = np.linspace(-3.2, 3.4, 220); ys = np.linspace(-3.2, 3.2, 220)
    XX, YY = np.meshgrid(xs, ys); G = np.c_[XX.ravel(), YY.ravel()]
    f1 = bdo_field(X, y, G).reshape(XX.shape)
    f2, k = sgbo_field(X, y, G); f2 = f2.reshape(XX.shape)
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.9), sharey=True)
    for ax, F, ttl in ((axs[0], f1, r"(a) BDO degree, $k=n^+=40$"),
                       (axs[1], f2, rf"(b) SGBO score $b(x)$, $k={k}$")):
        im = ax.imshow(F, origin="lower", extent=[xs[0], xs[-1], ys[0], ys[-1]], cmap="YlOrRd",
                       vmin=0, vmax=1, aspect="auto", interpolation="bilinear")
        ax.contour(XX, YY, F, levels=[0.5, 0.9], colors="k", linewidths=0.5, linestyles=["--", "-"])
        ax.scatter(X[y == 0, 0], X[y == 0, 1], s=3, c=NEG, edgecolors="none", alpha=0.8)
        ax.scatter(X[y == 1, 0], X[y == 1, 1], s=9, c=POS, edgecolors="k", linewidths=0.3)
        ax.set_title(ttl); ax.set_xlabel(r"$x_1$")
    axs[0].set_ylabel(r"$x_2$")
    cb = fig.colorbar(im, ax=axs, fraction=0.025, pad=0.02); cb.set_label("boundary score")
    save(fig, "fig02_score_field")


def fig_consistency():
    """Error of the boundary score against the true H(eta) for a two-Gaussian model."""
    rng = np.random.default_rng(0)
    pi = 1 / 6
    def eta(Z):
        lp = np.exp(-0.5 * np.sum((Z - [1.0, 0.0]) ** 2, 1)); ln = np.exp(-0.5 * np.sum((Z + [1.0, 0.0]) ** 2, 1))
        return pi * lp / (pi * lp + (1 - pi) * ln)
    ns = [150, 300, 600, 1200, 2400, 4800, 9600]
    rows = {"BDO ($k=n^+$)": [], "adaptive $k$, uniform": [], "SGBO (adaptive, weighted)": []}
    rho = {key: [] for key in rows}
    for n in ns:
        e = {key: [] for key in rows}; r = {key: [] for key in rows}
        for rep in range(5):
            npos = int(round(n * pi))
            X = np.vstack([rng.normal([1, 0], 1, (npos, 2)), rng.normal([-1, 0], 1, (n - npos, 2))])
            y = np.r_[np.ones(npos, int), np.zeros(n - npos, int)]
            Q = rng.normal(0, 1.4, (2000, 2)); Ht = binary_entropy(eta(Q))
            # BDO
            nb = NearestNeighbors(n_neighbors=npos).fit(X).kneighbors(Q, return_distance=False)
            b1 = binary_entropy(np.mean(y[nb] == 1, 1))
            # adaptive k, uniform weights
            ka = int(min(npos, max(5, np.ceil(np.sqrt(n)))))
            nb2 = NearestNeighbors(n_neighbors=ka).fit(X).kneighbors(Q, return_distance=False)
            b2 = binary_entropy(np.mean(y[nb2] == 1, 1))
            # SGBO
            s = SGBO(); s.y_ = y; s.k_ = ka; s.nn_ = NearestNeighbors().fit(X)
            b3 = binary_entropy(s.posterior(Q))
            for key, b in zip(rows, (b1, b2, b3)):
                e[key].append(np.mean(np.abs(b - Ht))); r[key].append(spearmanr(b, Ht).statistic)
        for key in rows:
            rows[key].append((np.mean(e[key]), np.std(e[key]))); rho[key].append(np.mean(r[key]))
    json.dump({"ns": ns, "mae": rows, "rho": rho}, open(f"{RES}/consistency.json", "w"), indent=1)
    fig, axs = plt.subplots(1, 2, figsize=(6.6, 2.5))
    sty = {"BDO ($k=n^+$)": (COL["BDO"], "o", "-"), "adaptive $k$, uniform": ("#5f86a6", "s", "--"),
           "SGBO (adaptive, weighted)": (COL["SGBO"], "^", "-")}
    for key, v in rows.items():
        c, mk, ls = sty[key]; m = np.array([a for a, _ in v]); sd = np.array([b for _, b in v])
        axs[0].plot(ns, m, ls, color=c, marker=mk, ms=4, lw=1.2, label=key)
        axs[0].fill_between(ns, m - sd, m + sd, color=c, alpha=0.15, lw=0)
        axs[1].plot(ns, rho[key], ls, color=c, marker=mk, ms=4, lw=1.2, label=key)
    for ax in axs:
        ax.set_xscale("log"); ax.set_xlabel(r"sample size $n$"); ax.grid(alpha=0.25, lw=0.4)
    axs[0].set_ylabel(r"mean $|\,\hat b(x)-H_2(\eta(x))\,|$"); axs[0].set_title("(a) score error")
    axs[1].set_ylabel(r"Spearman $\rho(\hat b, H_2(\eta))$"); axs[1].set_title("(b) rank agreement")
    axs[0].legend(frameon=False, loc="upper right")
    save(fig, "fig03_consistency")


def fig_trajectories():
    X, y = two_cluster(n_neg=800, n_pos=40, seed=2)
    rng = np.random.default_rng(3)
    Xs, ys = SMOTE().fit_resample(X, y, np.random.default_rng(3))
    bd = BDO(return_info=True).fit_resample(X, y, np.random.default_rng(3))
    s = SGBO(return_info=True)
    sg = s.fit_resample(X, y, np.random.default_rng(3)); info = sg[2]
    paths = np.stack(s.paths_)              # (T+1, M, d)
    fig, axs = plt.subplots(1, 3, figsize=(6.9, 2.45), sharex=True, sharey=True)
    def base(ax):
        ax.scatter(X[y == 0, 0], X[y == 0, 1], s=2.5, c=NEG, edgecolors="none", alpha=0.7)
        ax.scatter(X[y == 1, 0], X[y == 1, 1], s=9, c=POS, edgecolors="k", linewidths=0.3, zorder=4)
    base(axs[0]); n0 = len(X)
    axs[0].scatter(Xs[n0:, 0], Xs[n0:, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none")
    axs[0].set_title("(a) SMOTE")
    base(axs[1]); bi = bd[2]
    axs[1].scatter(bi["new"][:, 0], bi["new"][:, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none")
    for a, b in zip(bi["seeds"], bi["aided"]):
        axs[1].annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="-|>", lw=0.6, color=ANC, mutation_scale=5))
    axs[1].scatter(bi["seeds"][:, 0], bi["seeds"][:, 1], s=7, facecolors="none", edgecolors=ANC, linewidths=0.5, zorder=5)
    axs[1].set_title("(b) BDO: straight aided moves")
    base(axs[2])
    axs[2].scatter(info["new"][:, 0], info["new"][:, 1], s=2.5, c=NEW, alpha=0.45, edgecolors="none")
    for j in range(paths.shape[1]):
        axs[2].plot(paths[:, j, 0], paths[:, j, 1], "-", color=ANC, lw=0.45, alpha=0.8)
    axs[2].scatter(info["seeds"][:, 0], info["seeds"][:, 1], s=7, facecolors="none", edgecolors=ANC, linewidths=0.5, zorder=5)
    axs[2].scatter(info["anchors"][:, 0], info["anchors"][:, 1], s=6, marker="x", c=ANC, linewidths=0.6, zorder=5)
    axs[2].set_title("(c) SGBO: Langevin paths")
    for ax in axs:
        ax.set_xlim(-3.3, 3.4); ax.set_ylim(-3.2, 3.3); ax.set_xlabel(r"$x_1$")
    axs[0].set_ylabel(r"$x_2$")
    save(fig, "fig04_trajectories")
    return info


def _band(ax, x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.45):
    xm = (x0 + x1) / 2
    verts = [(x0, y0a), (xm, y0a), (xm, y1a), (x1, y1a), (x1, y1b), (xm, y1b), (xm, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), fc=color, ec="none", alpha=alpha))


def sankey(ax, columns, flows, colors, title, width=0.06, gap=0.03):
    """columns: list of lists of (name, value); flows: list of (src, dst, value)."""
    columns = [[(n, v) for n, v in col if v > 0] for col in columns]
    flows = [f for f in flows if f[2] > 0]
    tot = max(sum(v for _, v in col) for col in columns)
    pos = {}
    xs = np.linspace(0, 1, len(columns))
    for ci, col in enumerate(columns):
        n = len(col); scale = (1 - gap * (n - 1)) / tot
        y = 1 - (1 - (sum(v for _, v in col) * scale + gap * (n - 1))) / 2
        for name, v in col:
            h = v * scale
            pos[name] = dict(x=xs[ci], top=y, h=h, out=y, inn=y, scale=scale)
            ax.add_patch(plt.Rectangle((xs[ci] - width / 2, y - h), width, h, fc=colors.get(name, "#555"), ec="k", lw=0.4, zorder=3))
            ha = "right" if ci == len(columns) - 1 else "left"
            dx = -width / 2 - 0.01 if ci == len(columns) - 1 else width / 2 + 0.01
            if ci == 0:
                ha, dx = "left", width / 2 + 0.01
            ax.text(xs[ci] + dx, y - h / 2, f"{name}\n{v:,}", ha=ha, va="center", fontsize=6.6, zorder=4,
                    bbox=dict(fc="white", ec="none", alpha=0.7, pad=0.6))
            y -= h + gap
    for s, d, v in flows:
        ps, pd_ = pos[s], pos[d]
        hs, hd = v * ps["scale"], v * pd_["scale"]
        _band(ax, ps["x"] + width / 2, ps["out"], ps["out"] - hs, pd_["x"] - width / 2, pd_["inn"], pd_["inn"] - hd,
              colors.get(d, "#888"))
        ps["out"] -= hs; pd_["inn"] -= hd
    ax.set_xlim(-0.05, 1.05); ax.set_ylim(-0.02, 1.02); ax.axis("off"); ax.set_title(title)


def fig_sankey():
    agg = dict(neg=0, cand=0, seeds=0, gen=0, acc=0, used=0, fill=0, N=0)
    for nm, X, y, _ in all_tasks():
        Xs = StandardScaler().fit_transform(X)
        s = SGBO(return_info=True); info = s.fit_resample(Xs, y, np.random.default_rng(0))[2]
        agg["neg"] += int((y == 0).sum()); agg["cand"] += int((info["b"][y == 0] > 0).sum())
        agg["seeds"] += info["n_seeds"]; agg["gen"] += info["n_cand"]; agg["acc"] += info["n_acc"]; agg["N"] += info["N"]
        used = min(info["n_acc"], info["N"]); agg["used"] += used; agg["fill"] += info["N"] - used
    json.dump(agg, open(f"{RES}/sankey_counts.json", "w"), indent=1)
    C = {"negative samples": "#8fb3d9", "interior ($b=0$)": "#d0d0d0", "boundary ($b>0$)": "#d08c3c",
         "not drawn": "#e3c9a6", "seeds": "#b2182b",
         "candidates": "#7d3c98", "accepted": "#2e7d32", "rejected": "#9e9e9e", "kept": "#1b5e20",
         "surplus": "#a5d6a7", "refilled": "#c0ca33", "discarded": "#bdbdbd"}
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.7))
    a = agg
    sankey(axs[0], [[("negative samples", a["neg"])],
                    [("boundary ($b>0$)", a["cand"]), ("interior ($b=0$)", a["neg"] - a["cand"])],
                    [("seeds", a["seeds"]), ("not drawn", a["cand"] - a["seeds"])]],
           [("negative samples", "boundary ($b>0$)", a["cand"]), ("negative samples", "interior ($b=0$)", a["neg"] - a["cand"]),
            ("boundary ($b>0$)", "seeds", a["seeds"]), ("boundary ($b>0$)", "not drawn", a["cand"] - a["seeds"])],
           C, "(a) seed selection (unit: majority samples)")
    rej = a["gen"] - a["acc"]
    sankey(axs[1], [[("candidates", a["gen"])],
                    [("accepted", a["acc"]), ("rejected", rej)],
                    [("kept", a["used"]), ("surplus", a["acc"] - a["used"]), ("refilled", a["fill"]), ("discarded", rej - a["fill"])]],
           [("candidates", "accepted", a["acc"]), ("candidates", "rejected", rej),
            ("accepted", "kept", a["used"]), ("accepted", "surplus", a["acc"] - a["used"]),
            ("rejected", "refilled", a["fill"]), ("rejected", "discarded", rej - a["fill"])],
           C, "(b) generation filter (unit: synthetic candidates)")
    save(fig, "fig10_sankey")
    return agg


if __name__ == "__main__":
    os.makedirs(RES, exist_ok=True)
    fig_score_field(); print("field")
    fig_consistency(); print("consistency")
    print(fig_trajectories()["k"])
    print(fig_sankey())
