"""Figures of the revised manuscript (v2)."""
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import style
from style import plt, COL, MLAB
from analysis_v2 import load, unit_matrix, friedman, METHODS, CLFS
import networkx as nx

RES = "../results"
OUT = "../manuscript_v2/figures"
SHORT = {"None": "None", "ROS": "ROS", "SMOTE": "SMOTE", "B-SMOTE": "B-SMOTE", "ADASYN": "ADASYN",
         "SVM-SMOTE": "SVM-SM", "SMOTE-ENN": "SM-ENN", "KM-SMOTE": "KM-SM", "MWMOTE": "MWMOTE",
         "CCR": "CCR", "BDO": "BDO", "SGBO": "SGBO"}
LINE = ["None", "SMOTE", "B-SMOTE", "SVM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MK = {"None": "x", "SMOTE": "o", "B-SMOTE": "s", "SVM-SMOTE": "D", "MWMOTE": "v", "CCR": "P", "BDO": "^", "SGBO": "*"}


def save(fig, name):
    style.save(fig, name, OUT)


# ---------------------------------------------------------------------------- F4
def fig_synthetic():
    s = pd.read_csv(f"{RES}/synthetic_study.csv", keep_default_na=False, na_values=[""])
    cons = json.load(open("../results/consistency.json"))
    fig, axs = plt.subplots(2, 4, figsize=(7.0, 3.9))
    ax = axs[0, 0]
    ns = cons["ns"]
    for key, c, mk in (("BDO ($k=n^+$)", COL["BDO"], "^"), ("SGBO (adaptive, weighted)", COL["SGBO"], "*")):
        m = np.array([a for a, _ in cons["mae"][key]])
        ax.plot(ns, m, "-", marker=mk, color=c, ms=4, lw=1.2, label="BDO" if "BDO" in key else "SGBO")
    ax.set_xscale("log"); ax.set_xlabel(r"$n$"); ax.set_ylabel(r"error of $\hat b$"); ax.set_title(r"(a) error vs. $n$")
    ax.legend(frameon=False, fontsize=6)

    def by(factor, col, groupby_method=True):
        d = s[s.factor == factor]
        if groupby_method:
            return d.groupby(["value", "method"])[col].mean().unstack()
        return d.groupby("value")[col].mean()

    ax = axs[0, 1]
    for key, c, mk in (("BDO", COL["BDO"], "^"), ("SGBO", COL["SGBO"], "*")):
        e = s[(s.factor == "s") & (s.method == "None") & (s.clf == "RF")].groupby("value")[f"err_{key}"].agg(["mean", "std"])
        ax.errorbar(e.index, e["mean"], yerr=e["std"], color=c, marker=mk, ms=4, lw=1.1, capsize=2, label=key)
    ax.set_xlabel(r"separation $s$"); ax.set_title(r"(b) error vs. overlap"); ax.legend(frameon=False, fontsize=6)

    def lines(ax, factor, col, title, xlabel, logx=False, avg_clf=True):
        d = s[s.factor == factor]
        t = d.groupby(["value", "method"])[col].mean().unstack()
        for m in LINE:
            if m not in t or t[m].isna().all():
                continue
            ax.plot(t.index, t[m], "-", marker=MK[m], ms=3.2 if m != "SGBO" else 5, lw=1.5 if m == "SGBO" else 0.8,
                    color=COL[m], label=SHORT[m], zorder=5 if m == "SGBO" else 2)
        if logx:
            ax.set_xscale("log")
        ax.set_title(title); ax.set_xlabel(xlabel)

    lines(axs[0, 2], "rho", "deep_majority", r"(c) share with $\eta(z)<\pi$", r"label noise $\rho$")
    lines(axs[0, 3], "rho", "near_flipped", "(d) share next to flipped labels", r"label noise $\rho$")
    ref = s[(s.factor == "rho") & (s.method == "SGBO") & (s.clf == "RF")].groupby("value")["flip_ref"].mean()
    axs[0, 3].plot(ref.index, ref.values, ":", color="k", lw=1.0, label="flipped share of $P$")
    lines(axs[1, 0], "s", "mcc", "(e) MCC vs. overlap", r"separation $s$")
    lines(axs[1, 1], "rho", "mcc", "(f) MCC vs. label noise", r"label noise $\rho$")
    lines(axs[1, 2], "ir", "mcc", "(g) MCC vs. imbalance", r"IR", logx=True)
    lines(axs[1, 3], "q", "mcc", "(h) MCC vs. dimension", r"irrelevant features $q$")
    for a in axs.ravel():
        a.grid(alpha=0.25, lw=0.4); a.tick_params(labelsize=6.5); a.title.set_fontsize(7.6); a.xaxis.label.set_fontsize(7.5)
    axs[1, 0].set_ylabel("MCC"); axs[0, 0].set_ylabel(r"error of $\hat b$")
    h, l = axs[0, 3].get_legend_handles_labels()
    h0, l0 = axs[1, 0].get_legend_handles_labels()
    h, l = h0 + h[-1:], l0 + l[-1:]
    fig.legend(h, l, loc="lower center", ncol=8, frameon=False, fontsize=6.8, bbox_to_anchor=(0.5, -0.035))
    fig.tight_layout(rect=(0, 0.04, 1, 1), h_pad=0.6, w_pad=0.4)
    save(fig, "fig04_synthetic")


# ---------------------------------------------------------------------------- F5
def fig_heatmap(df, metric="mcc"):
    M = unit_matrix(df, metric)
    from datasets import task_registry
    order = []
    for t in task_registry(include_new=True):
        if t["source"] not in order:
            order.append(t["source"])
    M = M.loc[[o for o in order if o in M.index]]
    R = M.rank(axis=1, ascending=False)
    fig, ax = plt.subplots(figsize=(6.9, 5.6))
    im = ax.imshow(M.values, cmap="RdYlBu_r", aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{M.values[i, j]:.2f}", ha="center", va="center", fontsize=5.6)
            if R.values[i, j] == 1:
                ax.add_patch(plt.Rectangle((j - .5, i - .5), 1, 1, fill=False, ec="k", lw=0.9))
    ax.set_xticks(range(M.shape[1])); ax.set_xticklabels([SHORT[m] for m in M.columns], rotation=35, ha="right", fontsize=7)
    ax.set_yticks(range(M.shape[0])); ax.set_yticklabels(M.index, fontsize=6.5)
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.015); cb.set_label(f"mean {MLAB[metric]} per source (4 classifiers)")
    save(fig, "fig05_heatmap_units")
    return M


# ---------------------------------------------------------------------------- F6
def fig_classifier_ranks(df):
    fig, axs = plt.subplots(2, 1, figsize=(6.9, 3.9), sharex=True)
    shades = {"RF": "#3b3b3b", "SVM": "#7a7a7a", "kNN": "#b0b0b0", "LR": "#dcdcdc"}
    hatch = {"RF": "", "SVM": "///", "kNN": "...", "LR": "xx"}
    x = np.arange(len(METHODS)); w = 0.2
    out = {}
    for ax, met in zip(axs, ["mcc", "aucpr"]):
        for i, c in enumerate(CLFS):
            r = friedman(unit_matrix(df, met, clf=c))["ranks"]
            out[(met, c)] = r
            vals = [r[m] for m in METHODS]
            bars = ax.bar(x + (i - 1.5) * w, vals, w, color=shades[c], edgecolor="k", lw=0.35, hatch=hatch[c], label=c)
            bars[-1].set_facecolor(COL["SGBO"]); bars[-1].set_alpha(0.45 + 0.15 * i)
        ax.set_ylabel(f"avg. rank ({MLAB[met]})"); ax.grid(axis="y", alpha=0.3, lw=0.4)
        ax.axhline((len(METHODS) + 1) / 2, color="k", lw=0.5, ls=":")
    axs[1].set_xticks(x); axs[1].set_xticklabels([SHORT[m] for m in METHODS], fontsize=7)
    axs[0].legend(ncol=4, frameon=False, loc="upper center", bbox_to_anchor=(0.5, 1.28), fontsize=7)
    save(fig, "fig06_classifier_ranks")
    return out


# ---------------------------------------------------------------------------- F7
def fig_radar(df):
    ms = ["aucpr", "mcc", "f1", "gmean", "auc"]
    show = ["SMOTE", "B-SMOTE", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    means = {m: unit_matrix(df, m).mean() for m in ms}
    ang = np.linspace(0, 2 * np.pi, len(ms), endpoint=False).tolist(); ang += ang[:1]
    fig = plt.figure(figsize=(6.6, 2.9))
    for p, (title, norm) in enumerate((("(a) mean over 26 sources", False), ("(b) min--max normalised", True))):
        ax = fig.add_subplot(1, 2, p + 1, polar=True)
        for k in show:
            v = []
            for m in ms:
                sv = means[m][show]; val = means[m][k]
                v.append((val - sv.min()) / (sv.max() - sv.min() + 1e-12) if norm else val)
            v += v[:1]
            ax.plot(ang, v, color=COL[k], lw=1.6 if k == "SGBO" else 0.9, label=SHORT[k],
                    ls="-" if k in ("SGBO", "BDO") else "--")
            if k == "SGBO":
                ax.fill(ang, v, color=COL[k], alpha=0.15)
        ax.set_xticks(ang[:-1]); ax.set_xticklabels([MLAB[m] for m in ms], fontsize=7.5)
        ax.tick_params(axis="y", labelsize=6); ax.set_title(title, pad=12)
        if norm:
            ax.set_ylim(0, 1.05); ax.set_yticks([0.25, 0.5, 0.75, 1.0])
        else:
            lo = min(means[m][show].min() for m in ms); ax.set_ylim(lo - 0.08, None)
    fig.legend(*ax.get_legend_handles_labels(), loc="lower center", ncol=8, frameon=False, bbox_to_anchor=(0.5, -0.06), fontsize=6.8)
    save(fig, "fig07_radar")


# ---------------------------------------------------------------------------- F8
def fig_effects(df, stats_all):
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.9), sharey=False)
    comp = [m for m in METHODS if m != "SGBO"]
    for ax, met in zip(axs, ["mcc", "aucpr"]):
        M = unit_matrix(df, met)
        D = [(M["SGBO"] - M[m]).values for m in comp]
        bp = ax.boxplot(D, widths=0.55, patch_artist=True, showfliers=False, medianprops=dict(color="k", lw=0.9),
                        boxprops=dict(lw=0.5), whiskerprops=dict(lw=0.5), capprops=dict(lw=0.5))
        for patch, m in zip(bp["boxes"], comp):
            patch.set_facecolor(COL[m]); patch.set_alpha(0.55)
        rng = np.random.default_rng(0)
        for i, d in enumerate(D):
            ax.scatter(i + 1 + rng.uniform(-0.17, 0.17, len(d)), d, s=2.5, c="k", alpha=0.45, lw=0, zorder=3)
            ph = stats_all[met]["posthoc"][comp[i]]
            ax.errorbar(i + 1.32, ph["mean"], yerr=[[ph["mean"] - ph["ci_lo"]], [ph["ci_hi"] - ph["mean"]]],
                        fmt="D", ms=2.8, color=COL["SGBO"], lw=0.9, capsize=1.5, zorder=4)
            if ph["reject"]:
                ax.text(i + 1, ax.get_ylim()[1] if False else max(d.max(), ph["ci_hi"]) + 0.01, "*", ha="center", fontsize=8)
        ax.axhline(0, color="k", lw=0.6, ls="--")
        ax.set_xticks(range(1, len(comp) + 1)); ax.set_xticklabels([SHORT[m] for m in comp], rotation=55, ha="right", fontsize=6.5)
        ax.set_title(f"({'a' if met == 'mcc' else 'b'}) $\\Delta${MLAB[met]} = SGBO $-$ method"); ax.grid(axis="y", alpha=0.3, lw=0.4)
    save(fig, "fig08_effect_sizes")


# ---------------------------------------------------------------------------- F9
def fig_network(df):
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 3.1))
    out = {}
    for ax, met, ttl in ((axs[0], "mcc", "(a) MCC"), (axs[1], "aucpr", "(b) AUC-PR")):
        fr = friedman(unit_matrix(df, met)); cd, r = fr["cd"], fr["ranks"]
        # directed edge A -> B: A has a lower (better) mean rank than B by more than the Nemenyi CD
        G = nx.DiGraph(); G.add_nodes_from(METHODS)
        for a in METHODS:
            for b in METHODS:
                if r[b] - r[a] > cd:
                    G.add_edge(a, b)
        srt = sorted(METHODS, key=lambda k: r[k])
        ang = np.linspace(np.pi / 2, np.pi / 2 - 2 * np.pi, len(srt), endpoint=False)
        pos = {k: (np.cos(a), np.sin(a)) for k, a in zip(srt, ang)}
        nx.draw_networkx_edges(G, pos, ax=ax, edge_color="#555555", width=0.7, arrows=True, arrowsize=6,
                               arrowstyle="-|>", node_size=300, connectionstyle="arc3,rad=0.08")
        sizes = [420 * (fr["k"] + 1 - r[k]) / fr["k"] for k in METHODS]
        nx.draw_networkx_nodes(G, pos, ax=ax, nodelist=METHODS, node_size=sizes, node_color=[COL[k] for k in METHODS],
                               edgecolors="k", linewidths=0.5)
        for k, (x, y) in pos.items():
            ha = "left" if x > 0.2 else ("right" if x < -0.2 else "center")
            ax.text(1.2 * x + (0.06 if x > 0.2 else -0.06 if x < -0.2 else 0), (1.22 if abs(x) > 0.2 else 1.34) * y,
                    f"{SHORT[k]} ({r[k]:.2f})", ha=ha, va="center", fontsize=6.3)
        ax.set_xlim(-2.1, 2.1); ax.set_ylim(-1.5, 1.5); ax.set_aspect("equal"); ax.axis("off")
        ax.set_title(f"{ttl}: CD = {cd:.2f}")
        out[met] = dict(cd=cd, ranks=r)
    save(fig, "fig09_network_cd")
    return out


# ---------------------------------------------------------------------------- F10
def fig_ir(df):
    from datasets import task_registry
    IR = {t["name"]: (len(t["y"]) - t["y"].sum()) / t["y"].sum() for t in task_registry()}
    t = df.groupby(["dataset", "method"])["mcc"].mean().unstack()
    fig, axs = plt.subplots(1, 2, figsize=(6.9, 2.7), gridspec_kw=dict(width_ratios=[1.1, 1]))
    ax = axs[0]
    for comp, mk in (("SVM-SMOTE", "D"), ("SMOTE", "o"), ("BDO", "^")):
        d = (t["SGBO"] - t[comp]); x = np.array([IR[k] for k in d.index])
        ax.scatter(x, d.values, s=10, marker=mk, color=COL[comp], alpha=0.75, label=f"SGBO $-$ {SHORT[comp]}", lw=0.3, edgecolors="k")
        o = np.argsort(x); lx = np.log(x[o]); yy = d.values[o]
        # running median over IR (window of 9 tasks)
        med = [np.median(yy[max(0, i - 4):i + 5]) for i in range(len(yy))]
        ax.plot(x[o], med, "-", color=COL[comp], lw=1.1)
    ax.axhline(0, color="k", lw=0.6, ls="--"); ax.set_xscale("log"); ax.set_xlabel("imbalance ratio (task)")
    ax.set_ylabel(r"$\Delta$MCC"); ax.set_title("(a) difference per task (lines: running median)"); ax.legend(frameon=False, fontsize=6.3)
    ax.grid(alpha=0.25, lw=0.4)
    ax = axs[1]
    bins = [(0, 3, "IR$<$3"), (3, 10, "3--10"), (10, 20, "10--20"), (20, 1e9, "$>$20")]
    show = ["SMOTE", "SVM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    res = {}
    for lo, hi, lab in bins:
        names = [k for k in t.index if lo <= IR[k] < hi]
        sub = df[df.dataset.isin(names)]
        M = sub.groupby(["dataset", "clf", "method"])["mcc"].mean().groupby(["dataset", "method"]).mean().unstack()[METHODS]
        rk = M.rank(axis=1, ascending=False).mean()
        res[lab] = (len(names), rk)
    xs = np.arange(len(bins))
    for m in show:
        ax.plot(xs, [res[b[2]][1][m] for b in bins], "-", marker=MK.get(m, "o"), color=COL[m], lw=1.5 if m == "SGBO" else 0.9,
                ms=5 if m == "SGBO" else 3.5, label=SHORT[m])
    ax.set_xticks(xs); ax.set_xticklabels([f"{b[2]}\n({res[b[2]][0]} tasks)" for b in bins], fontsize=6.8)
    ax.invert_yaxis(); ax.set_ylabel("avg. rank (MCC)"); ax.set_title("(b) rank by imbalance group (descriptive)")
    ax.grid(alpha=0.25, lw=0.4); ax.legend(frameon=False, fontsize=6, ncol=2)
    save(fig, "fig10_imbalance")
    return {k: (v[0], v[1].round(2).to_dict()) for k, v in res.items()}


# ---------------------------------------------------------------------------- F12
def _band(ax, x0, y0a, y0b, x1, y1a, y1b, color, alpha=0.45):
    from matplotlib.patches import PathPatch
    from matplotlib.path import Path
    xm = (x0 + x1) / 2
    verts = [(x0, y0a), (xm, y0a), (xm, y1a), (x1, y1a), (x1, y1b), (xm, y1b), (xm, y0b), (x0, y0b), (x0, y0a)]
    codes = [Path.MOVETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.LINETO, Path.CURVE4, Path.CURVE4, Path.CURVE4, Path.CLOSEPOLY]
    ax.add_patch(PathPatch(Path(verts, codes), fc=color, ec="none", alpha=alpha))


def sankey(ax, columns, flows, colors, title, width=0.07, gap=0.035):
    columns = [[(n, v) for n, v in col if v > 0] for col in columns]
    flows = [f for f in flows if f[2] > 0]
    tot = max(sum(v for _, v in col) for col in columns)
    pos = {}; xs = np.linspace(0, 1, len(columns))
    for ci, col in enumerate(columns):
        n = len(col); scale = (1 - gap * (n - 1)) / tot
        y = 1 - (1 - (sum(v for _, v in col) * scale + gap * (n - 1))) / 2
        for name, v in col:
            h = v * scale
            pos[name] = dict(x=xs[ci], out=y, inn=y, scale=scale)
            ax.add_patch(plt.Rectangle((xs[ci] - width / 2, y - h), width, h, fc=colors.get(name, "#555"), ec="k", lw=0.4, zorder=3))
            last = ci == len(columns) - 1
            ax.text(xs[ci] + (-width / 2 - 0.01 if last else width / 2 + 0.01), y - h / 2, f"{name}\n{v:,}",
                    ha="right" if last else "left", va="center", fontsize=5.6, zorder=4,
                    bbox=dict(fc="white", ec="none", alpha=0.7, pad=0.5))
            y -= h + gap
    for s_, d_, v in flows:
        ps, pd_ = pos[s_], pos[d_]
        hs, hd = v * ps["scale"], v * pd_["scale"]
        _band(ax, ps["x"] + width / 2, ps["out"], ps["out"] - hs, pd_["x"] - width / 2, pd_["inn"], pd_["inn"] - hd, colors.get(d_, "#888"))
        ps["out"] -= hs; pd_["inn"] -= hd
    ax.set_xlim(-0.06, 1.06); ax.set_ylim(-0.02, 1.02); ax.axis("off"); ax.set_title(title, fontsize=7.6)


def fig_ablation_runtime_sankey():
    a = pd.read_csv(f"{RES}/ablation.csv", keep_default_na=False, na_values=[""])
    rt = pd.read_csv(f"{RES}/runtime.csv")
    ag = json.load(open(f"{RES}/sankey_v2.json"))
    fig = plt.figure(figsize=(7.0, 5.0))
    gs = fig.add_gridspec(2, 3, height_ratios=[1.05, 0.95], hspace=0.45, wspace=0.55)
    ax = fig.add_subplot(gs[0, 0:2])
    t = a.groupby(["source", "dataset", "clf", "method"])["mcc"].mean().groupby(["source", "method"]).mean().unstack()
    full = t["SGBO"]; var = [c for c in t.columns if c != "SGBO"]
    diff = pd.DataFrame({v: t[v] - full for v in var})
    mean = diff.mean(); rng = np.random.default_rng(0)
    B = np.array([diff.values[rng.integers(0, len(diff), len(diff))].mean(0) for _ in range(5000)])
    lo, hi = pd.Series(np.quantile(B, 0.025, 0), index=var), pd.Series(np.quantile(B, 0.975, 0), index=var)
    order = mean.sort_values().index
    pretty = {"w/o noise (tau=0)": r"w/o noise ($\tau=0$)", "w/o adaptive k": r"w/o adaptive $k$"}
    y = np.arange(len(order))
    ax.barh(y, mean[order], xerr=[mean[order] - lo[order], hi[order] - mean[order]],
            color=["#b2182b" if v < 0 else "#2166ac" for v in mean[order]], alpha=0.75, edgecolor="k", lw=0.4,
            error_kw=dict(lw=0.6, capsize=2))
    # real sources only (20), shown as diamonds
    real_src = [s_ for s_ in t.index if not s_.lower().startswith("syn")]
    from datasets import task_registry as _tr
    kind = {r_["source"]: r_["kind"] for r_ in _tr()}
    real_src = [s_ for s_ in t.index if not kind[s_].startswith("synthetic")]
    mean_real = diff.loc[real_src].mean()
    ax.scatter(mean_real[order], y, marker="D", s=14, color="k", zorder=5, label="20 real sources only")
    ax.legend(frameon=False, fontsize=6, loc="upper left")
    ax.set_yticks(y); ax.set_yticklabels([pretty.get(o, o) for o in order], fontsize=6.8); ax.axvline(0, color="k", lw=0.6)
    ax.set_xlabel(r"$\Delta$MCC w.r.t. full SGBO (bars: 26 sources, 95% bootstrap CI)", fontsize=7)
    ax.set_title("(a) ablation", fontsize=7.8); ax.grid(axis="x", alpha=0.3, lw=0.4)
    ax = fig.add_subplot(gs[0, 2])
    for m in rt.method.unique():
        r = rt[rt.method == m]
        ax.plot(r.n, r.time, "-o", ms=2.5, lw=1.4 if m in ("SGBO", "BDO") else 0.8, color=COL[m], label=SHORT[m])
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([500, 1000, 2000, 4000, 8000])
    ax.set_xticklabels(["500", "1k", "2k", "4k", "8k"], fontsize=6.5); ax.xaxis.set_minor_formatter(plt.NullFormatter())
    ax.set_xlabel(r"training size $n$", fontsize=7); ax.set_ylabel("time (s)", fontsize=7); ax.set_title("(b) resampling time", fontsize=7.8)
    ax.grid(alpha=0.3, lw=0.4, which="both"); ax.legend(frameon=False, fontsize=5, ncol=2, loc="upper left")
    C = {"majority points": "#8fb3d9", "$b=0$": "#d0d0d0", "$b>0$": "#d08c3c", "not drawn": "#e3c9a6", "seeds": "#b2182b",
         "chains": "#b2182b", "reached $\\theta$": "#2e7d32", "stopped at $T$": "#c0ca33",
         "candidates": "#7d3c98", "accepted": "#2e7d32", "rejected": "#9e9e9e", "used": "#1b5e20", "surplus": "#a5d6a7"}
    g = ag
    ax = fig.add_subplot(gs[1, 0])
    sankey(ax, [[("majority points", g["neg"])], [("$b>0$", g["cand"]), ("$b=0$", g["neg"] - g["cand"])],
                [("seeds", g["seeds"]), ("not drawn", g["cand"] - g["seeds"])]],
           [("majority points", "$b>0$", g["cand"]), ("majority points", "$b=0$", g["neg"] - g["cand"]),
            ("$b>0$", "seeds", g["seeds"]), ("$b>0$", "not drawn", g["cand"] - g["seeds"])], C, "(c) seed selection")
    ax = fig.add_subplot(gs[1, 1])
    sankey(ax, [[("chains", g["chains"])], [("reached $\\theta$", g["chains"] - g["unfinished"]), ("stopped at $T$", g["unfinished"])]],
           [("chains", "reached $\\theta$", g["chains"] - g["unfinished"]), ("chains", "stopped at $T$", g["unfinished"])], C, "(d) transport")
    ax = fig.add_subplot(gs[1, 2])
    rej = g["gen"] - g["acc"]
    sankey(ax, [[("candidates", g["gen"])], [("accepted", g["acc"]), ("rejected", rej)],
                [("used", g["used"]), ("surplus", g["acc"] - g["used"])]],
           [("candidates", "accepted", g["acc"]), ("candidates", "rejected", rej), ("accepted", "used", g["used"]),
            ("accepted", "surplus", g["acc"] - g["used"])], C, "(e) acceptance test")
    save(fig, "fig12_ablation_runtime_flow")
    return dict(mean=mean.to_dict(), lo=lo.to_dict(), hi=hi.to_dict())


def sankey_counts():
    from datasets import task_registry
    from sklearn.preprocessing import StandardScaler
    from samplers import SGBO
    agg = dict(neg=0, cand=0, seeds=0, chains=0, unfinished=0, gen=0, acc=0, used=0, fill=0, N=0)
    for t in task_registry():
        X = StandardScaler().fit_transform(t["X"]); y = t["y"]
        s = SGBO(return_info=True); info = s.fit_resample(X, y, np.random.default_rng(0))[2]
        dg = s.diag_
        agg["neg"] += int((y == 0).sum()); agg["cand"] += int((info["b"][y == 0] > 0).sum()); agg["seeds"] += info["n_seeds"]
        agg["chains"] += dg["chains"]; agg["unfinished"] += dg["chains_unfinished"]; agg["gen"] += dg["n_cand"]
        agg["acc"] += dg["n_acc"]; agg["N"] += info["N"]; agg["fill"] += dg["n_fill"]
        agg["used"] += info["N"] - dg["n_fill"]
    json.dump(agg, open(f"{RES}/sankey_v2.json", "w"), indent=1)
    return agg


# ---------------------------------------------------------------------------- F11
def fig_sensitivity():
    s = pd.read_csv(f"{RES}/sensitivity.csv")
    t = s.groupby(["eta", "tau"])["mcc"].mean().unstack()
    E, Tg = np.meshgrid(t.index.values, t.columns.values, indexing="ij")
    fig = plt.figure(figsize=(6.9, 3.0))
    gs = fig.add_gridspec(1, 2, width_ratios=[1.15, 1], wspace=0.42)
    ax = fig.add_subplot(gs[0], projection="3d", computed_zorder=False)
    ax.plot_surface(E, Tg, t.values, cmap="viridis", edgecolor="k", lw=0.3, alpha=0.92, rstride=1, cstride=1)
    ax.scatter([0.5], [0.1], [t.loc[0.5, 0.1] + 0.002], color="#b2182b", edgecolor="k", s=26, depthshade=False, zorder=10)
    ax.set_xlabel(r"step $\eta$", labelpad=-2); ax.set_ylabel(r"temperature $\tau$", labelpad=-2); ax.set_zlabel("")
    ax.tick_params(labelsize=6, pad=-1); ax.view_init(elev=26, azim=-48)
    ax.set_title("(a) mean MCC over $(\\eta,\\tau)$; red dot: default")
    ax2 = fig.add_subplot(gs[1])
    g = s.groupby(["dataset", "tau"])["mcc"].mean().unstack()
    g = g.sub(g.mean(axis=1), axis=0)
    for d, row in g.iterrows():
        ax2.plot(row.index, row.values, "-o", ms=2.5, lw=0.9, label=d)
    ax2.set_xlabel(r"temperature $\tau$"); ax2.set_ylabel("centred MCC"); ax2.grid(alpha=0.3, lw=0.4)
    ax2.set_title(r"(b) effect of $\tau$ (averaged over $\eta$)"); ax2.legend(frameon=False, fontsize=6, ncol=2)
    save(fig, "fig11_sensitivity")
    return dict(grid=t.round(4).to_dict(), best=[float(t.stack().idxmax()[0]), float(t.stack().idxmax()[1])],
                best_val=float(t.stack().max()), default=float(t.loc[0.5, 0.1]), worst=float(t.stack().min()))


if __name__ == "__main__":
    which = sys.argv[1:] or ["main"]
    if "main" in which:
        df = load()
        st = json.load(open(f"{RES}/stats_v2.json"))["all_tasks"]
        fig_heatmap(df); cr = fig_classifier_ranks(df); fig_radar(df); fig_effects(df, st); net = fig_network(df); ir = fig_ir(df)
        json.dump({"ir_groups": ir}, open(f"{RES}/fig_v2_summary.json", "w"), indent=1, default=float)
        print(ir)
    if "synthetic" in which:
        fig_synthetic()
    if "sankey" in which:
        print(sankey_counts())
    if "sens" in which:
        print(fig_sensitivity())
    if "extra" in which:
        print(fig_ablation_runtime_sankey())
