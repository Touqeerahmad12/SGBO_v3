"""LaTeX tables of the revised manuscript and its supplement, written from the result files."""
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis_v2 import load, unit_matrix, friedman, METHODS, CLFS
from datasets import task_registry

RES, OUT = "../results", "../manuscript_v2/tables"
os.makedirs(OUT, exist_ok=True)
LAB = {"gmean": "G-mean", "f1": "F1", "aucpr": "AUC-PR", "mcc": "MCC", "auc": "AUC"}
SHORT = {"SVM-SMOTE": "SVM-SMOTE", "SMOTE-ENN": "SMOTE-ENN", "KM-SMOTE": "$k$M-SMOTE"}


def sci(p):
    if p >= 1e-3:
        return f"{p:.3f}"
    m, e = f"{p:.1e}".split("e")
    return f"${m}\\times10^{{{int(e)}}}$"


def name(m):
    return SHORT.get(m, m)


df = load()
st = json.load(open(f"{RES}/stats_v2.json"))
S = st["all_tasks"]
reg = task_registry()
facts = {}

# ---------------------------------------------------------------- data table
groups = [("real (scikit-learn)", "Real tasks derived from data sets distributed with scikit-learn"),
          ("real (KEEL)", "Independent real data sets (KEEL versions)"),
          ("real (UCI, fixed split)", None), ("synthetic", "Synthetic tasks")]
lines, i = [], 0
for kind, title in groups:
    rows = [t for t in reg if t["kind"] == kind]
    if title:
        lines.append(f"\\multicolumn{{9}}{{@{{}}l}}{{\\textit{{{title}}}}}\\\\")
    for t in rows:
        i += 1
        n, npos = len(t["y"]), int(t["y"].sum())
        mark = "$^{\\ast}$" if t["primary"] else ""
        nm = t["name"] + ("$^{\\dagger}$" if t.get("split") is not None else "")
        lines.append(f"T{i} & \\texttt{{{t['name']}}}{mark}{'$^{\\dagger}$' if t.get('split') is not None else ''} & {t['source']} & {n} & {t['X'].shape[1]} & {npos} & {n - npos} & {(n - npos) / npos:.2f} & {t['definition'].replace('%', chr(92) + '%').replace('_', chr(92) + '_')} \\\\")
    if kind != "synthetic" and kind != "real (KEEL)":
        lines.append("\\midrule")
open(f"{OUT}/tab_data.tex", "w").write("\n".join(lines))

# ---------------------------------------------------------------- main table
MAIN = ["aucpr", "mcc", "f1", "gmean", "auc"]
best_mean = {m: max(S[m]["mean"][k] for k in METHODS) for m in MAIN}
best_rank = {m: min(S[m]["ranks"].values()) for m in MAIN}
lines = []
avg = {k: np.mean([S[m]["ranks"][k] for m in ["aucpr", "mcc", "f1", "gmean"]]) for k in METHODS}
best_avg = min(avg.values())
for k in METHODS:
    cells = []
    for m in MAIN:
        v, r, sd = S[m]["mean"][k], S[m]["ranks"][k], S[m]["std"][k]
        sv = f"{v:.3f}"; sr = f"{r:.2f}"
        if abs(v - best_mean[m]) < 1e-12: sv = f"\\textbf{{{sv}}}"
        if abs(r - best_rank[m]) < 1e-12: sr = f"\\textbf{{{sr}}}"
        cells.append(f"{sv} ({sr})")
    a = f"{avg[k]:.2f}"
    if abs(avg[k] - best_avg) < 1e-12: a = f"\\textbf{{{a}}}"
    lines.append(f"{'\\textbf{SGBO}' if k == 'SGBO' else name(k)} & " + " & ".join(cells) + f" & {a} \\\\")
open(f"{OUT}/tab_main.tex", "w").write("\n".join(lines))
facts["avg_rank4"] = avg

# ---------------------------------------------------------------- Friedman summary
lines = []
for m in ["aucpr", "mcc", "f1", "gmean", "auc"]:
    s = S[m]
    per = " & ".join(f"{st['all_tasks'][f'{m}_{c}']['ranks']['SGBO']:.2f}" for c in CLFS)
    lines.append(f"{LAB[m]} & {s['chi2']:.2f} & {s['FF']:.2f} & {sci(s['p_FF'])} & {s['ranks']['SGBO']:.2f} & {per} & {st['primary_only'][m]['ranks']['SGBO']:.2f} \\\\")
open(f"{OUT}/tab_friedman.tex", "w").write("\n".join(lines))
facts["friedman"] = {m: dict(chi2=S[m]["chi2"], FF=S[m]["FF"], p=S[m]["p_FF"], Fcrit=S[m]["Fcrit"], cd=S[m]["cd"]) for m in MAIN}

# ---------------------------------------------------------------- post-hoc
def posthoc_rows(mets):
    lines = []
    for k in [k for k in METHODS if k != "SGBO"]:
        cells = []
        for m in mets:
            ph = S[m]["posthoc"][k]
            p = sci(ph["p_holm"])
            if ph["reject"]:
                p = ("{\\boldmath" + p + "}") if p.startswith("$") else f"\\textbf{{{p}}}"
            cells.append(f"{ph['mean']:+.3f} [{ph['ci_lo']:+.3f}, {ph['ci_hi']:+.3f}] & {ph['wins']}/{ph['losses']} & {p}")
        lines.append(f"{name(k)} & " + " & ".join(cells) + " \\\\")
    return "\n".join(lines).replace("+", "$+$").replace("[-", "[$-$").replace(" -", " $-$")
open(f"{OUT}/tab_posthoc.tex", "w").write(posthoc_rows(["aucpr", "mcc"]))
open(f"{OUT}/supp_posthoc.tex", "w").write(posthoc_rows(["f1", "gmean"]))

# ---------------------------------------------------------------- exceptions
sg = df[(df.method == "SGBO") & (df.clf == "RF")]
calls = len(sg)
d = {c: sg[c].sum() for c in sg.columns if c.startswith("diag_")}
chains = d["diag_chains"]
rows = [
    ("$n^-\\le n^+$ (already balanced)", "data returned unchanged", f"0 of {calls} calls"),
    ("$n^+<2$ (too few minority points)", "data returned unchanged", f"{int(d['diag_too_few_minority'])} of {calls} calls"),
    ("no candidate seed ($C=\\emptyset$)", "seeds drawn uniformly from $P$", f"{int(d['diag_no_candidates'])} of {calls} calls"),
    ("chain does not reach $\\theta$ within $T$ steps", "last iterate kept as anchor; the acceptance test decides", f"{int(d['diag_chains_unfinished']):,} of {int(chains):,} chains ({100 * d['diag_chains_unfinished'] / chains:.1f}\\%)"),
    ("local set of one point or with zero trace", "$\\Sigma_i=h^2I_d$", f"{int(d['diag_cov_single'] + d['diag_cov_zero_trace'])} local models"),
    ("Ledoit--Wolf intensity below $\\rho_{\\min}$", "intensity raised to $\\rho_{\\min}=0.01$", f"{int(d['diag_rho_clipped'])} local models"),
    ("fewer than $N_{\\text{new}}$ points accepted after five rounds", "highest-scoring rejected candidates added", f"{int((sg['diag_n_fill'] > 0).sum())} calls; {int(d['diag_n_fill']):,} of {int((sg['n_after'] - 0).sum()):,} points"),
]
acc_rate = d["diag_n_acc"] / d["diag_n_cand"]
open(f"{OUT}/tab_exceptions.tex", "w").write("\n".join(f"{a} & {b} & {c} \\\\" for a, b, c in rows))
facts["exceptions"] = {k: float(v) for k, v in d.items()}; facts["calls"] = calls; facts["acc_rate"] = float(acc_rate)

# ---------------------------------------------------------------- tuning
if os.path.exists(f"{RES}/tuning.csv"):
    tu = pd.read_csv(f"{RES}/tuning.csv", keep_default_na=False, na_values=[""])
    names = tu.dataset.unique().tolist()
    base = df[(df.rep == 0) & df.dataset.isin(names) & df.clf.isin(["RF", "kNN"])]
    lines = []
    Mt = {}
    for met in ["mcc", "aucpr"]:
        Mt[met] = (tu.groupby(["source", "clf", "method"])[met].mean().groupby(["source", "method"]).mean().unstack(),
                   base.groupby(["source", "clf", "method"])[met].mean().groupby(["source", "method"]).mean().unstack())
    tuned_methods = list(tu.method.unique())
    allm = [m for m in METHODS]
    # ranks among all methods with tuned versions where available
    rk = {}
    for met in ["mcc", "aucpr"]:
        T, Dd = Mt[met]
        comb = Dd[allm].copy()
        for m in tuned_methods:
            comb[m] = T[m]
        rk[met] = comb.rank(axis=1, ascending=False).mean()
    for m in allm:
        cells = []
        for met in ["mcc", "aucpr"]:
            T, Dd = Mt[met]
            dv = Dd[m].mean()
            if m in tuned_methods:
                tv = T[m].mean(); cells.append(f"{dv:.3f} & {tv:.3f} & {tv - dv:+.3f}")
            else:
                cells.append(f"{dv:.3f} & -- & --")
            cells.append(f"{rk[met][m]:.2f}")
        lines.append(f"{'\\textbf{SGBO}' if m == 'SGBO' else name(m)} & " + " & ".join(cells) + " \\\\")
    open(f"{OUT}/tab_tuning.tex", "w").write("\n".join(lines).replace("+", "$+$").replace(" -0", " $-$0"))
    ch = tu[tu.method == "SGBO"].chosen.value_counts().to_dict()
    facts["tuning"] = dict(n_tasks=len(names), sgbo_choices=ch, ranks={met: rk[met].round(2).to_dict() for met in rk})

# ---------------------------------------------------------------- supplement: per-task tables
order = [t["name"] for t in reg]
for met in ["mcc", "aucpr", "f1", "gmean"]:
    g = df.groupby(["dataset", "method"])[met]
    mu = g.mean().unstack().loc[order, METHODS]; sd = g.std().unstack().loc[order, METHODS]
    lines = []
    for i, tname in enumerate(order, 1):
        best = mu.loc[tname].max()
        cells = []
        for m in METHODS:
            v = f"{mu.loc[tname, m]:.3f}"
            if abs(mu.loc[tname, m] - best) < 1e-12: v = f"\\textbf{{{v}}}"
            cells.append(f"{v}\\,{{\\tiny$\\pm${sd.loc[tname, m]:.2f}}}")
        lines.append(f"T{i} & " + " & ".join(cells) + " \\\\")
    open(f"{OUT}/supp_{met}.tex", "w").write("\n".join(lines))
# supplement: per-classifier ranks
lines = []
for met in ["aucpr", "mcc", "f1", "gmean"]:
    for c in CLFS:
        r = st["all_tasks"][f"{met}_{c}"]["ranks"]; bestr = min(r.values())
        cells = [(f"\\textbf{{{r[m]:.2f}}}" if abs(r[m] - bestr) < 1e-12 else f"{r[m]:.2f}") for m in METHODS]
        lines.append(f"{LAB[met]} & {c} & " + " & ".join(cells) + " \\\\")
    lines.append("\\midrule")
open(f"{OUT}/supp_classifier_ranks.tex", "w").write("\n".join(lines[:-1]))
json.dump(facts, open(f"{RES}/facts_v2.json", "w"), indent=1, default=float)
print(json.dumps({k: v for k, v in facts.items() if k != "exceptions"}, indent=1, default=float)[:3000])
print(facts["exceptions"])
