#!/bin/bash
cd /home/claude/sgbo_paper/code
python3 run_extra.py runtime > ../results/runtime.log 2>&1
python3 run_synthetic.py > ../results/synthetic.log 2>&1
python3 run_extra.py ablation > ../results/ablation.log 2>&1
python3 run_extra.py sensitivity > ../results/sensitivity.log 2>&1
python3 run_tuning.py > ../results/tuning.log 2>&1
echo ALLDONE > ../results/alldone.flag
