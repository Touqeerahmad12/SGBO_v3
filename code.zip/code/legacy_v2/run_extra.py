"""
Additional experiments: ablation, parameter sensitivity, run time, and
diagnostic quantities for the figures (boundary score field, trajectories,
acceptance counts).
"""
import os, sys, time, json
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.datasets import make_classification
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from run_benchmark import run, classifiers, scores
from samplers import SGBO, make_sampler
from datasets import all_tasks, task_registry

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")


def ablation(reps=2):
    variants = lambda: {
        "SGBO": SGBO(),
        "w/o adaptive k": SGBO(adaptive_k=False),
        "w/o soft score": SGBO(soft=False),
        "w/o noise (tau=0)": SGBO(tau=0.0),
        "BDO movement": SGBO(movement="bdo"),
        "w/o movement": SGBO(movement="none"),
        "w/o shrinkage": SGBO(shrink=False),
        "w/o filter": SGBO(filter=False),
    }
    run(task_registry(), [], reps, os.path.join(RES, "ablation.csv"), extra_fn=variants, save=False)


def _sens_job(name, X, y, fold, tr, te, eta, tau):
    sc = StandardScaler().fit(X[tr]); Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te])
    rng = np.random.default_rng(10 * fold + 7)
    Xr, yr = SGBO(eta=eta, tau=tau).fit_resample(Xtr, y[tr], rng)[:2]
    rows = []
    for cn, clf in classifiers(0).items():
        if cn not in ("RF", "SVM"):
            continue
        clf.fit(Xr, yr); r = scores(clf, Xte, y[te])
        r.update(dataset=name, fold=fold, eta=eta, tau=tau, clf=cn); rows.append(r)
    return rows


def sensitivity():
    T = {t[0]: t for t in all_tasks()}
    names = ["bcancer-ir10", "diabetes-top10", "wine-c2-ir8", "syn-2cluster-ir20", "syn-overlap-ir10", "digits-8v3-ir10"]
    etas = [0.1, 0.25, 0.5, 1.0, 1.5]
    taus = [0.0, 0.05, 0.1, 0.25, 0.5, 1.0]
    jobs = []
    for nm in names:
        _, X, y, _ = T[nm]
        for fold, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=0).split(X, y)):
            for e in etas:
                for t in taus:
                    jobs.append((nm, X, y, fold, tr, te, e, t))
    res = Parallel(n_jobs=2, verbose=2)(delayed(_sens_job)(*j) for j in jobs)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "sensitivity.csv"), index=False)


def runtime():
    rows = []
    for n in [500, 1000, 2000, 4000, 8000]:
        X, y = make_classification(n_samples=n, n_features=10, n_informative=5, weights=[0.91], random_state=n)
        X = StandardScaler().fit_transform(X)
        for m in ["SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]:
            ts = []
            for r in range(3):
                t0 = time.perf_counter(); make_sampler(m).fit_resample(X, y, np.random.default_rng(r)); ts.append(time.perf_counter() - t0)
            rows.append(dict(n=n, method=m, time=float(np.median(ts))))
            print(n, m, rows[-1]["time"], flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(RES, "runtime.csv"), index=False)


if __name__ == "__main__":
    which = sys.argv[1:] or ["ablation", "sensitivity", "runtime"]
    for w in which:
        t0 = time.time(); globals()[w](); print(w, "done", round(time.time() - t0), "s", flush=True)
