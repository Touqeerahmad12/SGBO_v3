"""
Oversampling methods used in the SGBO study.

All baselines are re-implemented from their original descriptions so that the
study runs without third-party resampling packages:
  ROS            random oversampling
  SMOTE          Chawla et al. (2002)
  BorderlineSMOTE (borderline-1) Han et al. (2005)
  ADASYN         He et al. (2008)
  SVMSMOTE       Nguyen et al. (2011)
  SMOTEENN       Batista et al. (2004)
  BDO            Chen, Pedrycz and Yang (2023), implemented literally from the paper
  SGBO           proposed score-guided boundary oversampling

Every sampler exposes fit_resample(X, y, rng) with y in {0, 1} and 1 = minority.
"""
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.neighbors import NearestNeighbors
from sklearn.svm import SVC
from sklearn.covariance import ledoit_wolf


# ----------------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------------
def _split(X, y):
    return X[y == 1], X[y == 0]


def _n_needed(y):
    return int(np.sum(y == 0) - np.sum(y == 1))


def _interpolate(Xbase, Xnbr, base_idx, nbr_idx, rng, step=1.0):
    gaps = rng.uniform(0, 1, size=(len(base_idx), 1)) * step
    return Xbase[base_idx] + gaps * (Xnbr[nbr_idx] - Xbase[base_idx])


def binary_entropy(p):
    p = np.clip(p, 0.0, 1.0)
    out = np.zeros_like(p, dtype=float)
    m = (p > 0) & (p < 1)
    out[m] = -(p[m] * np.log2(p[m]) + (1 - p[m]) * np.log2(1 - p[m]))
    return out


# ----------------------------------------------------------------------------
# classical baselines
# ----------------------------------------------------------------------------
class ROS:
    name = "ROS"

    def fit_resample(self, X, y, rng):
        N = _n_needed(y)
        idx = np.flatnonzero(y == 1)
        pick = rng.choice(idx, size=N, replace=True)
        return np.vstack([X, X[pick]]), np.concatenate([y, np.ones(N, int)])


class SMOTE:
    name = "SMOTE"

    def __init__(self, k=5):
        self.k = k

    def fit_resample(self, X, y, rng, n_new=None):
        Xp = X[y == 1]
        N = _n_needed(y) if n_new is None else n_new
        if N <= 0 or len(Xp) < 2:
            return X, y
        k = min(self.k, len(Xp) - 1)
        nn = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        nbrs = nn.kneighbors(Xp, return_distance=False)[:, 1:]
        base = rng.integers(0, len(Xp), size=N)
        col = rng.integers(0, k, size=N)
        new = _interpolate(Xp, Xp, base, nbrs[base, col], rng)
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class BorderlineSMOTE:
    """Borderline-SMOTE1 (Han et al., 2005)."""
    name = "B-SMOTE"

    def __init__(self, k=5, m=10):
        self.k, self.m = k, m

    def fit_resample(self, X, y, rng):
        Xp = X[y == 1]
        N = _n_needed(y)
        m = min(self.m, len(X) - 1)
        nn_all = NearestNeighbors(n_neighbors=m + 1).fit(X)
        nb = nn_all.kneighbors(Xp, return_distance=False)[:, 1:]
        n_maj = np.sum(y[nb] == 0, axis=1)
        danger = (n_maj >= m / 2) & (n_maj < m)
        if danger.sum() == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng)
        k = min(self.k, len(Xp) - 1)
        nn_p = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        D = Xp[danger]
        nbrs = nn_p.kneighbors(D, return_distance=False)[:, 1:]
        base = rng.integers(0, len(D), size=N)
        col = rng.integers(0, k, size=N)
        new = D[base] + rng.uniform(0, 1, (N, 1)) * (Xp[nbrs[base, col]] - D[base])
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class ADASYN:
    """ADASYN (He et al., 2008)."""
    name = "ADASYN"

    def __init__(self, k=5):
        self.k = k

    def fit_resample(self, X, y, rng):
        Xp = X[y == 1]
        N = _n_needed(y)
        K = min(self.k, len(X) - 1)
        nb = NearestNeighbors(n_neighbors=K + 1).fit(X).kneighbors(Xp, return_distance=False)[:, 1:]
        r = np.sum(y[nb] == 0, axis=1) / K
        if r.sum() == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng)
        r = r / r.sum()
        g = np.floor(r * N).astype(int)
        rest = N - g.sum()
        if rest > 0:
            np.add.at(g, rng.choice(len(Xp), size=rest, p=r), 1)
        k = min(self.k, len(Xp) - 1)
        nbrs = NearestNeighbors(n_neighbors=k + 1).fit(Xp).kneighbors(Xp, return_distance=False)[:, 1:]
        base = np.repeat(np.arange(len(Xp)), g)
        col = rng.integers(0, k, size=len(base))
        new = _interpolate(Xp, Xp, base, nbrs[base, col], rng)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class SVMSMOTE:
    """SVM-SMOTE (Nguyen et al., 2011), following the common open implementation."""
    name = "SVM-SMOTE"

    def __init__(self, k=5, m=10, out_step=0.5):
        self.k, self.m, self.out_step = k, m, out_step

    def fit_resample(self, X, y, rng):
        N = _n_needed(y)
        Xp = X[y == 1]
        svm = SVC(gamma="scale", random_state=int(rng.integers(1e9))).fit(X, y)
        sv = svm.support_[y[svm.support_] == 1]
        S = X[sv]
        m = min(self.m, len(X) - 1)
        nn_all = NearestNeighbors(n_neighbors=m + 1).fit(X)
        if len(S) > 0:
            nb = nn_all.kneighbors(S, return_distance=False)[:, 1:]
            n_maj = np.sum(y[nb] == 0, axis=1)
            S, n_maj = S[n_maj < m], n_maj[n_maj < m]
        if len(S) == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng)
        danger = n_maj >= m / 2
        k = min(self.k, len(Xp) - 1)
        nn_p = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        n1 = int(rng.beta(10, 10) * (N + 1)) if danger.any() and (~danger).any() else (N if danger.any() else 0)
        parts = []
        for mask, cnt, step in ((danger, n1, 1.0), (~danger, N - n1, -self.out_step)):
            if cnt <= 0 or mask.sum() == 0:
                continue
            B = S[mask]
            nbrs = nn_p.kneighbors(B, return_distance=False)[:, 1:]
            base = rng.integers(0, len(B), size=cnt)
            col = rng.integers(0, k, size=cnt)
            parts.append(B[base] + step * rng.uniform(0, 1, (cnt, 1)) * (Xp[nbrs[base, col]] - B[base]))
        new = np.vstack(parts)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class SMOTEENN:
    """SMOTE followed by Edited Nearest Neighbours cleaning (Batista et al., 2004)."""
    name = "SMOTE-ENN"

    def __init__(self, k=5, k_enn=3):
        self.k, self.k_enn = k, k_enn

    def fit_resample(self, X, y, rng):
        Xs, ys = SMOTE(self.k).fit_resample(X, y, rng)
        nb = NearestNeighbors(n_neighbors=self.k_enn + 1).fit(Xs).kneighbors(Xs, return_distance=False)[:, 1:]
        keep = np.all(ys[nb] == ys[:, None], axis=1)
        if keep[ys == 1].sum() < 2 or keep[ys == 0].sum() < 2:
            return Xs, ys
        return Xs[keep], ys[keep]


# ----------------------------------------------------------------------------
# BDO (Chen, Pedrycz and Yang, 2023) -- literal implementation of the paper
# ----------------------------------------------------------------------------
class BDO:
    name = "BDO"

    def __init__(self, alpha=1e-3, t_max=1000, return_info=False):
        self.alpha, self.t_max, self.return_info = alpha, t_max, return_info

    def fit_resample(self, X, y, rng):
        Xp, Xn = _split(X, y)
        n_pos, n_neg = len(Xp), len(Xn)
        N = n_neg - n_pos
        # Eq. (1): boundary degree with k = n+ neighbours taken from all samples
        k = min(n_pos, len(X) - 1)
        nb = NearestNeighbors(n_neighbors=k + 1).fit(X).kneighbors(Xn, return_distance=False)[:, 1:]
        IE = binary_entropy(np.mean(y[nb] == 1, axis=1))
        # sigma rule, Eqs. (2)-(3)
        thr = IE.mean() + IE.std()
        sel = np.flatnonzero(IE > thr)
        if len(sel) == 0:
            out = SMOTE().fit_resample(X, y, rng)
            return (out + ({},)) if self.return_info else out
        XnB = Xn[sel]
        D = cdist(XnB, Xp)
        nearest = np.argmin(D, axis=1)
        dist = D[np.arange(len(sel)), nearest]
        Dpp = cdist(Xp[nearest], Xp)
        aided, local_sets = [], []
        for i in range(len(sel)):
            Pi = Xp[Dpp[i] <= dist[i] + 1e-12]          # Eq. (5)
            x0 = XnB[i]
            d_ij = np.linalg.norm(x0 - Pi, axis=1)        # Eq. (6)
            w = np.exp(-(d_ij - d_ij.min()))
            w = w / w.sum()
            grad = (w[:, None] * (Pi - x0)).sum(0)        # Eq. (7), uses x^nb_i as written
            xt = x0.copy()
            for _ in range(self.t_max):                   # Algorithm 1
                if np.all(np.linalg.norm(xt - Pi, axis=1) < np.linalg.norm(xt - x0)):
                    break
                xt = xt + self.alpha * grad
            aided.append(xt)
            local_sets.append(np.vstack([xt[None, :], Pi]))
        # Section 3.4: one Gaussian per local set, (n- - n+) draws each, keep N at random
        M = len(local_sets)
        pick = rng.choice(N * M, size=N, replace=False) // N if N * M > N else np.repeat(np.arange(M), N)
        counts = np.bincount(pick, minlength=M)
        new = []
        for i, c in enumerate(counts):
            if c == 0:
                continue
            L = local_sets[i]
            mu = L.mean(0)
            C = np.cov(L, rowvar=False) if len(L) > 1 else np.zeros((X.shape[1], X.shape[1]))
            C = np.atleast_2d(C)
            new.append(rng.multivariate_normal(mu, C, size=c, check_valid="ignore", method="svd"))
        new = np.vstack(new)
        out = (np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)]))
        if self.return_info:
            return out + ({"seeds": XnB, "aided": np.array(aided), "new": new},)
        return out


# ----------------------------------------------------------------------------
# SGBO (proposed)
# ----------------------------------------------------------------------------
class SGBO:
    """
    Score-Guided Boundary Oversampling.

    Stage 1  adaptive, distance-weighted boundary score b(x) = H2(eta_hat(x)).
    Stage 2  tempered Langevin movement of negative boundary seeds along the
             score of a Gaussian KDE of the minority class.
    Stage 3  local Gaussian generation with Ledoit-Wolf shrinkage and a
             posterior-based acceptance filter.

    Ablation switches:
      adaptive_k  False -> k = n+ (as in BDO)
      soft        False -> hard sigma-rule seed selection and uniform allocation
      tau         0     -> deterministic mean-shift ascent (no noise)
      movement    "langevin" | "bdo" | "none"
      shrink      False -> plain sample covariance
      filter      False -> no acceptance test
    """
    name = "SGBO"

    def __init__(self, eta=0.5, tau=0.1, T=30, k0=5, k_gen=5, adaptive_k=True,
                 soft=True, movement="langevin", shrink=True, filter=True,
                 return_info=False):
        self.eta, self.tau, self.T, self.k0, self.k_gen = eta, tau, T, k0, k_gen
        self.adaptive_k, self.soft, self.movement = adaptive_k, soft, movement
        self.shrink, self.filter, self.return_info = shrink, filter, return_info

    # ---- Stage 1 -----------------------------------------------------------
    def _k(self, n, n_pos):
        if not self.adaptive_k:
            return max(1, min(n_pos, n - 1))
        return int(max(1, min(n_pos, n - 1, max(self.k0, np.ceil(np.sqrt(n))))))

    def posterior(self, Q, exclude_self=False):
        k = self.k_
        kk = k + 1 if exclude_self else k
        d, idx = self.nn_.kneighbors(Q, n_neighbors=kk)
        if exclude_self:
            d, idx = d[:, 1:], idx[:, 1:]
        dk = np.maximum(d[:, -1:], 1e-12)
        w = np.exp(-(d / dk) ** 2)
        return (w * (self.y_[idx] == 1)).sum(1) / w.sum(1)

    # ---- Stage 2 -----------------------------------------------------------
    def _mean_shift(self, Z):
        D2 = cdist(Z, self.Xp_, "sqeuclidean") / (2 * self.h_ ** 2)
        D2 -= D2.min(1, keepdims=True)
        W = np.exp(-D2)
        W /= W.sum(1, keepdims=True)
        return W @ self.Xp_

    def _move(self, S, rng):
        Z = S.copy()
        if self.movement == "none":
            return Z, np.zeros(len(Z), int)
        if self.movement == "bdo":
            out = []
            for x0 in Z:
                ball_c = self.Xp_[np.argmin(np.linalg.norm(self.Xp_ - x0, axis=1))]
                r = np.linalg.norm(ball_c - x0)
                Pi = self.Xp_[np.linalg.norm(self.Xp_ - ball_c, axis=1) <= r + 1e-12]
                dij = np.linalg.norm(Pi - x0, axis=1)
                w = np.exp(-(dij - dij.min())); w /= w.sum()
                g = (w[:, None] * (Pi - x0)).sum(0)
                out.append(x0 + g)   # alpha * t_max = 1 in the original setting
            return np.array(out), np.full(len(Z), 1000)
        active = np.ones(len(Z), bool)
        steps = np.zeros(len(Z), int)
        sd = self.h_ * np.sqrt(2 * self.eta * self.tau)
        self.paths_ = [Z.copy()]
        for t in range(self.T):
            if not active.any():
                break
            idx = np.flatnonzero(active)
            Za = Z[idx]
            Za = Za + self.eta * (self._mean_shift(Za) - Za) + sd * rng.standard_normal(Za.shape)
            Z[idx] = Za
            steps[idx] += 1
            done = self.posterior(Za) >= self.theta_
            active[idx[done]] = False
            self.paths_.append(Z.copy())
        return Z, steps

    # ---- Stage 3 -----------------------------------------------------------
    RHO_MIN = 0.01   # lower bound on the shrinkage intensity (safeguard, Prop. 3)

    def _cov(self, L):
        """Local covariance with the safeguards described in Section 3.3:
        a single point or a zero-trace set -> h^2 I; Ledoit-Wolf intensity clipped to [RHO_MIN, 1]."""
        d = L.shape[1]
        if len(L) < 2:
            self.diag_["cov_single"] += 1
            return (self.h_ ** 2) * np.eye(d)
        if self.shrink:
            S = np.atleast_2d(np.cov(L, rowvar=False, bias=True))
            nu = np.trace(S) / d
            if nu <= 1e-12:
                self.diag_["cov_zero_trace"] += 1
                return (self.h_ ** 2) * np.eye(d)
            C, rho = ledoit_wolf(L)
            if rho < self.RHO_MIN:
                self.diag_["rho_clipped"] += 1
                C = (1 - self.RHO_MIN) * S + self.RHO_MIN * nu * np.eye(d)
            return C
        return np.atleast_2d(np.cov(L, rowvar=False))

    def fit_resample(self, X, y, rng):
        Xp, Xn = _split(X, y)
        n, n_pos = len(X), len(Xp)
        N = len(Xn) - n_pos
        self.diag_ = dict(too_few_minority=0, no_candidates=0, chains=0, chains_unfinished=0,
                          cov_single=0, cov_zero_trace=0, rho_clipped=0, n_cand=0, n_acc=0, n_fill=0)
        if N <= 0 or n_pos < 2:            # nothing to do / too few minority points to estimate anything
            self.diag_["too_few_minority"] = int(n_pos < 2)
            return X, y
        self.Xp_, self.y_ = Xp, y
        self.k_ = self._k(n, n_pos)
        self.nn_ = NearestNeighbors().fit(X)
        eta_all = self.posterior(X, exclude_self=True)
        b = binary_entropy(eta_all)
        # bandwidth of the minority KDE: median distance to the k_h-th minority neighbour
        kh = min(5, n_pos - 1)
        dpp = NearestNeighbors(n_neighbors=kh + 1).fit(Xp).kneighbors(Xp)[0][:, -1]
        self.h_ = max(np.median(dpp), 1e-6)
        # acceptance level: lower quartile of the minority posterior, capped at 1/2
        self.theta_ = min(0.5, float(np.quantile(eta_all[y == 1], 0.25)))
        neg_idx = np.flatnonzero(y == 0)
        bn = b[neg_idx]
        if self.soft:
            cand = neg_idx[bn > 0]
            wts = b[cand]
        else:
            thr = bn.mean() + bn.std()
            cand = neg_idx[bn > thr]
            wts = np.ones(len(cand))
        if len(cand) == 0:            # perfectly separated data: start from minority points
            self.diag_["no_candidates"] = 1
            cand = np.flatnonzero(y == 1)
            wts = np.ones(len(cand))
        wts = wts / wts.sum()
        M = int(min(len(cand), max(10, N // 4)))
        seeds_idx = rng.choice(cand, size=M, replace=False, p=wts) if M < len(cand) else cand
        seed_w = b[seeds_idx] if self.soft else np.ones(len(seeds_idx))
        if seed_w.sum() <= 0:
            seed_w = np.ones(len(seeds_idx))
        S = X[seeds_idx]
        A, steps = self._move(S, rng)
        self.diag_["chains"] = len(A)
        if self.movement == "langevin":
            self.diag_["chains_unfinished"] = int(np.sum(self.posterior(A) < self.theta_))
        # local generator around every anchor: anchor + its k_gen nearest minority points
        kg = min(self.k_gen, n_pos)
        nbr = NearestNeighbors(n_neighbors=kg).fit(Xp).kneighbors(A, return_distance=False)
        comps = []
        for i in range(len(A)):
            L = np.vstack([A[i][None, :], Xp[nbr[i]]])
            comps.append((L.mean(0), self._cov(L)))
        p_alloc = seed_w / seed_w.sum()

        def draw(cnt):
            lab = rng.choice(len(comps), size=cnt, p=p_alloc)
            out = np.empty((cnt, X.shape[1]))
            for c in np.unique(lab):
                m = lab == c
                mu, C = comps[c]
                out[m] = rng.multivariate_normal(mu, C, size=m.sum(), check_valid="ignore", method="svd")
            return out

        n_cand = n_acc = 0
        if not self.filter:
            new = draw(N)
            n_cand = n_acc = N
        else:
            kept, pool, pool_s = [], [], []
            need = N
            for _ in range(5):
                Z = draw(max(2 * need, 10))
                s = self.posterior(Z)
                ok = s >= self.theta_
                n_cand += len(Z); n_acc += int(ok.sum())
                kept.append(Z[ok][:need]); need -= len(kept[-1])
                pool.append(Z[~ok]); pool_s.append(s[~ok])
                if need <= 0:
                    break
            if need > 0:               # fill with the most minority-like rejected candidates
                P = np.vstack(pool); Ps = np.concatenate(pool_s)
                kept.append(P[np.argsort(-Ps)[:need]])
                self.diag_["n_fill"] = int(need)
            new = np.vstack(kept)[:N]
        self.diag_["n_cand"], self.diag_["n_acc"] = int(n_cand), int(n_acc)
        out = (np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)]))
        if self.return_info:
            info = dict(seeds=S, anchors=A, steps=steps, new=new, b=b, k=self.k_,
                        h=self.h_, theta=self.theta_, n_cand=n_cand, n_acc=n_acc,
                        n_seed_cand=len(cand), n_seeds=len(S), N=N)
            return out + (info,)
        return out



# ----------------------------------------------------------------------------
# additional baselines (re-implemented from the original papers)
# ----------------------------------------------------------------------------
class KMeansSMOTE:
    """k-means SMOTE (Douzas, Bacao and Last, 2018).
    1) k-means on the whole training set; 2) keep clusters whose minority share is at
    least the global minority share and that contain >= 2 minority points; 3) allocate the
    new points by cluster sparsity (mean minority distance^d / minority count, Eq. of the
    paper, computed in log space); 4) SMOTE inside each kept cluster.
    Falls back to SMOTE on the whole set when no cluster qualifies."""
    name = "KM-SMOTE"

    def __init__(self, n_clusters=8, k=5):
        self.n_clusters, self.k = n_clusters, k

    def fit_resample(self, X, y, rng):
        from sklearn.cluster import KMeans
        N = _n_needed(y)
        n, n_pos = len(X), int(y.sum())
        kc = int(max(2, min(self.n_clusters, n // 5)))
        lab = KMeans(n_clusters=kc, n_init=3, random_state=int(rng.integers(1e9))).fit_predict(X)
        share = n_pos / n
        keep, logsp = [], []
        for c in range(kc):
            m = lab == c
            mp = m & (y == 1)
            if mp.sum() < 2 or mp.sum() / max(m.sum(), 1) < share:
                continue
            P = X[mp]
            D = cdist(P, P)
            md = D[np.triu_indices(len(P), 1)].mean()
            md = max(md, 1e-12)
            keep.append(np.flatnonzero(mp))
            logsp.append(X.shape[1] * np.log(md) - np.log(len(P)))
        if not keep:
            return SMOTE(self.k).fit_resample(X, y, rng)
        logsp = np.array(logsp)
        w = np.exp(logsp - logsp.max()); w /= w.sum()
        counts = rng.multinomial(N, w)
        parts = []
        for idx, cnt in zip(keep, counts):
            if cnt == 0:
                continue
            P = X[idx]
            k = min(self.k, len(P) - 1)
            nbrs = NearestNeighbors(n_neighbors=k + 1).fit(P).kneighbors(P, return_distance=False)[:, 1:]
            base = rng.integers(0, len(P), size=cnt)
            col = rng.integers(0, k, size=cnt)
            parts.append(_interpolate(P, P, base, nbrs[base, col], rng))
        new = np.vstack(parts)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class MWMOTE:
    """MWMOTE (Barua, Islam, Yao and Murase, 2014), steps 1-6 of the original algorithm
    with the published defaults k1=5, k2=3, k3=|S_min|/2, C_p=3, C_f(th)=5, CMAX=2."""
    name = "MWMOTE"

    def __init__(self, k1=5, k2=3, cp=3.0, cf_th=5.0, cmax=2.0):
        self.k1, self.k2, self.cp, self.cf_th, self.cmax = k1, k2, cp, cf_th, cmax

    def fit_resample(self, X, y, rng):
        from scipy.cluster.hierarchy import linkage, fcluster
        N = _n_needed(y)
        Xp, Xn = X[y == 1], X[y == 0]
        if len(Xp) < 2 or N <= 0:
            return X, y
        d = X.shape[1]
        k1 = min(self.k1, len(X) - 1)
        nb = NearestNeighbors(n_neighbors=k1 + 1).fit(X).kneighbors(Xp, return_distance=False)[:, 1:]
        noise = np.all(y[nb] == 0, axis=1)
        Pf = Xp[~noise] if (~noise).sum() >= 2 else Xp                     # step 1
        k2 = min(self.k2, len(Xn))
        bm = NearestNeighbors(n_neighbors=k2).fit(Xn).kneighbors(Pf, return_distance=False)
        Sbmaj = Xn[np.unique(bm.ravel())]                                    # step 2
        k3 = max(1, min(len(Xp), int(np.ceil(len(Xp) / 2))))
        im = NearestNeighbors(n_neighbors=k3).fit(Xp).kneighbors(Sbmaj, return_distance=False)
        imin_idx = np.unique(im.ravel())                                     # step 3
        pos = {j: t for t, j in enumerate(imin_idx)}
        Cf = np.zeros((len(Sbmaj), len(imin_idx)))
        for r in range(len(Sbmaj)):
            for j in im[r]:
                dn = np.linalg.norm(Sbmaj[r] - Xp[j]) / d
                z = 1.0 / max(dn, 1e-12)
                Cf[r, pos[j]] = min(z, self.cf_th) / self.cf_th * self.cmax
        Df = Cf / np.maximum(Cf.sum(1, keepdims=True), 1e-12)
        Sw = (Cf * Df).sum(0)                                                # step 4
        if Sw.sum() <= 0:
            return SMOTE().fit_resample(X, y, rng)
        Sp = Sw / Sw.sum()
        # step 5: average-linkage clustering of the minority class, threshold d_avg * C_p
        Dff = cdist(Pf, Pf); np.fill_diagonal(Dff, np.inf)
        davg = float(np.mean(Dff.min(1))) if len(Pf) > 1 else 1.0
        if len(Xp) > 1:
            clus = fcluster(linkage(Xp, method="average"), t=davg * self.cp, criterion="distance")
        else:
            clus = np.ones(1, int)
        # step 6
        pick = imin_idx[rng.choice(len(imin_idx), size=N, p=Sp)]
        new = np.empty((N, d))
        for t, i in enumerate(pick):
            members = np.flatnonzero(clus == clus[i])
            j = rng.choice(members)
            new[t] = Xp[i] + rng.uniform() * (Xp[j] - Xp[i])
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class CCR:
    """Combined Cleaning and Resampling (Koziarski and Wozniak, 2017).
    For every minority point a sphere grows until its energy budget is spent (expanding
    by dr with p majority points inside costs dr*(p+1)); majority points inside the
    sphere are pushed to its surface; new points are drawn uniformly inside the spheres,
    in numbers proportional to 1/r."""
    name = "CCR"

    def __init__(self, energy=0.25):
        self.energy = energy

    def fit_resample(self, X, y, rng):
        N = _n_needed(y)
        Xp, Xn = X[y == 1], X[y == 0].copy()
        if len(Xp) < 1 or N <= 0:
            return X, y
        d = X.shape[1]
        D = cdist(Xp, Xn)
        radii = np.zeros(len(Xp))
        shift = np.zeros_like(Xn)
        for i in range(len(Xp)):
            order = np.argsort(D[i])
            e, r, p = self.energy, 0.0, 0
            for j in order:
                cost = (D[i, j] - r) * (p + 1)
                if e - cost > 0:
                    e -= cost; r = D[i, j]; p += 1
                else:
                    r += e / (p + 1); e = 0.0
                    break
            if e > 0:
                r += e / (p + 1)
            radii[i] = r
            inside = order[:p]
            for j in inside:
                dij = max(D[i, j], 1e-12)
                shift[j] += (r - dij) / dij * (Xn[j] - Xp[i])
        Xn = Xn + shift                                                       # cleaning
        w = 1.0 / np.maximum(radii, 1e-12); w /= w.sum()
        counts = np.floor(w * N).astype(int)
        rest = N - counts.sum()
        if rest > 0:
            np.add.at(counts, rng.choice(len(Xp), size=rest, p=w), 1)
        parts = []
        for i, c in enumerate(counts):
            if c == 0:
                continue
            v = rng.standard_normal((c, d)); v /= np.linalg.norm(v, axis=1, keepdims=True)
            rad = radii[i] * rng.uniform(0, 1, (c, 1)) ** (1.0 / d)
            parts.append(Xp[i] + v * rad)
        new = np.vstack(parts)
        Xo = np.vstack([Xp, Xn, new])
        yo = np.concatenate([np.ones(len(Xp), int), np.zeros(len(Xn), int), np.ones(len(new), int)])
        return Xo, yo


def make_sampler(name, **kw):
    table = {"ROS": ROS, "SMOTE": SMOTE, "B-SMOTE": BorderlineSMOTE, "ADASYN": ADASYN,
             "SVM-SMOTE": SVMSMOTE, "SMOTE-ENN": SMOTEENN, "KM-SMOTE": KMeansSMOTE,
             "MWMOTE": MWMOTE, "CCR": CCR, "BDO": BDO, "SGBO": SGBO}
    return table[name](**kw)
