"""
Write manuscript_v3/facts.tex: every number quoted in the text is a macro \\F{key} defined here from the result
files, so that the manuscript cannot drift away from the results (the build fails loudly on a missing key).

    python make_facts.py          # reads results/*.json (the analysis outputs) and results/*.csv where needed
"""
import _threads  # noqa: F401
import os, sys, json, re
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.protocol import RES
import style

OUT = os.path.join(os.path.dirname(style.FIG), "facts.tex")
FACTS = {}


def key(*parts):
    return re.sub(r"[^A-Za-z0-9]+", "", "_".join(str(p) for p in parts).replace("_", "U").replace("-", "")).replace("U", "_")


def clean(s):
    return re.sub(r"[^A-Za-z0-9_]", "", str(s).replace("-", "").replace(" ", "").replace("+", "p"))


def K(*parts):
    return "_".join(clean(p) for p in parts)


def f(x, nd=3):
    return f"{x:.{nd}f}"


def sg(x, nd=3):
    """signed number with a typographic minus"""
    return ("$+$" if x >= 0 else "$-$") + f"{abs(x):.{nd}f}"


def pv(p):
    return "$<0.001$" if p < 0.001 else f"{p:.3f}"


def put(k, v):
    FACTS[k] = v


def load(name):
    p = os.path.join(RES, name)
    return json.load(open(p)) if os.path.exists(p) else None


# ---------------------------------------------------------------------------------------------------------------- main
S = load("stats_main.json")
E = load("extra_main.json")
R = load("reproduction.json")
if S:
    A = S["all_tasks"]
    for met in ["aucpr", "mcc", "f1", "gmean", "auc"]:
        fr = A[met]
        put(K("fr", met, "N"), fr["N"]); put(K("fr", met, "chi2"), f(fr["chi2"], 1)); put(K("fr", met, "FF"), f(fr["FF"], 2))
        put(K("fr", met, "p"), pv(fr["p_FF"]) if fr["p_FF"] >= 1e-3 else "$<10^{-3}$"); put(K("fr", met, "cd"), f(fr["cd"], 2))
        for m, r in fr["ranks"].items():
            put(K("rank", met, m), f(r, 2)); put(K("mean", met, m), f(fr["mean"][m], 3)); put(K("sd", met, m), f(fr["std"][m], 3))
        for m, ph in fr["posthoc"].items():
            put(K("d", met, m), sg(ph["mean"])); put(K("lo", met, m), sg(ph["ci_lo"])); put(K("hi", met, m), sg(ph["ci_hi"]))
            put(K("pH", met, m), pv(ph["p_holm"])); put(K("w", met, m), ph["wins"]); put(K("l", met, m), ph["losses"]); put(K("rrb", met, m), sg(ph["r_rb"], 2))
        for c in ["RF", "SVM", "kNN", "LR"]:
            fc = A[f"{met}_{c}"]
            for m, r in fc["ranks"].items():
                put(K("rankclf", met, c, m), f(r, 2))
            order = sorted(fc["ranks"], key=fc["ranks"].get); put(K("posclf", met, c, "SGBO"), order.index("SGBO") + 1); put(K("bestclf", met, c), order[0])
            for m, ph in fc["posthoc"].items():
                put(K("dclf", met, c, m), sg(ph["mean"])); put(K("pHclf", met, c, m), pv(ph["p_holm"]))
        for part, tag in (("primary_only", "prim"), ("previous_26_sources", "old26")):
            fp = S[part][met]
            put(K(tag, met, "N"), fp["N"])
            for m in ["SGBO", "BDO", "SVM-SMOTE", "SMOTE", "None"]:
                put(K(tag, "rank", met, m), f(fp["ranks"][m], 2))
            for m in ["BDO", "SVM-SMOTE"]:
                ph = fp["posthoc"][m]; put(K(tag, "d", met, m), sg(ph["mean"])); put(K(tag, "pH", met, m), pv(ph["p_holm"]))
    for tag in ("real", "synthetic"):
        for met in ["aucpr", "mcc", "f1", "gmean"]:
            x = E[f"{tag}_{met}"]; put(K(tag, "N"), x["N"])
            for m in ["SGBO", "BDO", "SVM-SMOTE", "SMOTE", "None"]:
                put(K(tag, "rank", met, m), f(x["ranks"][m], 2))
    for k in ["n_sources", "n_real_src", "n_syn_src", "n_tasks", "n_rows", "sgbo_calls"]:
        put(K("E", k), f"{E[k]:,}".replace(",", "{,}") if isinstance(E[k], int) else E[k])
    put("avg_rank4_SGBO", f(E["sgbo_avg_rank4"], 2))
    put("mcc_spread", f(E["mcc_spread_excl_none"], 3))
    ex_ = [v for k, v in A["mcc"]["mean"].items() if k not in ("None", "BDO")]
    put("mcc_spread_exbdo", f(max(ex_) - min(ex_), 3))
    for met in ["mcc", "aucpr", "f1", "gmean"]:
        for m in ["SGBO", "None", "SVM-SMOTE", "SMOTE-ENN", "BDO"]:
            put(K("best", met, m), E[f"best_{met}"].get(m, 0))
        for m in ["SGBO", "SVM-SMOTE", "None"]:
            put(K("top3", met, m), E[f"top3_{met}"][m])
        for key_ in ["bdo", "smote", "svmsm", "none"]:
            put(K("ge", met, key_), E[f"sgbo_ge_{key_}_{met}"])
    for q in ["tpr", "tnr", "prec", "fpr"]:
        for m, v in E[f"mean_{q}"].items():
            put(K("m", q, m), f(v, 3))
    for m, v in E["t_resample"].items():
        put(K("tres", m), f(v, 3))
    put("rej_share", f(100 * E["rej_share_mean"], 1)); put("unfin_share", f(100 * E["unfinished_share_mean"], 1))
    for c in [c for c in E if c.startswith("diag_")]:
        put(K(c, "sum"), f"{int(E[c]['sum']):,}".replace(",", "{,}")); put(K(c, "calls"), E[c]["calls_with"])
    put("acc_rate", f(100 * E["diag_n_acc"]["sum"] / E["diag_n_cand"]["sum"], 1))
if R:
    for m, v in R["per_method"].items():
        put(K("repro", m, "ident"), f(100 * v["identical"], 1)); put(K("repro", m, "maxdiff"), f(v["max_abs_diff"], 3))
    put("repro_rows", f"{R['rows_compared']:,}".replace(",", "{,}"))
    put("repro_sgbo_tasks", len(R["differing_tasks"]["SGBO"]))

# ---------------------------------------------------------------------------------------------------------------- known
Kn = load("known_summary.json")
if Kn:
    C = Kn["consistency"]
    names = {"BDO (k=n+, uniform)": "bdo", "SGBO (k=sqrt(n), weighted)": "sgbo", "k=5, uniform": "k5", "k=n+, weighted": "knw", "k=sqrt(n), uniform": "ksu"}
    for q in (0, 8):
        for r, nm in names.items():
            sl = C[f"q{q}_slope_mae_b"][r]
            put(K("cons", q, nm, "slope"), sg(sl["slope"], 2)); put(K("cons", q, nm, "lo"), sg(sl["lo"], 2)); put(K("cons", q, nm, "hi"), sg(sl["hi"], 2))
            mae = C[f"q{q}_mae_b"][r]
            put(K("cons", q, nm, "mae_first"), f(mae["mean"][0], 3)); put(K("cons", q, nm, "mae_last"), f(mae["mean"][-1], 3))
    for q in (0, 8):
        for r, x in C[f"q{q}_paired_largest_n"].items():
            nm = names.get(r, clean(r))
            put(K("cons", q, nm, "pdiff"), sg(x["diff"], 3)); put(K("cons", q, nm, "pp"), pv(x["p"]))
    put("cons_nmin", C["q0_mae_b"]["SGBO (k=sqrt(n), weighted)"]["n"][0]); put("cons_nmax", f"{C['q0_mae_b']['SGBO (k=sqrt(n), weighted)']['n'][-1]:,}".replace(",", "{,}"))
    if "ablation" in Kn:
        for met in ("mcc", "aucpr"):
            for cond, r in Kn["ablation"][met].items():
                cn = clean(cond.split("(")[0])
                put(K("abl", met, cn, "full"), f(list(r.values())[0]["full"], 3))
                for v, x in r.items():
                    put(K("abl", met, cn, v), sg(x["mean"] * 100, 1)); put(K("ablp", met, cn, v), pv(x["p_holm"]))
    if "shrink_median" in Kn:
        for d, rr in Kn["shrink_median"].items():
            for v, x in rr.items():
                put(K("shr", d, v, "cond"), (f"{x['cond_med']:.1f}" if np.isfinite(x["cond_med"]) else "singular"))
                put(K("shr", d, v, "rank"), f(100 * x["rankdef_frac"], 0)); put(K("shr", d, v, "rho"), f(x["rho_mean"], 2) if x["rho_mean"] == x["rho_mean"] else "--")
                put(K("shr", d, v, "prec"), f(x["prec_true"], 2)); put(K("shr", d, v, "rec"), f(x["rec_true"], 2)); put(K("shr", d, v, "off"), f(x["offsupp"], 2))
        for d, rr in Kn["shrink_perf"]["mcc"].items():
            for v, x in rr.items():
                put(K("shrmcc", d, v), f(x["mean"], 3))
                if "diff_vs_default" in x:
                    put(K("shrdiff", d, v), sg(100 * x["diff_vs_default"], 1)); put(K("shrp", d, v), pv(x["p_vs_default"]))
    if "langevin" in Kn:
        L = Kn["langevin"]
        for c, v in L["paired_struct"].items():
            for t, m in v["mean"].items():
                put(K("lang", c, t), f(m, 3))
            for kk, x in v.items():
                if kk.startswith("diff_"):
                    put(K("langd", c, kk[5:]), sg(x["mean"], 3)); put(K("langp", c, kk[5:]), pv(x["p"])); put(K("langw", c, kk[5:]), f"{x['wins']}/{x['n']}")
        for met in ["aucpr", "mcc", "f1", "gmean"]:
            for kk, x in L[met].items():
                if kk.startswith("diff_"):
                    put(K("langm", met, kk[5:]), sg(x["mean"], 3)); put(K("langmp", met, kk[5:]), pv(x["p"])); put(K("langmw", met, kk[5:]), f"{x['wins']}/{x['wins'] + x['losses']}")
            for t, v in L[met]["run_sd"].items():
                put(K("langsd", met, t), f(v, 3))
        put("lang_unfin0", f(100 * L["by_tau"]["unfinished"]["0.0"], 1)); put("lang_unfin01", f(100 * L["by_tau"]["unfinished"]["0.1"], 1))
    if "quality_overall" in Kn:
        for tag, r in Kn["quality"].items():
            for m, x in r.items():
                for c, v in x.items():
                    if v == v:
                        put(K("kq", tag, m, c), f(v, 2))
        for m, x in Kn["quality_overall"].items():
            for c, v in x.items():
                if v == v:
                    put(K("kqo", m, c), f(v, 2))
        for c, d in Kn["quality_sgbo_diag"].items():
            for tag, v in d.items():
                put(K("kqd", c, tag), f(100 * v, 1))

# ---------------------------------------------------------------------------------------------------------------- other analyses
for fname, tag in (("ablation_summary.json", "abx"), ("sensitivity_summary.json", "sens"), ("quality_summary.json", "qual"), ("scale_summary.json", "scale"),
                   ("apps_summary.json", "app"), ("synth_summary.json", "syn"), ("tuning_summary.json", "tun"), ("illus_summary.json", "ill")):
    D = load(fname)
    if D is None:
        continue

    def walk(o, path):
        if isinstance(o, dict):
            for k, v in o.items():
                walk(v, path + [k])
        elif isinstance(o, (int, float, np.floating)) and not isinstance(o, bool):
            if o == o and np.isfinite(o):
                if isinstance(o, (int, np.integer)):
                    put(K(tag, *path), str(o))
                elif tag == "app":
                    put(K(tag, *path), f"{o:.3f}")
                else:
                    put(K(tag, *path), f"{o:.4g}" if abs(o) < 1e5 else f"{o:.3g}")
        elif isinstance(o, str) and len(o) < 40:
            put(K(tag, *path), o)
    if tag in ("app", "abx", "sens", "qual", "scale", "syn", "tun", "ill"):
        walk(D, [])

import glob
for p in sorted(glob.glob(os.path.join(RES, "facts_part_*.json"))):
    FACTS.update(json.load(open(p)))

# ---------------------------------------------------------------------------------------------------------------- write
lines = ["% generated by make_facts.py -- do not edit",
         r"\newcommand{\F}[1]{\ifcsname fact@#1\endcsname\csname fact@#1\endcsname\else\textbf{??}\PackageWarning{facts}{missing fact #1}\fi}"]
for k_, v in sorted(FACTS.items()):
    lines.append(r"\expandafter\def\csname fact@" + k_ + r"\endcsname{" + str(v) + "}")
os.makedirs(os.path.dirname(OUT), exist_ok=True)
open(OUT, "w").write("\n".join(lines) + "\n")
json.dump(FACTS, open(os.path.join(RES, "facts_v3.json"), "w"), indent=0, default=str)
print(len(FACTS), "facts ->", OUT)
