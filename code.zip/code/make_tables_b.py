"""Tables and short-key facts of the ablation, sensitivity, quality, scalability and robustness studies
(run after the corresponding analysis_*.py scripts; writes manuscript_v3/tables/*.tex and results/facts_part_tables_b.json)."""
import os, sys, json
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
RES, OUT = "../results", "../manuscript_v3/tables"
FACT = {}


def sg(x, nd=3):
    return ("$+$" if x >= 0 else "$-$") + f"{abs(x):.{nd}f}"


def pv(p):
    return "$<0.001$" if p < 0.001 else f"{p:.3f}"


# ------------------------------------------------------------------------------------------------ whole-benchmark ablation
p = f"{RES}/ablation_summary.json"
if os.path.exists(p):
    A = json.load(open(p))
    LABEL = {"k = n+ (no adaptive k)": "fixed $k=n^+$", "uniform weights": "uniform weights", "k = n+, uniform (BDO score)": "BDO score (both)",
             "uniform seeds": "uniform seeds", "uniform allocation": "uniform allocation", "sigma-rule seeds, uniform alloc.": "$\\sigma$-rule seeds",
             "no noise (tau=0)": "no Langevin noise", "BDO movement": "BDO movement", "no movement": "no movement", "no shrinkage": "no shrinkage",
             "no acceptance test": "no acceptance test"}
    KEY = {"k = n+ (no adaptive k)": "fixedk", "uniform weights": "unifw", "k = n+, uniform (BDO score)": "bdoscore", "uniform seeds": "unifseeds",
           "uniform allocation": "unifalloc", "sigma-rule seeds, uniform alloc.": "sigmaseeds", "no noise (tau=0)": "nonoise", "BDO movement": "bdomove",
           "no movement": "nomove", "no shrinkage": "noshrink", "no acceptance test": "noaccept"}
    REG = {"all": "all", "d >= 20": "hd", "d < 20": "ld", "IR >= 10": "hir", "IR < 10": "lir", "n+ < 50": "smallpos", "n >= 3000": "largen",
           "real data": "real", "synthetic data": "syn"}
    lines = []
    for v, lab in LABEL.items():
        cells = []
        for rg, met in (("all", "mcc"), ("all", "aucpr"), ("d >= 20", "mcc"), ("IR >= 10", "mcc"), ("n+ < 50", "mcc"), ("real data", "mcc")):
            x = A["regimes"][rg][met]["v"][v]
            b = -x["mean"]                       # benefit of the component = SGBO - variant
            sig = x["p_holm"] < 0.05 and rg == "all"
            cell = sg(b, 3)
            if sig:
                cell = "\\textbf{" + cell + "}"
            cells.append(cell)
        x = A["regimes"]["all"]["mcc"]["v"][v]
        cells.insert(1, pv(x["p_holm"]))
        lines.append(f"{lab} & " + " & ".join(cells) + " \\\\")
        for rg, rk in REG.items():
            for met in ("mcc", "aucpr", "f1", "gmean"):
                y = A["regimes"][rg][met]["v"][v]
                FACT[f"ab_{met}_{rk}_{KEY[v]}"] = sg(-y["mean"], 3)
                FACT[f"abp_{met}_{rk}_{KEY[v]}"] = pv(y["p_holm"])
                FACT[f"abw_{met}_{rk}_{KEY[v]}"] = f"{y['losses']}/{y['wins'] + y['losses']}"     # sources in which the component helps
    open(f"{OUT}/tab_ablation_bench.tex", "w").write("\n".join(lines))
    for rg, rk in REG.items():
        FACT[f"ab_n_{rk}"] = str(A["regimes"][rg]["mcc"]["N"])
    FACT["ab_full_mcc"] = f"{A['regimes']['all']['mcc']['full']:.3f}"

# ------------------------------------------------------------------------------------------------ parameter sensitivity
p = f"{RES}/sensitivity_summary.json"
if os.path.exists(p):
    S = json.load(open(p))
    P = S["params"]
    G = {"a": "IR<10, d<20", "b": "IR<10, d>=20", "c": "IR>=10, d<20", "d": "IR>=10, d>=20"}

    def dm(par, v, g=None):
        r = P[par]["values"][str(v)]["mcc"]
        return r["mean"] if g is None else r["groups"][G[g]]

    def vkey(v):
        return str(v).replace(".", "").replace("-", "m")

    def rng(par):
        ok = []
        for v, r in P[par]["values"].items():
            m = r["mcc"]
            if m["mean"] >= -0.005 and all(x >= -0.02 for x in m["groups"].values()):
                ok.append(float(v))
        return ok

    def fmtv(x):
        return f"{x:g}"
    # short-key facts
    for par, d in P.items():
        for v, r in d["values"].items():
            kk = f"{par.replace('_', '')}_{vkey(v)}"
            FACT[f"sn_{kk}"] = sg(r["mcc"]["mean"], 3)
            FACT[f"snl_{kk}"] = f"{r['mcc']['lo']:+.3f}".replace("-", "$-$").replace("+", "$+$")
            FACT[f"snh_{kk}"] = f"{r['mcc']['hi']:+.3f}".replace("-", "$-$").replace("+", "$+$")
            FACT[f"snp_{kk}"] = sg(r["aucpr"]["mean"], 3)
            for g in G:
                FACT[f"sn{g}_{kk}"] = sg(r["mcc"]["groups"][G[g]], 3)
            FACT[f"acc_{kk}"] = f"{100 * r['acc']['acc_rate']:.0f}"
            FACT[f"fill_{kk}"] = f"{100 * r['acc']['fill_share']:.0f}"
            FACT[f"unf_{kk}"] = f"{100 * r['acc']['unfinished']:.0f}"
            FACT[f"t3rel_{kk}"] = f"{r['acc']['t_stage3'] / P['theta_q']['values']['0.25']['acc']['t_stage3']:.1f}"
    gz = np.array(S["grid_mcc"]["z"]); ge = S["grid_mcc"]["eta"]; gt = S["grid_mcc"]["tau"]
    FACT["gr_min"] = f"{gz.min():.3f}"; FACT["gr_max"] = f"{gz.max():.3f}"
    FACT["gr_low_range"] = f"{gz[:, [i for i, t in enumerate(gt) if t <= 0.25]].max() - gz[:, [i for i, t in enumerate(gt) if t <= 0.25]].min():.3f}"
    FACT["gr_eta15_tau1"] = f"{gz[ge.index(1.5), gt.index(1.0)]:.3f}"; FACT["gr_eta15_tau005"] = f"{gz[ge.index(1.5), gt.index(0.05)]:.3f}"
    FACT["gr_eta05_tau01"] = f"{gz[ge.index(0.5), gt.index(0.1)]:.3f}"
    FACT["sn_default_mcc"] = f"{S['default_mean']['mcc']:.3f}"
    FACT["sn_ntasks"] = str(len(S["tasks"]))
    rows = [
        ("$k_0$", "5", "3--80", "any", "inactive for $n\\ge100$, because $\\lceil\\sqrt n\\rceil$ exceeds it; matters only for very small data sets"),
        ("$k$ scale ($k=c\\lceil\\sqrt n\\rceil$)", "1", "0.25--4", None, "do not go below 0.5 ($c=0.25$ loses " + f"{abs(dm('k_scale', 0.25)):.3f} MCC)"),
        ("bandwidth multiplier", "1", "0.25--4", None, "keep $\\le1$ when $d\\ge20$ (multiplier 2: " + sg(dm('h_mult', 2.0, 'd')) + ", 4: " + sg(dm('h_mult', 4.0, 'd')) + " at IR$\\ge10$, $d\\ge20$)"),
        ("step $\\eta$", "0.5", "0.1--1.5", None, "smaller for $d\\ge20$ and IR$\\ge10$ ($\\eta=1.5$: " + sg(dm('eta', 1.5, 'd')) + "); larger for IR$\\ge10$, $d<20$ (" + sg(dm('eta', 1.5, 'c')) + ")"),
        ("temperature $\\tau$", "0.1", "0--1", None, "$\\tau\\ge0.25$ loses up to " + f"{abs(dm('tau', 1.0, 'd')):.3f}" + " at IR$\\ge10$, $d\\ge20$; $\\tau=0$ loses diversity"),
        ("max. steps $T$", "30", "3--100", None, "$T=3$ leaves " + f"{100 * P['T']['values']['3']['acc']['unfinished']:.0f}" + "\\% of the chains unfinished; $T\\ge10$ is sufficient"),
        ("local neighbours $k_g$", "5", "2--12", None, "more neighbours help for IR$\\ge10$, $d\\ge20$ ($k_g=12$: " + sg(dm('k_gen', 12, 'd')) + "); 2--3 lose"),
        ("fixed shrinkage $\\rho$", "adaptive", "0.05--1", None, "light fixed $\\rho$ helps for IR$\\ge10$, $d\\ge20$ ($\\rho=0.05$: " + sg(dm('rho_fixed', 0.05, 'd')) + "); $\\rho\\ge0.75$ loses"),
        ("floor $\\rho_{\\min}$", "0.01", "0--0.5", None, "no effect up to 0.2; needed only for validity"),
        ("threshold quantile $q$", "0.25", "0--1", None, "larger $q$ gains " + sg(dm('theta_q', 0.5)) + " ($q=0.5$) but accepts fewer points; smaller $q$ loses"),
        ("fixed threshold $\\theta$", "$\\min\\{\\frac12,Q_{0.25}\\}$", "0.1--0.9", None, "$\\theta\\ge0.5$ gains " + sg(dm('theta', 0.5)) + " to " + sg(dm('theta', 0.7)) + " at " + f"{100 * P['theta']['values']['0.5']['acc']['acc_rate']:.0f}" + "\\%--" + f"{100 * P['theta']['values']['0.9']['acc']['acc_rate']:.0f}" + "\\% accepted"),
        ("rounds", "5", "1--10", "any", "no effect: the first round already supplies enough accepted points"),
    ]
    keys = ["k0", "k_scale", "h_mult", "eta", "tau", "T", "k_gen", "rho_fixed", "rho_min", "theta_q", "theta", "rounds"]
    lines = []
    for (name, dflt, tested, rg, note), par in zip(rows, keys):
        OVR = {"T": "10--100", "rho_min": "0--0.2", "rounds": "1--10", "theta_q": "0.25 (larger: post hoc)", "theta": "none fixed (post hoc)"}
        if par in OVR:
            rg = OVR[par]
        if rg is None:
            ok = rng(par)
            rg = f"{fmtv(min(ok))}--{fmtv(max(ok))}" if ok else "--"
        lines.append(f"{name} & {dflt} & {tested} & {rg} & {note} \\\\")
    open(f"{OUT}/tab_sens.tex", "w").write("\n".join(lines))

# ------------------------------------------------------------------------------------------------ sample quality on the benchmark
p = f"{RES}/quality_summary.json"
if os.path.exists(p):
    Q = json.load(open(p))
    MN = {"ROS": "ROS", "SMOTE": "SMOTE", "B-SMOTE": "B-SMOTE", "ADASYN": "ADASYN", "SVM-SMOTE": "SVM-SMOTE", "KM-SMOTE": "$k$M-SMOTE", "MWMOTE": "MWMOTE", "CCR": "CCR", "BDO": "BDO", "SGBO": "SGBO"}
    COLS = ["prec", "rec", "nn_ratio", "mmd_ho", "deep_frac", "bnd_frac", "maj_ratio"]
    lines = []
    for m, lab in MN.items():
        x = Q["mean"][m]
        cells = [f"{x[c]:.3f}" if c != "nn_ratio" else f"{x[c]:.2f}" for c in COLS]
        cells = [f"\\textbf{{{c}}}" if m == "SGBO" else c for c in cells]
        lines.append(("\\textbf{SGBO}" if m == "SGBO" else lab) + " & " + " & ".join(cells) + " \\\\")
        for c in COLS + ["dup_frac", "logdens_diff", "share_mean", "edist_ho"]:
            FACT[f"qd_{c}_{m.replace('-', '')}"] = f"{x[c]:.3f}" if c != "nn_ratio" else f"{x[c]:.2f}"
    r = Q["reference"]
    lines.append("\\midrule")
    lines.append(f"held-out real minority points & -- & -- & 1 & 0 & {r['deep_frac_ho']:.3f} & {r['bnd_frac_ho']:.3f} & 1 \\\\")
    open(f"{OUT}/tab_quality.tex", "w").write("\n".join(lines))
    FACT["qd_ref_deep"] = f"{r['deep_frac_ho']:.3f}"; FACT["qd_ref_bnd"] = f"{r['bnd_frac_ho']:.3f}"
    for met, v in Q["paired"].items():
        for m, x in v["vs"].items():
            FACT[f"qp_{met}_{m.replace('-', '')}"] = sg(x["mean"], 3)
            FACT[f"qph_{met}_{m.replace('-', '')}"] = pv(x["p_holm"])
            FACT[f"qpw_{met}_{m.replace('-', '')}"] = f"{x['sgbo_better']}/{x['n']}"
        for m, rk in v["ranks"].items():
            FACT[f"qr_{met}_{m.replace('-', '')}"] = f"{rk:.2f}"
    sgq = Q["sgbo"]
    FACT["qs_rej_mean"] = f"{100 * sgq['rej_share_mean']:.1f}"; FACT["qs_rej_med"] = f"{100 * sgq['rej_share_median']:.1f}"; FACT["qs_rej_max"] = f"{100 * sgq['rej_share_max']:.0f}"
    FACT["qs_unf_mean"] = f"{100 * sgq['unfinished_mean']:.1f}"; FACT["qs_unf_med"] = f"{100 * sgq['unfinished_median']:.1f}"; FACT["qs_unf_max"] = f"{100 * sgq['unfinished_max']:.0f}"
    FACT["qs_fill_max"] = f"{100 * sgq['fill_share_max']:.0f}"; FACT["qs_calls"] = str(sgq["n_calls"])
    top = sorted(sgq["by_task"].items(), key=lambda kv: -kv[1]["unf"])[:4]
    FACT["qs_unf_top"] = ", ".join(f"{k} ({100 * v['unf']:.0f}\\%)" for k, v in top)
    toprej = sorted(sgq["by_task"].items(), key=lambda kv: -kv[1]["rej"])[:3]
    FACT["qs_rej_top"] = ", ".join(f"{k} ({100 * v['rej']:.0f}\\%)" for k, v in toprej)
    FACT["qs_n_src"] = str(Q["n_sources"])

json.dump(FACT, open(f"{RES}/facts_part_tables_b.json", "w"), indent=0)
print(len(FACT), "short-key facts")
