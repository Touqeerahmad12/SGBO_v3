"""Short-key facts of the robustness sweeps on the known model (synth_summary.json) and the cost study
(scalability_summary.json) -> results/facts_part_tables_c.json; scalability table -> manuscript_v3/tables/tab_scale.tex"""
import os, sys, json
import numpy as np
RES, OUT = "../results", "../manuscript_v3/tables"
FACT = {}
cl = lambda s: str(s).replace("-", "").replace(" ", "").replace("+", "p")
xs = lambda v: ("%g" % v).replace(".", "p")

p = f"{RES}/synth_summary.json"
if os.path.exists(p):
    S = json.load(open(p))
    FACT["rb_seeds"] = str(S["n_seeds"]); FACT["rb_settings"] = str(S["pooled"]["mcc"]["n_settings"])
    for met in ("mcc", "aucpr", "f1", "gmean"):
        P = S["pooled"][met]
        for m, v in P["rank"].items():
            FACT[f"rbk_{met}_{cl(m)}"] = f"{v:.2f}"
        FACT[f"rbg_{met}_smote"] = f"{100 * P['sgbo_gt_smote']:.0f}"; FACT[f"rbg_{met}_svm"] = f"{100 * P['sgbo_gt_svm']:.0f}"; FACT[f"rbg_{met}_bdo"] = f"{100 * P['sgbo_gt_bdo']:.0f}"
    for f in ("s", "rho", "q", "ir"):
        for m, c in S["curve"][f]["mcc"].items():
            for x, v in zip(c["x"], c["mean"]):
                FACT[f"rbc_{f}_{cl(m)}_{xs(x)}"] = f"{v:.3f}"
        for cmp, d in S["diff"][f].items():
            for met in ("mcc", "aucpr"):
                for k, r in d[met].items():
                    kk = "all" if k == "all" else xs(float(k))
                    FACT[f"rbd_{f}_{cl(cmp)}_{met}_{kk}"] = ("$+$" if r["mean"] >= 0 else "$-$") + f"{abs(r['mean']):.3f}"
                    FACT[f"rbl_{f}_{cl(cmp)}_{met}_{kk}"] = f"{r['lo']:.3f}"; FACT[f"rbh_{f}_{cl(cmp)}_{met}_{kk}"] = f"{r['hi']:.3f}"
        for m, d in S["fidelity"][f]["deep_majority"].items():
            for x, v in d.items():
                FACT[f"rbp_{f}_{cl(m)}_{xs(float(x))}"] = f"{100 * v:.0f}"

# ------------------------------------------------------------------------------------------------ cost study
p = f"{RES}/scalability_summary.json"
if os.path.exists(p):
    C = json.load(open(p))
    METH = ["SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
    NAME = {"KM-SMOTE": "$k$M-SMOTE", "SMOTE-ENN": "SMOTE-ENN"}
    def tf(x):
        return "--" if x is None else (f"{x:.3f}" if x < 0.1 else f"{x:.2f}" if x < 10 else f"{x:.1f}" if x < 100 else f"{x:.0f}")
    rows = []
    for m in METH:
        T = C["times"]["n"].get(m, {})
        t4 = T.get("4000"); tmax = None
        ks = sorted(T, key=float)
        big = [k for k in ks if float(k) >= 16000]
        t16 = T.get("16000")
        sl = C["slopes"]["n"].get(m); sd = C["slopes"]["d"].get(m)
        mem = C.get("memory", {}).get("n", {}).get("8000", {}).get(m)
        sm = C["times"]["n"]["SMOTE"].get("4000")
        for sw, key in (("n", "n"), ("d", "d"), ("n_pos", "np"), ("n_new", "nn")):
            q = C["slopes"].get(sw, {}).get(m)
            if q:
                FACT[f"sc_sl_{key}_{cl(m)}"] = f"{q['slope']:.2f}"; FACT[f"sc_slu_{key}_{cl(m)}"] = f"{q['slope_upper']:.2f}"
                FACT[f"sc_sll_{key}_{cl(m)}"] = f"{q['lo']:.2f}"; FACT[f"sc_slh_{key}_{cl(m)}"] = f"{q['hi']:.2f}"
        for sw in C["times"]:
            tv = list(C["times"][sw].get(m, {}).values())
            if tv:
                FACT[f"sc_tmin_{sw}_{cl(m)}"] = tf(min(tv)); FACT[f"sc_tmax_{sw}_{cl(m)}"] = tf(max(tv))
            for v, t in C["times"][sw].get(m, {}).items():
                FACT[f"sc_t_{sw}_{cl(m)}_{v}"] = tf(t)
        if t4 is not None and sm:
            FACT[f"sc_x_{cl(m)}"] = f"{t4 / sm:.0f}" if t4 / sm >= 10 else f"{t4 / sm:.1f}"
        d200 = C["times"]["d"].get(m, {}).get("200")
        cells = [NAME.get(m, m), tf(t4), tf(t16), f"{sl['slope']:.2f}" if sl else "--", tf(d200), f"{sd['slope']:.2f}" if sd else "--",
                 f"{mem:.0f}" if mem is not None else "--"]
        if m == "SGBO":
            cells = ["\\textbf{" + c + "}" for c in cells]
        rows.append(" & ".join(cells) + " \\\\")
    open(f"{OUT}/tab_scale.tex", "w").write("\n".join(rows) + "\n")
    for k, v in C["clf"]["fit"].items():
        FACT["sc_fit_" + k.replace("t_fit_", "")] = tf(None if v != v else v)
    FACT["sc_prep"] = f"{1000 * C['clf']['prep']:.1f}"
    for sw in C["stages"]:
        for v, (a, b, c) in C["stages"][sw].items():
            tot = a + b + c
            FACT[f"sc_st1_{sw}_{v}"] = f"{100 * a / tot:.0f}"; FACT[f"sc_st2_{sw}_{v}"] = f"{100 * b / tot:.0f}"; FACT[f"sc_st3_{sw}_{v}"] = f"{100 * c / tot:.0f}"
    for sw, d in C.get("memory", {}).items():
        for v, mm in d.items():
            for m, x in mm.items():
                FACT[f"sc_mem_{sw}_{cl(m)}_{v}"] = f"{x:.0f}" if x >= 10 else f"{x:.1f}"
    for r in C["clf"]["resample"]:
        pass

# ------------------------------------------------------------------------------------------------ training-only tuning
p = f"{RES}/tables_facts.json"
if os.path.exists(p) and "tuning" in json.load(open(p)):
    T = json.load(open(p))["tuning"]
    sg3 = lambda x: ("$+$" if x >= 0 else "$-$") + f"{abs(x):.3f}"
    FACT["tun_n_tasks"] = str(T["n_tasks"]); FACT["tun_n_cases"] = str(T["n_cases"])
    for met in ("mcc", "aucpr"):
        for m, v in T["delta"][met].items():
            FACT[f"tun_d_{met}_{cl(m)}"] = sg3(v)
        FACT[f"tun_dmax_{met}"] = f"{max(abs(v) for v in T['delta'][met].values()):.3f}"
        for m, v in T["ranks"][met].items():
            FACT[f"tun_rk_{met}_{cl(m)}"] = f"{v:.2f}"
    tot = sum(T["sgbo_choices"].values())
    for k, v in T["sgbo_choices"].items():
        FACT["tun_tau_" + k.split(":")[1].strip(" }").replace(".", "")] = f"{100 * v / tot:.0f}"

json.dump(FACT, open(f"{RES}/facts_part_tables_c.json", "w"), indent=0)
print(len(FACT), "facts (c)")
