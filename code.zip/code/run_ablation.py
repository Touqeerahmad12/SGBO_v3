"""
Component ablation on all benchmark tasks: the full SGBO and 11 variants that each remove or replace one
component (sgbo/variants.py), evaluated with the protocol of the main benchmark (repetitions 0 and 1, the
same splits and the same sampler random streams as the main benchmark, four classifiers).

    python run_ablation.py            # -> results/ablation.csv   (about 45 min on 2 cores)
"""
import _threads  # noqa: F401
import os, sys, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.datasets import task_registry
from sgbo.protocol import run, RES
from sgbo.variants import ablation_variants

if __name__ == "__main__":
    reps = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    run(task_registry(), [], reps, os.path.join(RES, "ablation.csv"), extra_fn=ablation_variants, save=False)
