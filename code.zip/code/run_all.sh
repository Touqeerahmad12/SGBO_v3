#!/bin/bash
# Reproduce every number, table and figure of the manuscript from the code in this directory.
#   ./run_all.sh post      post-processing only (analysis -> figures -> tables -> facts -> PDF); minutes
#   ./run_all.sh all       all experiments (about 5-6 h on two cores) followed by post-processing
# Experiments write to ../results; run_scalability.py must run ALONE (no other job) because it measures time.
set -e
cd "$(dirname "$0")"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
mode=${1:-post}

if [ "$mode" = "all" ]; then
  python3 -m unittest discover -s tests            # unit tests of all samplers (23 tests)
  python3 verify_theory.py                          # numerical checks of theorems, propositions and examples
  python3 run_benchmark.py --reps 5                 # main benchmark: 12 methods x 4 classifiers x 45 tasks x 25 splits
  python3 run_known.py                              # known-model studies: consistency, ablation, shrinkage, Langevin, quality
  python3 run_ablation.py                           # whole-benchmark component ablation
  python3 run_sensitivity.py                        # parameter sensitivity and eta x tau grid
  python3 run_quality.py                            # sample quality on all benchmark tasks
  python3 run_synthetic.py                          # robustness sweeps on the known model
  python3 run_tuning.py                             # nested training-only tuning
  python3 run_scalability.py                        # runtime and memory (run alone, last)
fi

# ---- analysis (result files -> *_summary.json)
python3 analysis_main.py
python3 analysis_known.py
python3 analysis_ablation.py
python3 analysis_sensitivity.py
python3 analysis_quality.py
python3 analysis_synth.py
python3 analysis_apps.py
python3 analysis_scale.py
# ---- figures (../manuscript_v3/figures)
python3 figs_illus.py
python3 figs_known.py
python3 figs_main.py heatmap summary effects ranks ir
python3 figs_quality.py
python3 figs_sens.py
python3 figs_robust.py
python3 figs_scale.py
python3 figs_apps.py
# ---- tables and facts: every number in the text is a macro \F{key} defined in facts.tex
python3 make_tables.py > /dev/null
python3 make_tables_b.py
python3 make_tables_c.py
python3 make_facts.py
# ---- manuscript (main.pdf and supplement.pdf)
bash ../manuscript_v3/build.sh
