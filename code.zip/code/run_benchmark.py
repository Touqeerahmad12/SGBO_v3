"""
Main benchmark: 5 x repeated stratified 5-fold cross-validation, 12 methods x 4 classifiers x all tasks.

    python run_benchmark.py --reps 5                 # -> results/benchmark.csv  (about 80 min on 2 cores)
    python run_benchmark.py --only yeast4 --out /tmp/x.csv

The protocol is documented in sgbo/protocol.py.
"""
import _threads  # noqa: F401  (single-threaded BLAS for bit-reproducibility)
import os, sys, argparse, warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo.datasets import task_registry, load_keel_folder
from sgbo.registry import METHODS
from sgbo.protocol import run, RES

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--reps", type=int, default=5)
    ap.add_argument("--only", nargs="*", default=None)
    ap.add_argument("--skip", nargs="*", default=None)
    ap.add_argument("--methods", nargs="*", default=None)
    ap.add_argument("--out", default=os.path.join(RES, "benchmark.csv"))
    ap.add_argument("--jobs", type=int, default=2)
    ap.add_argument("--keel", default=None, help="folder with KEEL .dat files (numeric attributes)")
    a = ap.parse_args()
    if a.keel:
        tasks = [dict(name=n, X=X, y=y, source=n, split=None) for n, X, y, _ in load_keel_folder(a.keel)]
    else:
        tasks = task_registry()
    if a.only:
        tasks = [t for t in tasks if t["name"] in a.only]
    if a.skip:
        tasks = [t for t in tasks if t["name"] not in a.skip]
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    run(tasks, a.methods or METHODS, a.reps, a.out, n_jobs=a.jobs)
