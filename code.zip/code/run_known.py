"""
Mechanism-level studies on the controlled model with known class-conditional densities
(the model of run_synthetic.py: majority N(0, I_2), minority = two Gaussian clusters, q irrelevant
N(0,1) features).  Because p0, p1 and eta are known, every quantity below is measured against the
true model.

  python run_known.py consistency   # Section 6.3: accuracy of the boundary score vs n (Theorem 2, component a-b)
  python run_known.py quality       # Section 6.5: sample quality of all samplers against the true model
  python run_known.py ablation      # Section 6.3: components under the conditions they were designed for
  python run_known.py shrink        # Section 6.3: covariance shrinkage, condition numbers, dimension
  python run_known.py langevin      # Section 6.3: Langevin noise, repeated runs (known model + real tasks)
"""
import _threads  # noqa: F401
import os, sys, time, warnings
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from scipy.special import logsumexp
from scipy.stats import spearmanr
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import SGBO, make_sampler
from sgbo.common import binary_entropy
from sgbo.protocol import classifiers, scores, RES
from sgbo.variants import ablation_variants
from sgbo.quality import improved_pr, mmd2_unbiased, _median_bandwidth, _kth_radius
from run_synthetic import sample, eta, U, SIG

BASE = dict(s=2.0, ir=10, q=0, rho=0.0, n=1000)
SAMPLERS = ["ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]


# ----------------------------------------------------------------------------------------------
# the true model
# ----------------------------------------------------------------------------------------------
def comps_logpdf(X, s, q):
    Z = X[:, :2]
    return np.vstack([-0.5 * np.sum((Z - s * u) ** 2, 1) / SIG ** 2 - np.log(2 * np.pi * SIG ** 2) for u in U])


def log_p1(X, s, q):
    lp = logsumexp(comps_logpdf(X, s, q), axis=0) - np.log(2)
    if q:
        lp = lp - 0.5 * np.sum(X[:, 2:] ** 2, 1) - 0.5 * q * np.log(2 * np.pi)
    return lp


def draw_minority(m, s, q, rng):
    comp = rng.integers(0, 2, size=m)
    X = s * U[comp] + SIG * rng.standard_normal((m, 2))
    if q:
        X = np.hstack([X, rng.standard_normal((m, q))])
    return X


class TrueModel:
    """Reference quantities of the true minority distribution for one setting."""

    def __init__(self, s, ir, q, sc, rng, m_ref=1500):
        self.s, self.ir, self.q, self.sc = s, ir, q, sc
        self.pi = 1.0 / (1 + ir)
        big = draw_minority(20000, s, q, rng)
        lp = log_p1(big, s, q)
        self.lp_mean, self.lp_q05 = float(lp.mean()), float(np.quantile(lp, 0.05))
        r = comps_logpdf(big, s, q); resp = np.exp(r - logsumexp(r, axis=0))
        self.between_true = float(np.mean(resp.max(0) < 0.9))
        self.ref = sc.transform(big[:m_ref])                       # fresh true minority sample, standardised
        eb = eta(big, s, ir)
        band = (eb >= 0.3) & (eb <= 0.7)
        self.band = sc.transform(big[band][:1500]) if band.sum() >= 20 else None
        self.band_share_true = float(band.mean())
        self.r_ref = float(np.median(_kth_radius(self.ref, 3)))

    def quality(self, Znew, rng):
        s, q, ir = self.s, self.q, self.ir
        Z = self.sc.inverse_transform(Znew)
        et = eta(Z, s, ir)
        lp = log_p1(Z, s, q)
        r = comps_logpdf(Z, s, q); resp = np.exp(r - logsumexp(r, axis=0))
        out = dict(mean_eta=float(et.mean()), deep=float(np.mean(et < self.pi)),
                   below_half=float(np.mean(et < 0.5)),
                   offsupp=float(np.mean(lp < self.lp_q05)), logp1_diff=float(lp.mean() - self.lp_mean),
                   between=float(np.mean(resp.max(0) < 0.9)), between_true=self.between_true,
                   c1_share=float(np.mean(resp[0] > 0.5)), in_band=float(np.mean((et >= 0.3) & (et <= 0.7))),
                   in_band_true=self.band_share_true)
        sub = Znew if len(Znew) <= 1500 else Znew[rng.choice(len(Znew), 1500, replace=False)]
        out["mmd_true"] = mmd2_unbiased(sub, self.ref, _median_bandwidth(sub, self.ref, rng))
        out["prec_true"], out["rec_true"] = improved_pr(self.ref, sub, 3)
        if self.band is not None:
            d = NearestNeighbors(n_neighbors=1).fit(Znew).kneighbors(self.band)[0][:, 0]
            out["bnd_cov"] = float(np.mean(d <= self.r_ref))
        else:
            out["bnd_cov"] = np.nan
        return out


def setting(cfg, seed, test_n=5000):
    rng = np.random.default_rng(30_000 + seed)
    Xtr, yc = sample(cfg["n"], cfg["s"], cfg["ir"], cfg["q"], rng)
    while yc.sum() < 12:
        Xtr, yc = sample(cfg["n"], cfg["s"], cfg["ir"], cfg["q"], rng)
    flip = rng.uniform(size=len(yc)) < cfg["rho"]
    ytr = np.where(flip, 1 - yc, yc)
    Xte, yte = sample(test_n, cfg["s"], cfg["ir"], cfg["q"], rng)
    sc = StandardScaler().fit(Xtr)
    return rng, Xtr, ytr, yc, Xte, yte, sc


def cov_summary(smp):
    ci = smp.cov_info_ if hasattr(smp, "cov_info_") else []
    if not ci:
        return {}
    cond = np.array([c["cond"] for c in ci], float); rank = np.array([c["rank"] for c in ci]); d = smp.Xp_.shape[1]
    fin = np.isfinite(cond)
    return dict(cond_med=float(np.median(cond[fin])) if fin.any() else np.inf, cond_p95=float(np.quantile(cond[fin], 0.95)) if fin.any() else np.inf,
                cond_inf_frac=float(1 - fin.mean()), cond_gt1e8=float(np.mean(~fin | (cond > 1e8))),
                rankdef_frac=float(np.mean(rank < d)), rho_mean=float(np.nanmean([c["rho"] for c in ci])) if any(np.isfinite(c["rho"]) for c in ci) else np.nan,
                n_comp=len(ci))


def known_job(cfg, seed, variants, classify=True, tag=None, clf_names=("RF", "SVM", "kNN", "LR")):
    """One training sample; every variant is run once; quality against the true model + downstream scores."""
    rng, Xtr, ytr, yc, Xte, yte, sc = setting(cfg, seed)
    Xs, Xtes = sc.transform(Xtr), sc.transform(Xte)
    tm = TrueModel(cfg["s"], cfg["ir"], cfg["q"], sc, np.random.default_rng(777 + seed))
    rows = []
    for name, factory in variants.items():
        smp = factory()
        Xr, yr = smp.fit_resample(Xs, ytr, np.random.default_rng(seed * 101 + 3))[:2]
        new = Xr[len(Xs):]
        base = dict(cfg, seed=seed, variant=name, tag=tag)
        if len(new):
            base.update(tm.quality(new, np.random.default_rng(seed)))
        if isinstance(smp, SGBO) and hasattr(smp, "diag_"):
            d = smp.diag_
            base.update(rej_share=1 - d["n_acc"] / max(d["n_cand"], 1), unfinished=d["chains_unfinished"] / max(d["chains"], 1),
                        fill_share=d["n_fill"] / max(len(new), 1), rounds=d["rounds_used"], t_total=sum(smp.timing_.values()), **cov_summary(smp))
            if len(new) > 1:
                base["spread_new"] = float(np.mean(np.std(new, axis=0)))
        if classify:
            for cn, clf in classifiers(seed).items():
                if cn not in clf_names:
                    continue
                clf.fit(Xr, yr)
                rows.append(dict(base, clf=cn, **scores(clf, Xtes, yte)))
        else:
            rows.append(base)
    return rows


def run_jobs(jobs, out, n_jobs=2):
    t0 = time.time()
    res = Parallel(n_jobs=n_jobs, verbose=5)(delayed(known_job)(*j) for j in jobs)
    df = pd.DataFrame([r for rr in res for r in rr])
    df.to_csv(os.path.join(RES, out), index=False)
    print("saved", out, len(df), "rows in", round(time.time() - t0), "s", flush=True)


# ----------------------------------------------------------------------------------------------
# variants
# ----------------------------------------------------------------------------------------------
def sgbo_variants():
    return ablation_variants(record=True)


def conditions():
    """Each component is examined under the condition for which it was designed."""
    b = dict(BASE)
    return {
        "base": dict(b),
        "large n (n=8000, IR 20)": dict(b, n=8000, ir=20),
        "small n (n=300)": dict(b, n=300),
        "overlap (s=1)": dict(b, s=1.0),
        "label noise (10%)": dict(b, rho=0.10),
        "high dim (d=40)": dict(b, q=38),
        "extreme IR (100)": dict(b, ir=100, n=2000),
    }


# ----------------------------------------------------------------------------------------------
# studies
# ----------------------------------------------------------------------------------------------
def study_quality(seeds=range(10)):
    conds = {"base": BASE, "overlap (s=1)": dict(BASE, s=1.0), "separated (s=3)": dict(BASE, s=3.0),
             "high dim (d=10)": dict(BASE, q=8), "high dim (d=40)": dict(BASE, q=38),
             "label noise (10%)": dict(BASE, rho=0.10), "IR 50": dict(BASE, ir=50, n=2000)}
    variants = {m: (lambda m=m: make_sampler(m)) for m in SAMPLERS}
    variants["SGBO"] = lambda: SGBO(record=True)
    jobs = [(cfg, sd, variants, False, tag) for tag, cfg in conds.items() for sd in seeds]
    run_jobs(jobs, "known_quality.csv")


def study_ablation(seeds=range(20)):
    var = sgbo_variants()
    jobs = [(cfg, sd, var, True, tag, ("RF", "kNN", "SVM", "LR")) for tag, cfg in conditions().items() for sd in seeds]
    run_jobs(jobs, "known_ablation.csv")


def study_shrink(seeds=range(20)):
    qs = [0, 3, 8, 18, 48, 98]
    var = {"LW + floor (default)": lambda: SGBO(record=True),
           "no shrinkage": lambda: SGBO(record=True, shrink=False),
           "rho = 0.05": lambda: SGBO(record=True, rho_fixed=0.05),
           "rho = 0.25": lambda: SGBO(record=True, rho_fixed=0.25),
           "rho = 0.5": lambda: SGBO(record=True, rho_fixed=0.5),
           "rho = 1": lambda: SGBO(record=True, rho_fixed=1.0),
           "no shrinkage, no test": lambda: SGBO(record=True, shrink=False, filter=False),
           "LW, no test": lambda: SGBO(record=True, filter=False)}
    jobs = [(dict(BASE, q=q, n=800, ir=10), sd, var, True, f"d={2+q}", ("RF", "kNN", "LR")) for q in qs for sd in seeds]
    run_jobs(jobs, "known_shrink.csv")


def study_consistency(reps=60):
    """Accuracy of different neighbourhood rules for the boundary score as n grows (Theorem 2)."""
    ns = [250, 500, 1000, 2000, 4000, 8000, 16000]
    rules = {"BDO (k=n+, uniform)": dict(adaptive_k=False, weighted=False), "k=n+, weighted": dict(adaptive_k=False, weighted=True),
             "k=5, uniform": dict(k_fixed=5, weighted=False), "k=sqrt(n), uniform": dict(weighted=False),
             "SGBO (k=sqrt(n), weighted)": dict()}

    def job(n, rep, q):
        rng = np.random.default_rng(50_000 + rep)
        cfg = dict(BASE, n=n, q=q)
        X, y = sample(n, cfg["s"], cfg["ir"], q, rng)
        while y.sum() < 12:
            X, y = sample(n, cfg["s"], cfg["ir"], q, rng)
        # evaluation points: fresh majority-class locations (where seeds are drawn from) and fresh minority points
        Q0 = rng.standard_normal((1500, 2 + q))
        eval_sets = {"majority": Q0}
        rows = []
        for setname, Q in eval_sets.items():
            et = eta(Q, cfg["s"], cfg["ir"]); bt = binary_entropy(et)
            top = bt >= np.quantile(bt, 0.9)
            for rname, kw in rules.items():
                s = SGBO(**kw)
                s.y_ = y; s.k_ = s._k(len(X), int(y.sum())); s.nn_ = NearestNeighbors().fit(X)
                eh = s.posterior(Q); bh = binary_entropy(eh)
                sel = bh >= np.quantile(bh, 0.9)
                rows.append(dict(n=n, rep=rep, q=q, rule=rname, k=s.k_, eval=setname,
                                 mae_eta=float(np.mean(np.abs(eh - et))), mae_b=float(np.mean(np.abs(bh - bt))),
                                 rho_b=float(spearmanr(bh, bt).statistic), prec10=float(np.mean(top[sel])),
                                 bias_eta=float(np.mean(eh - et))))
        return rows

    jobs = [(n, r, q) for q in (0, 8) for n in ns for r in range(reps)]
    res = Parallel(n_jobs=2, verbose=5)(delayed(job)(*j) for j in jobs)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "known_consistency.csv"), index=False)
    print("consistency done", flush=True)


def study_langevin(R=20):
    """Repeated runs of SGBO with different Langevin temperatures on fixed training sets:
    diversity, coverage of real minority points, boundary coverage, classification and its run-to-run spread."""
    from sgbo.datasets import task_registry
    from sgbo.protocol import splits_for
    from sgbo.quality import minority_share
    taus = [0.0, 0.1, 0.25, 0.5]
    names = ["syn-2cluster-ir20", "syn-overlap-ir10", "syn-moons-ir10", "yeast4", "ecoli3", "bcancer-ir10", "ionosphere", "page-blocks0",
             "glass6", "vehicle0", "abalone9-18", "haberman"]
    T = {t["name"]: t for t in task_registry()}

    def job(name, fold):
        t = T[name]; rep, f, tr, te = splits_for(t, 1)[fold]
        X, y = t["X"], t["y"]
        sc = StandardScaler().fit(X[tr]); Xs, Xte = sc.transform(X[tr]), sc.transform(X[te]); ytr, yte = y[tr], y[te]
        P = Xs[ytr == 1]
        sh = minority_share(Xs, ytr, P, 5, self_idx=np.flatnonzero(ytr == 1))
        near_bnd = P[(sh >= 0.2) & (sh <= 0.8)]                # real minority points near the class boundary
        r_ref = float(np.median(_kth_radius(P, 3)))
        rows = []
        for tau in taus:
            for run in range(R):
                smp = SGBO(tau=tau, record=False)
                Xr, yr = smp.fit_resample(Xs, ytr, np.random.default_rng(900 + run))[:2]
                new = Xr[len(Xs):]
                dd = NearestNeighbors(n_neighbors=1).fit(new).kneighbors(P)[0][:, 0]
                bc = float(np.mean(NearestNeighbors(n_neighbors=1).fit(new).kneighbors(near_bnd)[0][:, 0] <= r_ref)) if len(near_bnd) >= 3 else np.nan
                # diversity: mean nearest-neighbour distance among the synthetic points, relative to the minority spacing
                sub = new[np.random.default_rng(run).choice(len(new), min(len(new), 1500), replace=False)]
                nnd = float(np.mean(NearestNeighbors(n_neighbors=2).fit(sub).kneighbors(sub)[0][:, 1]))
                prec, rec = improved_pr(P, sub, 3)
                base = dict(dataset=name, fold=fold, tau=tau, run=run, div_nn=nnd / max(float(np.mean(_kth_radius(P, 1))), 1e-12),
                            cover_real=float(np.mean(dd <= r_ref)), bnd_cov=bc, prec=prec, rec=rec,
                            unfinished=smp.diag_["chains_unfinished"] / max(smp.diag_["chains"], 1), n_near_bnd=len(near_bnd))
                for cn, clf in classifiers(0).items():
                    if cn not in ("RF", "kNN", "LR"):
                        continue
                    clf.fit(Xr, yr)
                    rows.append(dict(base, clf=cn, **scores(clf, Xte, yte)))
        return rows

    jobs = [(nm, f) for nm in names for f in range(2 if T[nm]["split"] is None else 1)]
    res = Parallel(n_jobs=2, verbose=5)(delayed(job)(*j) for j in jobs)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "langevin_runs.csv"), index=False)
    print("langevin done", flush=True)


if __name__ == "__main__":
    which = sys.argv[1:] or ["consistency", "quality", "ablation", "shrink", "langevin"]
    for w in which:
        t0 = time.time(); globals()["study_" + w](); print(w, "done", round(time.time() - t0), "s", flush=True)
