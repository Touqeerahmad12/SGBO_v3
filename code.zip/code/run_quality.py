"""
Synthetic-sample quality on all benchmark tasks (Section 6.5): for every task, the 5 folds of
repetition 0, every oversampler (except SMOTE-ENN, which also removes points) generates its synthetic
points from the training part; sgbo/quality.py compares them with the training minority and with the
held-out minority points of the test fold.  SGBO's rejection share and unfinished-trajectory share are
recorded as well.

    python run_quality.py             # -> results/quality_tasks.csv
"""
import _threads  # noqa: F401
import os, sys, time, warnings
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import SGBO, make_sampler
from sgbo.datasets import task_registry
from sgbo.protocol import splits_for, fold_rng, RES
from sgbo.quality import sample_quality

SAMPLERS = ["ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]


def job(task, rep, fold, tr, te):
    X, y = task["X"], task["y"]
    sc = StandardScaler().fit(X[tr]); Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te]); ytr, yte = y[tr], y[te]
    Xho = Xte[yte == 1]
    rows = []
    for m in SAMPLERS:
        smp = make_sampler(m)
        Xr, yr = smp.fit_resample(Xtr, ytr, fold_rng(rep, fold))[:2]
        new = Xr[len(Xtr):]
        r = dict(dataset=task["name"], source=task["source"], rep=rep, fold=fold, method=m, n_new=len(new), d=Xtr.shape[1],
                 n_pos=int(ytr.sum()), ir=float((ytr == 0).sum() / ytr.sum()))
        r.update(sample_quality(Xtr, ytr, new, Xho, np.random.default_rng(fold)))
        if isinstance(smp, SGBO):
            d = smp.diag_
            r.update(rej_share=1 - d["n_acc"] / max(d["n_cand"], 1), unfinished=d["chains_unfinished"] / max(d["chains"], 1),
                     fill_share=d["n_fill"] / max(len(new), 1), rounds=d["rounds_used"], n_chains=d["chains"], no_cand=d["no_candidates"])
        rows.append(r)
    return rows


if __name__ == "__main__":
    jobs = []
    for t in task_registry():
        for rep, fold, tr, te in splits_for(t, 1):
            jobs.append((t, rep, fold, tr, te))
    jobs.sort(key=lambda j: -len(j[0]["y"]))
    t0 = time.time()
    res = Parallel(n_jobs=2, verbose=5)(delayed(job)(*j) for j in jobs)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "quality_tasks.csv"), index=False)
    print("quality done", round(time.time() - t0), "s", flush=True)
