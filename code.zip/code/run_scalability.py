"""
Computational cost of SGBO and the baselines (Section 6.6).

Run this script ALONE (no other job on the machine); it uses one process and one BLAS thread.
  (a) n     : total training size, d = 10, IR = 10
  (b) d     : dimension, n = 4000, IR = 10
  (c) n+    : minority size, n- = 4000 (so that IR falls from 160 to 2.5), classes balanced afterwards
  (d) N_new : number of synthetic points, data fixed (n- = 4000, n+ = 400)
For each configuration and method the median of REPS timings is stored (min and max as well), together
with the time of the preprocessing step (standardisation), the training time of four classifiers on the
resampled data (reported separately), and, for SGBO, the time of its three stages.  A second pass with
tracemalloc records the peak Python/NumPy memory of the resampling call.  A method is dropped from a
sweep when one call exceeded TIME_CAP seconds.

    python run_scalability.py         # -> results/scalability.csv, results/scalability_memory.csv, results/environment.json
"""
import _threads  # noqa: F401
import os, sys, time, json, platform, subprocess, tracemalloc, warnings
import numpy as np, pandas as pd
from sklearn.datasets import make_classification
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import SGBO, make_sampler
from sgbo.protocol import classifiers, RES

METHODS = ["SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
REPS, TIME_CAP = 5, 150.0


def environment():
    import numpy, scipy, sklearn, pandas, joblib
    cpu = subprocess.run("lscpu | grep -E 'Model name|^CPU\\(s\\)|MHz|L2|L3' ", shell=True, capture_output=True, text=True).stdout
    mem = subprocess.run("grep -E 'MemTotal' /proc/meminfo", shell=True, capture_output=True, text=True).stdout
    env = dict(python=sys.version.split()[0], platform=platform.platform(), numpy=numpy.__version__, scipy=scipy.__version__,
               sklearn=sklearn.__version__, pandas=pandas.__version__, joblib=joblib.__version__, cpu=cpu.strip().split("\n"),
               mem=mem.strip(), blas_threads="1 (OMP/OPENBLAS/MKL_NUM_THREADS=1)", reps=REPS, time_cap=TIME_CAP)
    json.dump(env, open(os.path.join(RES, "environment.json"), "w"), indent=1)
    return env


def make_data(n_neg, n_pos, d, seed):
    n = n_neg + n_pos
    X, y = make_classification(n_samples=n, n_features=d, n_informative=max(2, min(d, 5)), n_redundant=0, n_clusters_per_class=1,
                               weights=[n_neg / n], class_sep=1.0, flip_y=0.01, random_state=seed)
    return X, y


def clf_times(Xr, yr):
    out = {}
    for cn, clf in classifiers(0).items():
        if cn == "SVM" and len(yr) > 20000:
            out["t_fit_" + cn] = np.nan
            continue
        t0 = time.perf_counter(); clf.fit(Xr, yr); out["t_fit_" + cn] = time.perf_counter() - t0
    return out


def one_config(sweep, value, n_neg, n_pos, d, n_new, methods, dead, seed=0):
    X, y = make_data(n_neg, n_pos, d, seed)
    t0 = time.perf_counter(); sc = StandardScaler().fit(X); Xs = sc.transform(X); t_prep = time.perf_counter() - t0
    # classifier training time on a balanced set of the same size (SMOTE output), measured once per configuration
    Xb, yb = make_sampler("SMOTE").fit_resample(Xs, y, np.random.default_rng(0))[:2]
    ct = clf_times(Xb, yb)
    rows = []
    for m in methods:
        if m in dead:
            continue
        ts, st = [], []
        for r in range(REPS):
            smp = make_sampler(m)
            if n_new is not None:
                smp.n_new = n_new
            t0 = time.perf_counter(); Xr, yr = smp.fit_resample(Xs, y, np.random.default_rng(r))[:2]; ts.append(time.perf_counter() - t0)
            if isinstance(smp, SGBO) and hasattr(smp, "timing_"):
                st.append([smp.timing_["stage1"], smp.timing_["stage2"], smp.timing_["stage3"]])
            if ts[-1] > TIME_CAP:
                dead.add(m); break
        row = dict(sweep=sweep, value=value, n_neg=n_neg, n_pos=n_pos, d=d, n_new=(n_new if n_new is not None else n_neg - n_pos), method=m,
                   t_med=float(np.median(ts)), t_min=float(np.min(ts)), t_max=float(np.max(ts)), reps=len(ts), t_prep=t_prep, **ct)
        if st:
            s = np.median(np.array(st), axis=0); row.update(t_stage1=s[0], t_stage2=s[1], t_stage3=s[2])
        rows.append(row); print(sweep, value, m, round(row["t_med"], 3), flush=True)
    return rows


def sweeps():
    cfgs = []
    for n in [500, 1000, 2000, 4000, 8000, 16000, 32000]:
        cfgs.append(("n", n, int(round(n * 10 / 11)), n - int(round(n * 10 / 11)), 10, None))
    for d in [2, 5, 10, 20, 50, 100, 200]:
        cfgs.append(("d", d, 3636, 364, d, None))
    for npos in [25, 50, 100, 200, 400, 800, 1600]:
        cfgs.append(("n_pos", npos, 4000, npos, 10, None))
    for nn in [100, 200, 500, 1000, 2000, 4000, 8000]:
        cfgs.append(("n_new", nn, 4000, 400, 10, nn))
    return cfgs


def memory_pass(cfgs):
    rows = []
    for sweep, value, n_neg, n_pos, d, n_new in cfgs:
        if sweep == "n" and value > 16000:
            continue
        X, y = make_data(n_neg, n_pos, d, 0)
        Xs = StandardScaler().fit_transform(X)
        for m in METHODS:
            smp = make_sampler(m)
            if n_new is not None:
                smp.n_new = n_new
            tracemalloc.start()
            t0 = time.perf_counter()
            try:
                smp.fit_resample(Xs, y, np.random.default_rng(0))
                ok = True
            except MemoryError:
                ok = False
            cur, peak = tracemalloc.get_traced_memory(); tracemalloc.stop()
            rows.append(dict(sweep=sweep, value=value, method=m, peak_mb=peak / 2 ** 20, ok=ok))
            print("mem", sweep, value, m, round(peak / 2 ** 20, 1), flush=True)
    return rows


if __name__ == "__main__":
    env = environment(); print(json.dumps(env, indent=1))
    cfgs = sweeps(); rows = []
    dead = {}
    for sweep, value, n_neg, n_pos, d, n_new in cfgs:
        key = sweep
        d_set = dead.setdefault(key, set())
        rows += one_config(sweep, value, n_neg, n_pos, d, n_new, METHODS, d_set)
        pd.DataFrame(rows).to_csv(os.path.join(RES, "scalability.csv"), index=False)
    mem = memory_pass(cfgs)
    pd.DataFrame(mem).to_csv(os.path.join(RES, "scalability_memory.csv"), index=False)
    print("scalability done")
