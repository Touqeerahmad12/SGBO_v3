"""
Parameter sensitivity of SGBO (one parameter at a time around the default, plus an eta x tau grid).

15 tasks that span the imbalance ratio (1.7 ... 41) and the dimension (6 ... 64), repetition 0 (5 folds),
RF / kNN / LR (and SVM when the resampled training set has at most 6000 points).  For every setting the
acceptance statistics and the stage timers of the sampler are recorded as well.

    python run_sensitivity.py         # -> results/sensitivity.csv, results/sensitivity_grid.csv
"""
import _threads  # noqa: F401
import os, sys, time, warnings
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.preprocessing import StandardScaler
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import SGBO
from sgbo.datasets import task_registry
from sgbo.protocol import classifiers, scores, splits_for, fold_rng, RES

TASKS = ["pima", "ecoli1", "ionosphere", "bcancer", "ecoli3", "page-blocks0", "vowel0", "syn-overlap-ir10",
         "digits-8v3-ir10", "syn-hd-ir15", "yeast4", "yeast6", "abalone9-18", "oil-spill", "digits-9-ir40"]
DEFAULTS = dict(k0=5, k_scale=1.0, eta=0.5, tau=0.1, T=30, k_gen=5, rho_fixed=None, rho_min=0.01, h_mult=1.0,
                theta_q=0.25, theta=None, rounds=5)
GRID = {
    "k0": [3, 5, 10, 20, 40, 80],
    "k_scale": [0.25, 0.5, 1.0, 2.0, 4.0],
    "eta": [0.1, 0.25, 0.5, 1.0, 1.5],
    "tau": [0.0, 0.05, 0.1, 0.25, 0.5, 1.0],
    "T": [3, 10, 30, 60, 100],
    "k_gen": [2, 3, 5, 8, 12],
    "rho_fixed": [0.05, 0.1, 0.25, 0.5, 0.75, 1.0],
    "rho_min": [0.0, 0.01, 0.05, 0.2, 0.5],
    "h_mult": [0.25, 0.5, 1.0, 2.0, 4.0],
    "theta_q": [0.0, 0.1, 0.25, 0.5, 0.75, 1.0],
    "theta": [0.1, 0.3, 0.5, 0.7, 0.9],
    "rounds": [1, 2, 5, 10],
}


def job(task, rep, fold, tr, te, configs):
    X, y = task["X"], task["y"]
    sc = StandardScaler().fit(X[tr]); Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te]); ytr, yte = y[tr], y[te]
    rows = []
    for param, value in configs:
        kw = {} if param == "default" else {param: value}
        smp = SGBO(**kw)
        Xr, yr = smp.fit_resample(Xtr, ytr, fold_rng(rep, fold))[:2]
        d = smp.diag_
        base = dict(dataset=task["name"], rep=rep, fold=fold, param=param, value=value if param != "default" else np.nan,
                    k_used=getattr(smp, "k_", np.nan), h_used=getattr(smp, "h_", np.nan), theta_used=getattr(smp, "theta_", np.nan),
                    acc_rate=d["n_acc"] / max(d["n_cand"], 1), fill_share=d["n_fill"] / max(len(yr) - len(ytr), 1),
                    rounds_used=d["rounds_used"], unfinished=d["chains_unfinished"] / max(d["chains"], 1),
                    t_stage1=smp.timing_["stage1"], t_stage2=smp.timing_["stage2"], t_stage3=smp.timing_["stage3"])
        for cn, clf in classifiers(rep).items():
            if cn == "SVM" and len(yr) > 6000:
                continue
            clf.fit(Xr, yr)
            rows.append(dict(base, clf=cn, **scores(clf, Xte, yte)))
    return rows


def grid_job(task, rep, fold, tr, te):
    X, y = task["X"], task["y"]
    sc = StandardScaler().fit(X[tr]); Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te]); ytr, yte = y[tr], y[te]
    rows = []
    for eta in (0.1, 0.25, 0.5, 1.0, 1.5):
        for tau in (0.0, 0.05, 0.1, 0.25, 0.5, 1.0):
            Xr, yr = SGBO(eta=eta, tau=tau).fit_resample(Xtr, ytr, fold_rng(rep, fold))[:2]
            for cn, clf in classifiers(rep).items():
                if cn not in ("RF", "SVM"):
                    continue
                clf.fit(Xr, yr)
                rows.append(dict(dataset=task["name"], fold=fold, eta=eta, tau=tau, clf=cn, **scores(clf, Xte, yte)))
    return rows


if __name__ == "__main__":
    T = {t["name"]: t for t in task_registry()}
    configs = [("default", None)] + [(p, v) for p, vals in GRID.items() for v in vals]
    jobs = []
    for nm in TASKS:
        for rep, fold, tr, te in splits_for(T[nm], 1):
            jobs.append((T[nm], rep, fold, tr, te))
    jobs.sort(key=lambda j: -len(j[0]["y"]))
    t0 = time.time()
    res = Parallel(n_jobs=2, verbose=5)(delayed(job)(*j, configs) for j in jobs)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "sensitivity.csv"), index=False)
    print("sensitivity done", round(time.time() - t0), "s", flush=True)
    gj = [j for j in jobs if j[0]["name"] in ("bcancer", "ecoli3", "syn-overlap-ir10", "yeast4", "pima", "digits-8v3-ir10")]
    res = Parallel(n_jobs=2, verbose=5)(delayed(grid_job)(*j) for j in gj)
    pd.DataFrame([r for rr in res for r in rr]).to_csv(os.path.join(RES, "sensitivity_grid.csv"), index=False)
    print("grid done", round(time.time() - t0), "s", flush=True)
