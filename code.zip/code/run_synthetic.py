"""
Controlled synthetic study with a known posterior.

Model: majority ~ N(0, I_2); minority = equal mixture of two Gaussian clusters
N(s*u_1, 0.5^2 I_2) and N(s*u_2, 0.5^2 I_2) with u_1 = (1, 0), u_2 = (-1/2, sqrt(3)/2),
so the minority class is disconnected and the Bayes boundary is non-linear.
Irrelevant features: q extra coordinates ~ N(0, 1) for both classes (they cancel in eta).
Prior of the minority class: pi = 1/(1+IR). Label noise: each training label is flipped
with probability rho (test labels are clean).

Sweeps (one factor at a time, others at the base value s=2, IR=10, q=0, rho=0, n=1000):
  separation s in {0.75, 1.0, 1.5, 2.0, 2.5, 3.0}      (overlap)
  label noise rho in {0, 0.02, 0.05, 0.10, 0.15}
  irrelevant features q in {0, 2, 8, 18, 38, 78}         (dimension d = 2 + q)
  imbalance ratio IR in {5, 10, 20, 50, 100}             (n = 2000)
For every setting and seed: one training sample, one independent test sample of 5000 points.
Recorded: test metrics of four classifiers; error of the boundary measures against H2(eta);
share of synthetic points on the Bayes-majority side (eta(z) < 1/2); share of synthetic
points whose nearest training point carries a flipped label.
"""
import _threads  # noqa: F401
import os, sys, time
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
from scipy.stats import spearmanr
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import make_sampler, SGBO
from sgbo.common import binary_entropy
from sgbo.protocol import classifiers, scores, RES
from sgbo.registry import METHODS

U = np.array([[1.0, 0.0], [-0.5, np.sqrt(3) / 2]])
SIG = 0.5
BASE = dict(s=2.0, ir=10, q=0, rho=0.0, n=1000)


def sample(n, s, ir, q, rng):
    pi = 1.0 / (1 + ir)
    y = (rng.uniform(size=n) < pi).astype(int)
    X = rng.standard_normal((n, 2))
    pos = np.flatnonzero(y == 1)
    comp = rng.integers(0, 2, size=len(pos))
    X[pos] = s * U[comp] + SIG * rng.standard_normal((len(pos), 2))
    if q:
        X = np.hstack([X, rng.standard_normal((n, q))])
    return X, y


def eta(X, s, ir):
    pi = 1.0 / (1 + ir)
    Z = X[:, :2]
    fn = np.exp(-0.5 * np.sum(Z ** 2, 1)) / (2 * np.pi)
    fp = sum(0.5 * np.exp(-0.5 * np.sum((Z - s * u) ** 2, 1) / SIG ** 2) / (2 * np.pi * SIG ** 2) for u in U)
    return pi * fp / (pi * fp + (1 - pi) * fn)


def boundary_errors(Xtr, ytr, Q, Ht):
    out = {}
    n_pos = int(ytr.sum())
    nb = NearestNeighbors(n_neighbors=n_pos).fit(Xtr).kneighbors(Q, return_distance=False)
    b_bdo = binary_entropy(np.mean(ytr[nb] == 1, 1))
    s = SGBO(); s.y_ = ytr; s.k_ = s._k(len(Xtr), n_pos); s.nn_ = NearestNeighbors().fit(Xtr)
    b_sgbo = binary_entropy(s.posterior(Q))
    for nm, b in (("BDO", b_bdo), ("SGBO", b_sgbo)):
        out[f"err_{nm}"] = float(np.mean(np.abs(b - Ht)))
        out[f"rho_{nm}"] = float(spearmanr(b, Ht).statistic)
    return out


def job(factor, value, seed, methods):
    cfg = dict(BASE); cfg[factor] = value
    if factor == "ir":
        cfg["n"] = 2000
    rng = np.random.default_rng(10_000 + seed)
    Xtr, ytr_clean = sample(cfg["n"], cfg["s"], cfg["ir"], cfg["q"], rng)
    while ytr_clean.sum() < 12:
        Xtr, ytr_clean = sample(cfg["n"], cfg["s"], cfg["ir"], cfg["q"], rng)
    flip = rng.uniform(size=len(ytr_clean)) < cfg["rho"]
    ytr = np.where(flip, 1 - ytr_clean, ytr_clean)
    Xte, yte = sample(5000, cfg["s"], cfg["ir"], cfg["q"], rng)
    sc = StandardScaler().fit(Xtr)
    Xs, Xtes = sc.transform(Xtr), sc.transform(Xte)
    base = dict(factor=factor, value=value, seed=seed, n_pos=int(ytr.sum()))
    Ht = binary_entropy(eta(Xte[:2000], cfg["s"], cfg["ir"]))
    # boundary measures are compared in the standardised space used by the samplers
    errs = boundary_errors(Xs, ytr, Xtes[:2000], Ht)
    rows = []
    nn_tr = NearestNeighbors(n_neighbors=1).fit(Xs)
    pi = 1.0 / (1 + cfg["ir"])
    # reference levels: mean posterior at the clean minority training points, and the share of
    # flipped labels among the minority-labelled training points
    mean_eta_min = float(np.mean(eta(Xtr[ytr_clean == 1], cfg["s"], cfg["ir"])))
    flip_ref = float(np.mean(flip[ytr == 1])) if (ytr == 1).any() else np.nan
    for m in methods:
        r_rng = np.random.default_rng(seed * 101 + 3)
        if m == "None":
            Xr, yr = Xs, ytr
            new = np.empty((0, Xs.shape[1]))
        else:
            Xr, yr = make_sampler(m).fit_resample(Xs, ytr, r_rng)[:2]
            # SMOTE-ENN removes points, so its synthetic points cannot be isolated; CCR appends them at the end
            new = Xr[len(Xs):] if m != "SMOTE-ENN" else np.empty((0, Xs.shape[1]))
        if len(new):
            et = eta(sc.inverse_transform(new), cfg["s"], cfg["ir"])
            wrong = float(np.mean(et < 0.5))             # defined only when the Bayes-minority region exists
            deep = float(np.mean(et < pi))               # minority rarer than at a random location
            meta = float(np.mean(et))
            nn_idx = nn_tr.kneighbors(new, return_distance=False)[:, 0]
            near_flip = float(np.mean(flip[nn_idx]))
        else:
            wrong = deep = meta = near_flip = np.nan
        for cn, clf in classifiers(seed).items():
            clf.fit(Xr, yr)
            r = scores(clf, Xtes, yte)
            r.update(base, method=m, clf=cn, wrong_side=wrong, deep_majority=deep, mean_eta_new=meta,
                     near_flipped=near_flip, mean_eta_min=mean_eta_min, flip_ref=flip_ref, **errs)
            rows.append(r)
    return rows


if __name__ == "__main__":
    sweeps = {"s": [0.75, 1.0, 1.5, 2.0, 2.5, 3.0], "rho": [0.0, 0.02, 0.05, 0.10, 0.15],
              "q": [0, 2, 8, 18, 38, 78], "ir": [5, 10, 20, 50, 100]}
    seeds = range(5)
    jobs = [(f, v, sd) for f, vals in sweeps.items() for v in vals for sd in seeds]
    t0 = time.time()
    res = Parallel(n_jobs=2, verbose=5)(delayed(job)(f, v, sd, METHODS) for f, v, sd in jobs)
    df = pd.DataFrame([r for rr in res for r in rr])
    df.to_csv(os.path.join(RES, "synthetic_study.csv"), index=False)
    print("saved", len(df), "rows in", round(time.time() - t0), "s")
