"""
Training-only tuning of the resampling parameters (nested validation).

For every primary task (one per independent source, n <= 3000) and every outer split of
one repetition of stratified 5-fold CV, each method chooses its parameter from a small
grid by an inner stratified 3-fold CV on the outer training part only (criterion: mean
inner MCC). The chosen setting is then refitted on the whole outer training part and
evaluated once on the outer test part. Classifier hyperparameters stay fixed, so any
change with respect to the default run is caused by the resampling parameters.
"""
import _threads  # noqa: F401
import os, sys, time
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import matthews_corrcoef
import warnings
warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import make_sampler
from sgbo.protocol import classifiers, scores, RES
from sgbo.datasets import task_registry

GRIDS = {
    "SMOTE": [dict(k=3), dict(k=5), dict(k=7)],
    "B-SMOTE": [dict(k=3), dict(k=5), dict(k=7)],
    "ADASYN": [dict(k=3), dict(k=5), dict(k=7)],
    "SVM-SMOTE": [dict(k=3), dict(k=5), dict(k=7)],
    "SMOTE-ENN": [dict(k=3), dict(k=5), dict(k=7)],
    "KM-SMOTE": [dict(n_clusters=4), dict(n_clusters=8), dict(n_clusters=16)],
    "MWMOTE": [dict(k1=3), dict(k1=5), dict(k1=7)],
    "CCR": [dict(energy=0.25), dict(energy=1.0), dict(energy=4.0)],
    "SGBO": [dict(tau=0.05), dict(tau=0.1), dict(tau=0.25)],
}
CLFS = ["RF", "kNN"]


def fit_eval(m, params, Xtr, ytr, Xte, yte, cn, seed):
    rng = np.random.default_rng(seed)
    Xr, yr = make_sampler(m, **params).fit_resample(Xtr, ytr, rng)[:2]
    clf = classifiers(0)[cn]; clf.fit(Xr, yr)
    return clf, Xr, yr


def outer_job(task, fold, tr, te):
    X, y = task["X"], task["y"]
    rows = []
    sc = StandardScaler().fit(X[tr]); Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te])
    ytr, yte = y[tr], y[te]
    inner = list(StratifiedKFold(3, shuffle=True, random_state=100 + fold).split(Xtr, ytr))
    for m, grid in GRIDS.items():
        for cn in CLFS:
            best, best_s = None, -np.inf
            for gi, p in enumerate(grid):
                vals = []
                for ii, (a, b) in enumerate(inner):
                    sci = StandardScaler().fit(Xtr[a]); Xa, Xb = sci.transform(Xtr[a]), sci.transform(Xtr[b])
                    clf, _, _ = fit_eval(m, p, Xa, ytr[a], Xb, ytr[b], cn, 7 + ii)
                    vals.append(matthews_corrcoef(ytr[b], clf.predict(Xb)))
                if np.mean(vals) > best_s:
                    best, best_s = gi, float(np.mean(vals))
            clf, _, _ = fit_eval(m, grid[best], Xtr, ytr, Xte, yte, cn, 10 * fold + 7)
            r = scores(clf, Xte, yte)
            r.update(dataset=task["name"], source=task["source"], fold=fold, method=m, clf=cn,
                     chosen=str(grid[best]), inner_mcc=best_s)
            rows.append(r)
    return rows


if __name__ == "__main__":
    tasks = [t for t in task_registry() if t["primary"] and len(t["y"]) <= 3000 and t.get("split") is None]
    jobs = []
    for t in tasks:
        for fold, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=0).split(t["X"], t["y"])):
            jobs.append((t, fold, tr, te))
    jobs.sort(key=lambda j: -len(j[0]["y"]))
    t0 = time.time()
    res = Parallel(n_jobs=2, verbose=5)(delayed(outer_job)(*j) for j in jobs)
    df = pd.DataFrame([r for rr in res for r in rr])
    df.to_csv(os.path.join(RES, "tuning.csv"), index=False)
    print("saved", len(df), "rows,", len(tasks), "tasks in", round(time.time() - t0), "s")
