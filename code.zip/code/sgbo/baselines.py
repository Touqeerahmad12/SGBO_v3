"""
Baseline oversampling algorithms (re-implemented from the original descriptions so that the
study does not depend on third-party resampling packages).

  ROS             random oversampling
  SMOTE           Chawla et al. (2002)
  B-SMOTE         Borderline-SMOTE1, Han et al. (2005)
  ADASYN          He et al. (2008)
  SVM-SMOTE       Nguyen et al. (2011), following the common open implementation
  SMOTE-ENN       Batista et al. (2004)
  KM-SMOTE        k-means SMOTE, Douzas, Bacao and Last (2018)
  MWMOTE          Barua, Islam, Yao and Murase (2014)
  CCR             Combined Cleaning and Resampling, Koziarski and Wozniak (2017)

Interface: ``sampler.fit_resample(X, y, rng)`` with labels y in {0, 1}, 1 = minority, and a
numpy ``Generator`` ``rng``.  The attribute ``n_new`` (default None = balance the classes)
sets the number of synthetic points explicitly; it is used by the scalability study.
"""
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.neighbors import NearestNeighbors
from sklearn.svm import SVC
from .common import split as _split, n_needed, interpolate as _interpolate

class ROS:
    name = "ROS"
    n_new = None

    def fit_resample(self, X, y, rng):
        N = n_needed(y, self.n_new)
        idx = np.flatnonzero(y == 1)
        pick = rng.choice(idx, size=N, replace=True)
        return np.vstack([X, X[pick]]), np.concatenate([y, np.ones(N, int)])


class SMOTE:
    name = "SMOTE"
    n_new = None

    def __init__(self, k=5):
        self.k = k

    def fit_resample(self, X, y, rng, n_new=None):
        Xp = X[y == 1]
        N = n_needed(y, self.n_new) if n_new is None else n_new
        if N <= 0 or len(Xp) < 2:
            return X, y
        k = min(self.k, len(Xp) - 1)
        nn = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        nbrs = nn.kneighbors(Xp, return_distance=False)[:, 1:]
        base = rng.integers(0, len(Xp), size=N)
        col = rng.integers(0, k, size=N)
        new = _interpolate(Xp, Xp, base, nbrs[base, col], rng)
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class BorderlineSMOTE:
    """Borderline-SMOTE1 (Han et al., 2005)."""
    name = "B-SMOTE"
    n_new = None

    def __init__(self, k=5, m=10):
        self.k, self.m = k, m

    def fit_resample(self, X, y, rng):
        Xp = X[y == 1]
        N = n_needed(y, self.n_new)
        m = min(self.m, len(X) - 1)
        nn_all = NearestNeighbors(n_neighbors=m + 1).fit(X)
        nb = nn_all.kneighbors(Xp, return_distance=False)[:, 1:]
        n_maj = np.sum(y[nb] == 0, axis=1)
        danger = (n_maj >= m / 2) & (n_maj < m)
        if danger.sum() == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng, n_new=self.n_new)
        k = min(self.k, len(Xp) - 1)
        nn_p = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        D = Xp[danger]
        nbrs = nn_p.kneighbors(D, return_distance=False)[:, 1:]
        base = rng.integers(0, len(D), size=N)
        col = rng.integers(0, k, size=N)
        new = D[base] + rng.uniform(0, 1, (N, 1)) * (Xp[nbrs[base, col]] - D[base])
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class ADASYN:
    """ADASYN (He et al., 2008)."""
    name = "ADASYN"
    n_new = None

    def __init__(self, k=5):
        self.k = k

    def fit_resample(self, X, y, rng):
        Xp = X[y == 1]
        N = n_needed(y, self.n_new)
        K = min(self.k, len(X) - 1)
        nb = NearestNeighbors(n_neighbors=K + 1).fit(X).kneighbors(Xp, return_distance=False)[:, 1:]
        r = np.sum(y[nb] == 0, axis=1) / K
        if r.sum() == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng, n_new=self.n_new)
        r = r / r.sum()
        g = np.floor(r * N).astype(int)
        rest = N - g.sum()
        if rest > 0:
            np.add.at(g, rng.choice(len(Xp), size=rest, p=r), 1)
        k = min(self.k, len(Xp) - 1)
        nbrs = NearestNeighbors(n_neighbors=k + 1).fit(Xp).kneighbors(Xp, return_distance=False)[:, 1:]
        base = np.repeat(np.arange(len(Xp)), g)
        col = rng.integers(0, k, size=len(base))
        new = _interpolate(Xp, Xp, base, nbrs[base, col], rng)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class SVMSMOTE:
    """SVM-SMOTE (Nguyen et al., 2011), following the common open implementation."""
    name = "SVM-SMOTE"
    n_new = None

    def __init__(self, k=5, m=10, out_step=0.5):
        self.k, self.m, self.out_step = k, m, out_step

    def fit_resample(self, X, y, rng):
        N = n_needed(y, self.n_new)
        Xp = X[y == 1]
        svm = SVC(gamma="scale", random_state=int(rng.integers(1e9))).fit(X, y)
        sv = svm.support_[y[svm.support_] == 1]
        S = X[sv]
        m = min(self.m, len(X) - 1)
        nn_all = NearestNeighbors(n_neighbors=m + 1).fit(X)
        if len(S) > 0:
            nb = nn_all.kneighbors(S, return_distance=False)[:, 1:]
            n_maj = np.sum(y[nb] == 0, axis=1)
            S, n_maj = S[n_maj < m], n_maj[n_maj < m]
        if len(S) == 0 or len(Xp) < 2:
            return SMOTE(self.k).fit_resample(X, y, rng, n_new=self.n_new)
        danger = n_maj >= m / 2
        k = min(self.k, len(Xp) - 1)
        nn_p = NearestNeighbors(n_neighbors=k + 1).fit(Xp)
        n1 = int(rng.beta(10, 10) * (N + 1)) if danger.any() and (~danger).any() else (N if danger.any() else 0)
        parts = []
        for mask, cnt, step in ((danger, n1, 1.0), (~danger, N - n1, -self.out_step)):
            if cnt <= 0 or mask.sum() == 0:
                continue
            B = S[mask]
            nbrs = nn_p.kneighbors(B, return_distance=False)[:, 1:]
            base = rng.integers(0, len(B), size=cnt)
            col = rng.integers(0, k, size=cnt)
            parts.append(B[base] + step * rng.uniform(0, 1, (cnt, 1)) * (Xp[nbrs[base, col]] - B[base]))
        new = np.vstack(parts)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class SMOTEENN:
    """SMOTE followed by Edited Nearest Neighbours cleaning (Batista et al., 2004)."""
    name = "SMOTE-ENN"
    n_new = None

    def __init__(self, k=5, k_enn=3):
        self.k, self.k_enn = k, k_enn

    def fit_resample(self, X, y, rng):
        Xs, ys = SMOTE(self.k).fit_resample(X, y, rng, n_new=self.n_new)
        nb = NearestNeighbors(n_neighbors=self.k_enn + 1).fit(Xs).kneighbors(Xs, return_distance=False)[:, 1:]
        keep = np.all(ys[nb] == ys[:, None], axis=1)
        if keep[ys == 1].sum() < 2 or keep[ys == 0].sum() < 2:
            return Xs, ys
        return Xs[keep], ys[keep]



# ----------------------------------------------------------------------------
# additional baselines
# ----------------------------------------------------------------------------
class KMeansSMOTE:
    """k-means SMOTE (Douzas, Bacao and Last, 2018).
    1) k-means on the whole training set; 2) keep clusters whose minority share is at
    least the global minority share and that contain >= 2 minority points; 3) allocate the
    new points by cluster sparsity (mean minority distance^d / minority count, Eq. of the
    paper, computed in log space); 4) SMOTE inside each kept cluster.
    Falls back to SMOTE on the whole set when no cluster qualifies."""
    name = "KM-SMOTE"
    n_new = None

    def __init__(self, n_clusters=8, k=5):
        self.n_clusters, self.k = n_clusters, k

    def fit_resample(self, X, y, rng):
        from sklearn.cluster import KMeans
        N = n_needed(y, self.n_new)
        n, n_pos = len(X), int(y.sum())
        kc = int(max(2, min(self.n_clusters, n // 5)))
        lab = KMeans(n_clusters=kc, n_init=3, random_state=int(rng.integers(1e9))).fit_predict(X)
        share = n_pos / n
        keep, logsp = [], []
        for c in range(kc):
            m = lab == c
            mp = m & (y == 1)
            if mp.sum() < 2 or mp.sum() / max(m.sum(), 1) < share:
                continue
            P = X[mp]
            D = cdist(P, P)
            md = D[np.triu_indices(len(P), 1)].mean()
            md = max(md, 1e-12)
            keep.append(np.flatnonzero(mp))
            logsp.append(X.shape[1] * np.log(md) - np.log(len(P)))
        if not keep:
            return SMOTE(self.k).fit_resample(X, y, rng, n_new=self.n_new)
        logsp = np.array(logsp)
        w = np.exp(logsp - logsp.max()); w /= w.sum()
        counts = rng.multinomial(N, w)
        parts = []
        for idx, cnt in zip(keep, counts):
            if cnt == 0:
                continue
            P = X[idx]
            k = min(self.k, len(P) - 1)
            nbrs = NearestNeighbors(n_neighbors=k + 1).fit(P).kneighbors(P, return_distance=False)[:, 1:]
            base = rng.integers(0, len(P), size=cnt)
            col = rng.integers(0, k, size=cnt)
            parts.append(_interpolate(P, P, base, nbrs[base, col], rng))
        new = np.vstack(parts)
        return np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)])


class MWMOTE:
    """MWMOTE (Barua, Islam, Yao and Murase, 2014), steps 1-6 of the original algorithm
    with the published defaults k1=5, k2=3, k3=|S_min|/2, C_p=3, C_f(th)=5, CMAX=2."""
    name = "MWMOTE"
    n_new = None

    def __init__(self, k1=5, k2=3, cp=3.0, cf_th=5.0, cmax=2.0):
        self.k1, self.k2, self.cp, self.cf_th, self.cmax = k1, k2, cp, cf_th, cmax

    def fit_resample(self, X, y, rng):
        from scipy.cluster.hierarchy import linkage, fcluster
        N = n_needed(y, self.n_new)
        Xp, Xn = X[y == 1], X[y == 0]
        if len(Xp) < 2 or N <= 0:
            return X, y
        d = X.shape[1]
        k1 = min(self.k1, len(X) - 1)
        nb = NearestNeighbors(n_neighbors=k1 + 1).fit(X).kneighbors(Xp, return_distance=False)[:, 1:]
        noise = np.all(y[nb] == 0, axis=1)
        Pf = Xp[~noise] if (~noise).sum() >= 2 else Xp                     # step 1
        k2 = min(self.k2, len(Xn))
        bm = NearestNeighbors(n_neighbors=k2).fit(Xn).kneighbors(Pf, return_distance=False)
        Sbmaj = Xn[np.unique(bm.ravel())]                                    # step 2
        k3 = max(1, min(len(Xp), int(np.ceil(len(Xp) / 2))))
        im = NearestNeighbors(n_neighbors=k3).fit(Xp).kneighbors(Sbmaj, return_distance=False)
        imin_idx = np.unique(im.ravel())                                     # step 3
        pos = {j: t for t, j in enumerate(imin_idx)}
        Cf = np.zeros((len(Sbmaj), len(imin_idx)))
        for r in range(len(Sbmaj)):
            for j in im[r]:
                dn = np.linalg.norm(Sbmaj[r] - Xp[j]) / d
                z = 1.0 / max(dn, 1e-12)
                Cf[r, pos[j]] = min(z, self.cf_th) / self.cf_th * self.cmax
        Df = Cf / np.maximum(Cf.sum(1, keepdims=True), 1e-12)
        Sw = (Cf * Df).sum(0)                                                # step 4
        if Sw.sum() <= 0:
            return SMOTE().fit_resample(X, y, rng, n_new=self.n_new)
        Sp = Sw / Sw.sum()
        # step 5: average-linkage clustering of the minority class, threshold d_avg * C_p
        Dff = cdist(Pf, Pf); np.fill_diagonal(Dff, np.inf)
        davg = float(np.mean(Dff.min(1))) if len(Pf) > 1 else 1.0
        if len(Xp) > 1:
            clus = fcluster(linkage(Xp, method="average"), t=davg * self.cp, criterion="distance")
        else:
            clus = np.ones(1, int)
        # step 6
        pick = imin_idx[rng.choice(len(imin_idx), size=N, p=Sp)]
        new = np.empty((N, d))
        for t, i in enumerate(pick):
            members = np.flatnonzero(clus == clus[i])
            j = rng.choice(members)
            new[t] = Xp[i] + rng.uniform() * (Xp[j] - Xp[i])
        return np.vstack([X, new]), np.concatenate([y, np.ones(N, int)])


class CCR:
    """Combined Cleaning and Resampling (Koziarski and Wozniak, 2017).
    For every minority point a sphere grows until its energy budget is spent (expanding
    by dr with p majority points inside costs dr*(p+1)); majority points inside the
    sphere are pushed to its surface; new points are drawn uniformly inside the spheres,
    in numbers proportional to 1/r."""
    name = "CCR"
    n_new = None

    def __init__(self, energy=0.25):
        self.energy = energy

    def fit_resample(self, X, y, rng):
        N = n_needed(y, self.n_new)
        Xp, Xn = X[y == 1], X[y == 0].copy()
        if len(Xp) < 1 or N <= 0:
            return X, y
        d = X.shape[1]
        D = cdist(Xp, Xn)
        radii = np.zeros(len(Xp))
        shift = np.zeros_like(Xn)
        for i in range(len(Xp)):
            order = np.argsort(D[i])
            e, r, p = self.energy, 0.0, 0
            for j in order:
                cost = (D[i, j] - r) * (p + 1)
                if e - cost > 0:
                    e -= cost; r = D[i, j]; p += 1
                else:
                    r += e / (p + 1); e = 0.0
                    break
            if e > 0:
                r += e / (p + 1)
            radii[i] = r
            inside = order[:p]
            for j in inside:
                dij = max(D[i, j], 1e-12)
                shift[j] += (r - dij) / dij * (Xn[j] - Xp[i])
        Xn = Xn + shift                                                       # cleaning
        w = 1.0 / np.maximum(radii, 1e-12); w /= w.sum()
        counts = np.floor(w * N).astype(int)
        rest = N - counts.sum()
        if rest > 0:
            np.add.at(counts, rng.choice(len(Xp), size=rest, p=w), 1)
        parts = []
        for i, c in enumerate(counts):
            if c == 0:
                continue
            v = rng.standard_normal((c, d)); v /= np.linalg.norm(v, axis=1, keepdims=True)
            rad = radii[i] * rng.uniform(0, 1, (c, 1)) ** (1.0 / d)
            parts.append(Xp[i] + v * rad)
        new = np.vstack(parts)
        Xo = np.vstack([Xp, Xn, new])
        yo = np.concatenate([np.ones(len(Xp), int), np.zeros(len(Xn), int), np.ones(len(new), int)])
        return Xo, yo
