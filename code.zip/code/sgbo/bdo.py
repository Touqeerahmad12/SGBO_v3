"""
BDO -- boundary-degree-based oversampling (Chen, Pedrycz and Yang, Applied Intelligence 2023),
implemented literally from the paper.

  1. boundary degree of every majority point: binary entropy of the minority share among its
     n+ nearest neighbours (Eq. 1);
  2. sigma rule: keep the majority points with degree > mean + std (Eqs. 2-3);
  3. for every kept point x: nearest minority point, associated set P_i (Eq. 5), weights
     exp(-distance) (Eq. 6) and the "fraudulent gradient" (Eq. 7); the point is moved in steps
     alpha * gradient until it is closer to every member of P_i than to its start (Algorithm 1);
  4. one Gaussian per local set {moved point} + P_i; n- - n+ draws from each Gaussian, N kept
     at random (Section 3.4).

Only two details differ from a naive transcription and neither changes the method:
  * the neighbours of a point never include the point itself (removed by index, so exact
    duplicates are handled correctly);
  * "draw N points from each of M Gaussians and keep N at random" is realised by the
    equivalent multivariate hypergeometric allocation, which avoids building an N*M-element
    permutation (identical distribution of the component counts, far less memory).
"""
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.neighbors import NearestNeighbors
from .common import split, binary_entropy, knn_excl_self
from .baselines import SMOTE


class BDO:
    name = "BDO"
    n_new = None

    def __init__(self, alpha=1e-3, t_max=1000, return_info=False):
        self.alpha, self.t_max, self.return_info = alpha, t_max, return_info

    def fit_resample(self, X, y, rng):
        Xp, Xn = split(X, y)
        n_pos, n_neg = len(Xp), len(Xn)
        N = n_neg - n_pos if self.n_new is None else int(self.n_new)
        if N <= 0 or n_pos < 2:
            out = (X, y)
            return (out + ({},)) if self.return_info else out
        # Eq. (1): boundary degree with k = n+ neighbours taken from all samples
        neg_idx = np.flatnonzero(y == 0)
        k = min(n_pos, len(X) - 1)
        nn = NearestNeighbors().fit(X)
        share = np.empty(len(Xn))
        for a in range(0, len(Xn), 1000):             # chunked: the n+ neighbours of all majority points would need O(n n+) memory
            _, nb = knn_excl_self(nn, Xn[a:a + 1000], k, neg_idx[a:a + 1000])
            share[a:a + 1000] = np.mean(y[nb] == 1, axis=1)
        IE = binary_entropy(share)
        # sigma rule, Eqs. (2)-(3)
        thr = IE.mean() + IE.std()
        sel = np.flatnonzero(IE > thr)
        if len(sel) == 0:
            out = SMOTE().fit_resample(X, y, rng, n_new=self.n_new)
            return (out + ({},)) if self.return_info else out
        XnB = Xn[sel]
        D = cdist(XnB, Xp)
        nearest = np.argmin(D, axis=1)
        dist = D[np.arange(len(sel)), nearest]
        Dpp = cdist(Xp[nearest], Xp)
        aided, local_sets = [], []
        for i in range(len(sel)):
            Pi = Xp[Dpp[i] <= dist[i] + 1e-12]          # Eq. (5)
            x0 = XnB[i]
            d_ij = np.linalg.norm(x0 - Pi, axis=1)        # Eq. (6)
            w = np.exp(-(d_ij - d_ij.min()))
            w = w / w.sum()
            grad = (w[:, None] * (Pi - x0)).sum(0)        # Eq. (7), uses x^nb_i as written
            xt = x0.copy()
            for _ in range(self.t_max):                   # Algorithm 1
                if np.all(np.linalg.norm(xt - Pi, axis=1) < np.linalg.norm(xt - x0)):
                    break
                xt = xt + self.alpha * grad
            aided.append(xt)
            local_sets.append(np.vstack([xt[None, :], Pi]))
        # Section 3.4: one Gaussian per local set, N draws each, N of the M*N draws kept at random
        M = len(local_sets)
        counts = rng.multivariate_hypergeometric([N] * M, N) if M > 1 else np.array([N])
        new = []
        for i, c in enumerate(counts):
            if c == 0:
                continue
            L = local_sets[i]
            mu = L.mean(0)
            C = np.cov(L, rowvar=False) if len(L) > 1 else np.zeros((X.shape[1], X.shape[1]))
            C = np.atleast_2d(C)
            new.append(rng.multivariate_normal(mu, C, size=c, check_valid="ignore", method="svd"))
        new = np.vstack(new)
        out = (np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)]))
        if self.return_info:
            return out + ({"seeds": XnB, "aided": np.array(aided), "new": new},)
        return out
