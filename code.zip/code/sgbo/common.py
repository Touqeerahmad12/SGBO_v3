"""Small numerical helpers shared by all samplers."""
import numpy as np


def split(X, y):
    """Return (minority, majority) rows; label 1 = minority."""
    return X[y == 1], X[y == 0]


def n_needed(y, n_new=None):
    """Number of synthetic points: ``n_new`` if given, otherwise the size of the gap n- - n+."""
    if n_new is not None:
        return int(n_new)
    return int(np.sum(y == 0) - np.sum(y == 1))


def interpolate(Xbase, Xnbr, base_idx, nbr_idx, rng, step=1.0):
    """SMOTE-type interpolation x + u (x' - x), u ~ U(0, step)."""
    gaps = rng.uniform(0, 1, size=(len(base_idx), 1)) * step
    return Xbase[base_idx] + gaps * (Xnbr[nbr_idx] - Xbase[base_idx])


def binary_entropy(p):
    """H2(p) = -p log2 p - (1-p) log2 (1-p), with 0 log 0 = 0 (vectorised)."""
    p = np.clip(p, 0.0, 1.0)
    out = np.zeros_like(p, dtype=float)
    m = (p > 0) & (p < 1)
    out[m] = -(p[m] * np.log2(p[m]) + (1 - p[m]) * np.log2(1 - p[m]))
    return out


def knn_excl_self(nn, Q, k, qidx):
    """k nearest neighbours (distances, indices) of the rows ``Q`` = X[qidx] among the data X
    on which ``nn`` was fitted, never returning the query point itself.

    The query is removed *by index*, so that exact duplicates of the query (distance 0) are kept
    as ordinary neighbours; dropping 'the first column' would instead leave the query in the
    neighbourhood whenever a duplicate happens to be listed first.
    """
    n_fit = nn.n_samples_fit_
    k = int(min(k, n_fit - 1))
    d, idx = nn.kneighbors(Q, n_neighbors=k + 1)
    is_self = idx == np.asarray(qidx)[:, None]
    is_self[~is_self.any(1), -1] = True            # self not listed (many ties): drop the farthest
    keep = ~is_self
    m = len(Q)
    return d[keep].reshape(m, k), idx[keep].reshape(m, k)
