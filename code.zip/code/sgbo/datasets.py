"""
Binary imbalanced tasks used in the study.

Real tasks are derived from the four data sets distributed with scikit-learn
(no download needed). Minority classes are optionally sub-sampled once with a
fixed seed to reach a target imbalance ratio (IR). Synthetic tasks come from
standard scikit-learn generators. Label 1 always denotes the minority class.

To run the same pipeline on KEEL files, put the .dat files in a folder and use
load_keel_folder(path).
"""
import os
import numpy as np
from sklearn import datasets as skd


def _subsample(X, y, ir, seed=0):
    if ir is None:
        return X, y
    rng = np.random.default_rng(seed)
    pos, neg = np.flatnonzero(y == 1), np.flatnonzero(y == 0)
    n_pos = max(12, int(round(len(neg) / ir)))
    if n_pos < len(pos):
        pos = rng.choice(pos, size=n_pos, replace=False)
    idx = np.sort(np.concatenate([pos, neg]))
    return X[idx], y[idx]


def _binary(X, target, pos_labels, neg_labels=None):
    m = np.ones(len(target), bool) if neg_labels is None else np.isin(target, list(pos_labels) + list(neg_labels))
    y = np.isin(target[m], pos_labels).astype(int)
    return X[m].astype(float), y


def real_tasks():
    bc = skd.load_breast_cancer(); wi = skd.load_wine(); ir_ = skd.load_iris()
    dg = skd.load_digits(); db = skd.load_diabetes()
    tasks = []
    Xb, yb = bc.data, (bc.target == 0).astype(int)        # malignant = minority
    tasks += [("bcancer", Xb, yb, None), ("bcancer-ir5", Xb, yb, 5),
              ("bcancer-ir10", Xb, yb, 10), ("bcancer-ir20", Xb, yb, 20)]
    tasks += [("wine-c1", *_binary(wi.data, wi.target, [0]), None),
              ("wine-c3", *_binary(wi.data, wi.target, [2]), None),
              ("wine-c2-ir8", *_binary(wi.data, wi.target, [1]), 8)]
    tasks += [("iris-vers", *_binary(ir_.data, ir_.target, [1]), None),
              ("iris-vers-ir7", *_binary(ir_.data, ir_.target, [1]), 7)]
    tasks += [("digits-0", *_binary(dg.data, dg.target, [0]), None),
              ("digits-8", *_binary(dg.data, dg.target, [8]), None),
              ("digits-3-ir20", *_binary(dg.data, dg.target, [3]), 20),
              ("digits-9-ir40", *_binary(dg.data, dg.target, [9]), 40),
              ("digits-8v3-ir10", *_binary(dg.data, dg.target, [8], [3]), 10)]
    t = db.target
    for q, nm in ((0.80, "diabetes-top20"), (0.90, "diabetes-top10"), (0.95, "diabetes-top5")):
        tasks.append((nm, db.data.astype(float), (t > np.quantile(t, q)).astype(int), None))
    out = []
    for nm, X, y, ir in tasks:
        X2, y2 = _subsample(X, y, ir)
        out.append((nm, X2, y2, "real"))
    return out


def synthetic_tasks():
    out = []
    X, y = skd.make_moons(n_samples=2000, noise=0.30, random_state=1)
    out.append(("syn-moons-ir10", *_subsample(X, y, 10, seed=1), "synthetic"))
    X, y = two_cluster(n_neg=800, n_pos=40, seed=2)
    out.append(("syn-2cluster-ir20", X, y, "synthetic"))
    X, y = skd.make_classification(n_samples=1000, n_features=10, n_informative=4, n_redundant=2,
                                   class_sep=0.6, weights=[0.91], random_state=3)
    out.append(("syn-overlap-ir10", X, y, "synthetic"))
    X, y = skd.make_classification(n_samples=1500, n_features=40, n_informative=8, n_redundant=4,
                                   weights=[0.94], random_state=4)
    out.append(("syn-hd-ir15", X, y, "synthetic"))
    X, y = skd.make_classification(n_samples=1000, n_features=8, n_informative=5, flip_y=0.05,
                                   weights=[0.91], random_state=5)
    out.append(("syn-noise-ir10", X, y, "synthetic"))
    X, y = skd.make_classification(n_samples=3000, n_features=12, n_informative=6,
                                   n_clusters_per_class=3, weights=[0.97], class_sep=1.0, random_state=6)
    out.append(("syn-multi-ir30", X, y, "synthetic"))
    return out


def two_cluster(n_neg=800, n_pos=40, seed=0):
    """Majority blob with two separated minority clusters on its rim (cf. Fig. 3 of BDO)."""
    rng = np.random.default_rng(seed)
    Xn = rng.normal(0, 1.0, size=(n_neg, 2))
    c1, c2 = np.array([1.6, 1.6]), np.array([1.9, -1.4])
    h = n_pos // 2
    Xp = np.vstack([rng.normal(c1, 0.35, size=(h, 2)), rng.normal(c2, 0.35, size=(n_pos - h, 2))])
    X = np.vstack([Xn, Xp]); y = np.concatenate([np.zeros(n_neg, int), np.ones(n_pos, int)])
    return X, y


def all_tasks():
    return real_tasks() + synthetic_tasks()


def load_keel_folder(path):
    """Read every KEEL .dat file in `path`; the minority class becomes label 1."""
    out = []
    for f in sorted(os.listdir(path)):
        if not f.endswith(".dat"):
            continue
        rows = []
        with open(os.path.join(path, f)) as fh:
            for line in fh:
                if line.startswith("@") or not line.strip():
                    continue
                rows.append([v.strip() for v in line.split(",")])
        lab = np.array([r[-1] for r in rows])
        vals, cnt = np.unique(lab, return_counts=True)
        y = (lab == vals[np.argmin(cnt)]).astype(int)
        X = np.array([[float(v) for v in r[:-1]] for r in rows])
        out.append((f[:-4], X, y, "keel"))
    return out


if __name__ == "__main__":
    for nm, X, y, src in all_tasks():
        print(f"{nm:20s} n={len(y):5d} d={X.shape[1]:3d} n+={y.sum():4d} IR={(len(y)-y.sum())/y.sum():6.2f} {src}")


# ----------------------------------------------------------------------------
# Independent real data sets (KEEL imbalanced / standard versions, UCI Statlog Satimage)
# ----------------------------------------------------------------------------
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "data")

# name, file, source group, minority definition, primary task of its source?
KEEL_TASKS = [
    ("ionosphere", "ionosphere.dat", "Ionosphere", "bad radar returns (b) vs good (g)", True),
    ("pima", "pima.dat", "Pima", "diabetes positive vs negative", True),
    ("haberman", "haberman.dat", "Haberman", "death within 5 years vs survival", True),
    ("yeast1", "yeast1.dat", "Yeast", "NUC vs rest", False),
    ("yeast3", "yeast3.dat", "Yeast", "ME3 vs rest", True),
    ("yeast4", "yeast4.dat", "Yeast", "ME2 vs rest", False),
    ("yeast6", "yeast6.dat", "Yeast", "EXC vs rest", False),
    ("vehicle0", "vehicle0.dat", "Vehicle", "van vs rest", True),
    ("ecoli1", "ecoli1.dat", "Ecoli", "im vs rest", False),
    ("ecoli3", "ecoli3.dat", "Ecoli", "imU vs rest", True),
    ("ecoli4", "ecoli4.dat", "Ecoli", "om vs rest", False),
    ("new-thyroid1", "new-thyroid1.dat", "New-thyroid", "hyperthyroid vs rest", True),
    ("segment0", "segment0.dat", "Segment", "KEEL class 0 vs rest", True),
    ("glass6", "glass6.dat", "Glass", "headlamps (type 7) vs rest", True),
    ("vowel0", "vowel0.dat", "Vowel", "vowel 0 vs rest", True),
    ("page-blocks0", "page-blocks0.dat", "Page-blocks", "non-text blocks vs text", True),
    ("shuttle-c0-vs-c4", "shuttle-c0-vs-c4.dat", "Shuttle", "KEEL class 0 vs class 4", True),
    ("abalone9-18", "abalone9-18.dat", "Abalone", "18 rings vs 9 rings", True),
    ("winequality-red-4", "winequality-red-4.dat", "Wine quality (red)", "quality 4 vs rest", True),
]

# name, file, source, minority definition, drop the first column (record identifier)?
PUBLIC_TASKS = [
    ("mammography", "mammography.csv", "Mammography", "microcalcification vs no calcification", False),
    ("oil-spill", "oil-spill.csv", "Oil spill", "oil slick vs look-alike (identifier column dropped)", True),
]

SKLEARN_SOURCE = {"bcancer": "Breast cancer (WDBC)", "wine": "Wine", "iris": "Iris",
                  "digits": "Digits", "diabetes": "Diabetes"}
SKLEARN_PRIMARY = {"bcancer-ir10", "wine-c2-ir8", "iris-vers-ir7", "digits-8", "diabetes-top10"}
SKLEARN_DEF = {"bcancer": "malignant vs benign", "wine-c1": "cultivar 1 vs rest", "wine-c3": "cultivar 3 vs rest",
               "wine-c2": "cultivar 2 vs rest", "iris-vers": "versicolor vs rest", "digits-0": "digit 0 vs rest",
               "digits-8": "digit 8 vs rest", "digits-3": "digit 3 vs rest", "digits-9": "digit 9 vs rest",
               "digits-8v3": "digit 8 vs digit 3", "diabetes-top20": "progression above 80% quantile",
               "diabetes-top10": "progression above 90% quantile", "diabetes-top5": "progression above 95% quantile"}
SYN_DEF = {"syn-moons-ir10": "two moons, noise 0.3", "syn-2cluster-ir20": "two minority clusters on a majority rim",
           "syn-overlap-ir10": "strong overlap (class_sep 0.6)", "syn-hd-ir15": "40 features, 8 informative",
           "syn-noise-ir10": "5% label noise", "syn-multi-ir30": "3 clusters per class"}


def read_keel(path):
    """Parse a KEEL .dat file; nominal input attributes are one-hot encoded.
    The minority class becomes label 1."""
    attrs, rows = [], []
    with open(path) as fh:
        for line in fh:
            s = line.strip()
            if not s:
                continue
            if s.lower().startswith("@attribute"):
                body = s[len("@attribute"):].strip()
                name = body.split()[0]
                rest = body[len(name):].strip()
                attrs.append((name, [v.strip() for v in rest[rest.index("{") + 1:rest.index("}")].split(",")]
                              if rest.startswith("{") else None))
            elif s.startswith("@"):
                continue
            else:
                rows.append([v.strip() for v in s.split(",")])
    lab = np.array([r[-1] for r in rows])
    vals, cnt = np.unique(lab, return_counts=True)
    y = (lab == vals[np.argmin(cnt)]).astype(int)
    cols = []
    for j, (name, cats) in enumerate(attrs[:-1]):
        col = [r[j] for r in rows]
        if cats is None:
            cols.append(np.array(col, float)[:, None])
        else:
            cols.append(np.array([[c == v for v in cats] for c in col], float))
    return np.hstack(cols), y


def read_csv_task(fname, drop_first=False):
    """Numeric CSV whose last column is the class label; the rarer class becomes label 1."""
    import pandas as pd
    d = pd.read_csv(os.path.join(DATA_DIR, fname), header=None)
    lab = d.iloc[:, -1].astype(str).str.strip("'").values
    vals, cnt = np.unique(lab, return_counts=True)
    y = (lab == vals[np.argmin(cnt)]).astype(int)
    X = d.iloc[:, (1 if drop_first else 0):-1].values.astype(float)
    return X, y


def read_satimage():
    tr = np.loadtxt(os.path.join(DATA_DIR, "sat.trn.txt")); te = np.loadtxt(os.path.join(DATA_DIR, "sat.tst.txt"))
    A = np.vstack([tr, te]); X, c = A[:, :-1], A[:, -1].astype(int)
    y = (c == 4).astype(int)                    # damp grey soil vs rest
    split = (np.arange(len(tr)), np.arange(len(tr), len(A)))
    return X, y, split


def task_registry(include_new=True):
    """All tasks as dictionaries with the metadata used in the analysis."""
    reg = []
    for nm, X, y, kind in real_tasks():
        base = nm.split("-")[0]
        key = nm if nm in SKLEARN_DEF else "-".join(nm.split("-")[:2]) if "-".join(nm.split("-")[:2]) in SKLEARN_DEF else base
        reg.append(dict(name=nm, X=X, y=y, kind="real (scikit-learn)", source=SKLEARN_SOURCE[base],
                        primary=nm in SKLEARN_PRIMARY, definition=SKLEARN_DEF.get(key, ""), split=None))
    for nm, X, y, kind in synthetic_tasks():
        reg.append(dict(name=nm, X=X, y=y, kind="synthetic", source=nm, primary=True,
                        definition=SYN_DEF[nm], split=None))
    if include_new:
        for nm, f, src, dfn, prim in KEEL_TASKS:
            X, y = read_keel(os.path.join(DATA_DIR, f))
            reg.append(dict(name=nm, X=X, y=y, kind="real (KEEL)", source=src, primary=prim, definition=dfn, split=None))
        for nm, f, src, dfn, drop in PUBLIC_TASKS:
            X, y = read_csv_task(f, drop_first=drop)
            reg.append(dict(name=nm, X=X, y=y, kind="real (public CSV)", source=src, primary=True, definition=dfn, split=None))
        X, y, split = read_satimage()
        reg.append(dict(name="satimage", X=X, y=y, kind="real (UCI, fixed split)", source="Satimage", primary=True,
                        definition="damp grey soil vs rest", split=split))
    return reg
