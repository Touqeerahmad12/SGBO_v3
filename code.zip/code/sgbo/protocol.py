"""
Evaluation protocol shared by all experiments.

All steps are carried out inside the training part of every split:
  1. standardisation fitted on the training part only;
  2. resampling of the training part only;
  3. classifier with fixed hyperparameters (no tuning, except in run_tuning.py);
  4. evaluation on the untouched test part.
Splits: StratifiedKFold(5, shuffle=True, random_state=rep) for repetition ``rep``; tasks with an
official train/test split use it in every repetition.  The assignments are written to
results/splits/<task>.csv.  The random generator of the sampler for fold (rep, fold) is
default_rng(1000*rep + 10*fold + 7), identical for every method.
"""
import os, time
import numpy as np, pandas as pd
from joblib import Parallel, delayed
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (f1_score, matthews_corrcoef, average_precision_score,
                             roc_auc_score, confusion_matrix)
from .registry import make_sampler, METHODS
from .sgbo import SGBO

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "results")


def classifiers(seed):
    """Fixed hyperparameters, identical for every resampling method."""
    return {
        "RF": RandomForestClassifier(n_estimators=100, random_state=seed, n_jobs=1),
        "SVM": SVC(kernel="rbf", gamma="scale", C=1.0, cache_size=1000, random_state=seed),
        "kNN": KNeighborsClassifier(n_neighbors=5),
        "LR": LogisticRegression(max_iter=2000),
    }


def scores(clf, Xte, yte):
    """G-mean, F1, AUC-PR (average precision), ROC-AUC, MCC, sensitivity (tpr), specificity (tnr),
    precision and false-positive rate at the classifier's default decision threshold."""
    pred = clf.predict(Xte)
    s = clf.decision_function(Xte) if hasattr(clf, "decision_function") else clf.predict_proba(Xte)[:, 1]
    tn, fp, fn, tp = confusion_matrix(yte, pred, labels=[0, 1]).ravel()
    tpr = tp / (tp + fn) if tp + fn else 0.0
    tnr = tn / (tn + fp) if tn + fp else 0.0
    prec = tp / (tp + fp) if tp + fp else 0.0
    return dict(gmean=np.sqrt(tpr * tnr), f1=f1_score(yte, pred, zero_division=0),
                aucpr=average_precision_score(yte, s), auc=roc_auc_score(yte, s),
                mcc=matthews_corrcoef(yte, pred), tpr=tpr, tnr=tnr, prec=prec,
                fpr=1.0 - tnr, tp=int(tp), fp=int(fp), fn=int(fn), tn=int(tn))


def splits_for(task, reps):
    X, y = task["X"], task["y"]
    if task.get("split") is not None:
        tr, te = task["split"]
        return [(rep, 0, tr, te) for rep in range(reps)]
    out = []
    for rep in range(reps):
        skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=rep)
        for fold, (tr, te) in enumerate(skf.split(X, y)):
            out.append((rep, fold, tr, te))
    return out


def save_splits(task, sp, folder):
    os.makedirs(folder, exist_ok=True)
    n = len(task["y"]); cols = {}
    for rep, fold, tr, te in sp:
        c = cols.setdefault(f"rep{rep}", np.full(n, -1))
        c[te] = fold
    pd.DataFrame(cols).to_csv(os.path.join(folder, f"{task['name']}.csv"), index_label="row")


def fold_rng(rep, fold):
    return np.random.default_rng(1000 * rep + 10 * fold + 7)


def run_fold(task, rep, fold, tr, te, methods, extra=None, clf_names=None):
    """Resample the training part with every method and evaluate each classifier.
    ``extra`` is a dict name -> sampler for additional variants (ablation, sensitivity)."""
    X, y = task["X"], task["y"]
    rows = []
    t0 = time.perf_counter()
    sc = StandardScaler().fit(X[tr])
    Xtr, Xte = sc.transform(X[tr]), sc.transform(X[te])
    t_prep = time.perf_counter() - t0
    ytr, yte = y[tr], y[te]
    samplers = {m: (None if m == "None" else make_sampler(m)) for m in methods}
    if extra:
        samplers.update({k: (v() if callable(v) and not hasattr(v, "fit_resample") else v) for k, v in extra.items()})
    for m, smp in samplers.items():
        rng = fold_rng(rep, fold)
        t0 = time.perf_counter()
        if smp is None:
            Xr, yr = Xtr, ytr
        else:
            Xr, yr = smp.fit_resample(Xtr, ytr, rng)[:2]
        t_res = time.perf_counter() - t0
        diag = {}
        if isinstance(smp, SGBO) and hasattr(smp, "diag_"):
            diag = {f"diag_{k}": v for k, v in smp.diag_.items()}
            diag.update({f"tm_{k}": v for k, v in smp.timing_.items()})
            diag.update(k_used=smp.k_ if hasattr(smp, "k_") else np.nan, h_used=getattr(smp, "h_", np.nan),
                        theta_used=getattr(smp, "theta_", np.nan))
        for cn, clf in classifiers(rep).items():
            if clf_names and cn not in clf_names:
                continue
            t0 = time.perf_counter()
            clf.fit(Xr, yr)
            t_fit = time.perf_counter() - t0
            r = scores(clf, Xte, yte)
            r.update(dataset=task["name"], source=task["source"], rep=rep, fold=fold, method=m, clf=cn,
                     t_prep=t_prep, t_resample=t_res, t_fit=t_fit, n_after=len(yr), **diag)
            rows.append(r)
    return rows


def run(tasks, methods, reps, out, n_jobs=2, extra_fn=None, clf_names=None, save=True, verbose=5):
    jobs = []
    for t in tasks:
        sp = splits_for(t, reps)
        if save:
            save_splits(t, sp, os.path.join(RES, "splits"))
        for rep, fold, tr, te in sp:
            jobs.append((t, rep, fold, tr, te))
    jobs.sort(key=lambda j: -len(j[0]["y"]))      # large tasks first so that both workers finish together
    t0 = time.time()
    res = Parallel(n_jobs=n_jobs, verbose=verbose)(
        delayed(run_fold)(*j, methods, extra_fn() if extra_fn else None, clf_names) for j in jobs)
    df = pd.DataFrame([r for rr in res for r in rr])
    df.to_csv(out, index=False)
    print(f"saved {out} rows={len(df)} in {time.time()-t0:.0f}s", flush=True)
    return df
