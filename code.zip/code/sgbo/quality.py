"""
Quality of synthetic minority samples (Section 6.5 of the paper).

All quantities are computed in the standardised feature space used by the samplers.  ``Z`` are
the synthetic points, ``Xtr, ytr`` the (training-part) data the sampler saw, and ``Xho`` an
optional set of *held-out* minority points (the minority part of the test fold), which serves as
a reference for new real observations of the minority class.

Fidelity / coverage
  prec, rec         improved precision and recall of Kynkaanniemi et al. (2019): the share of
                    synthetic points inside the union of k-NN balls (k = 3) of the real training
                    minority points, and the share of real points inside the k-NN balls of the
                    synthetic points.
  nn_ratio          median distance synthetic -> nearest training-minority point, divided by the
                    same quantity for held-out minority points (1 = same spacing as new real data;
                    <1 = synthetic points hug the training points, >1 = they are pushed outwards).
  dup_frac          share of synthetic points that coincide with a training minority point.
  logdens_diff      mean log Gaussian-KDE density (training minority) at the synthetic points minus
                    the same at held-out minority points.
Distributional similarity
  mmd_ho, edist_ho  unbiased squared MMD (RBF, median heuristic) and energy distance between the
                    synthetic points and the held-out minority points.
Class-boundary proximity and intrusion (measured with the original training data)
  share_mean        mean minority share among the k = 5 nearest training points of a synthetic point;
  deep_frac         share of synthetic points with no minority point among these 5 neighbours
                    (deep inside the majority region);
  bnd_frac          share with minority H2(share) >= 0.9, i.e. 2 or 3 of the 5 neighbours are minority (boundary region);
  b_mean            mean H2 of the minority share.
  maj_ratio         median distance to the nearest majority point relative to held-out minority.
The same boundary quantities are returned for the held-out and the training minority points
(suffix _ho, _tr; the training points exclude themselves) as reference levels.
"""
import numpy as np
from scipy.spatial.distance import cdist
from scipy.special import logsumexp
from sklearn.neighbors import NearestNeighbors
from .common import binary_entropy


def _kth_radius(A, k):
    k = min(k, len(A) - 1)
    return NearestNeighbors(n_neighbors=k + 1).fit(A).kneighbors(A)[0][:, -1]


def improved_pr(real, fake, k=3):
    """Improved precision and recall (Kynkaanniemi et al., 2019)."""
    rr, rf = _kth_radius(real, k), _kth_radius(fake, k)
    D = cdist(fake, real)
    prec = float(np.mean((D <= rr[None, :]).any(1)))
    rec = float(np.mean((D.T <= rf[None, :]).any(1)))
    return prec, rec


def _median_bandwidth(A, B, rng, m=400):
    P = np.vstack([A, B])
    if len(P) > m:
        P = P[rng.choice(len(P), m, replace=False)]
    d = cdist(P, P)[np.triu_indices(len(P), 1)]
    return max(float(np.median(d)), 1e-9)


def mmd2_unbiased(A, B, bw):
    """Unbiased estimate of the squared MMD with Gaussian kernel exp(-|x-y|^2 / (2 bw^2))."""
    g = 1.0 / (2 * bw ** 2)
    Kaa, Kbb, Kab = np.exp(-g * cdist(A, A, "sqeuclidean")), np.exp(-g * cdist(B, B, "sqeuclidean")), np.exp(-g * cdist(A, B, "sqeuclidean"))
    m, n = len(A), len(B)
    return float((Kaa.sum() - np.trace(Kaa)) / (m * (m - 1)) + (Kbb.sum() - np.trace(Kbb)) / (n * (n - 1)) - 2 * Kab.mean())


def energy_distance(A, B):
    m, n = len(A), len(B)
    dab = cdist(A, B).mean()
    daa = cdist(A, A).sum() / (m * (m - 1))
    dbb = cdist(B, B).sum() / (n * (n - 1))
    return float(2 * dab - daa - dbb)


def log_kde(Q, P, h):
    """log of the Gaussian KDE (bandwidth h) of P at the rows of Q (up to the common constant)."""
    D2 = cdist(Q, P, "sqeuclidean") / (2 * h * h)
    return logsumexp(-D2, axis=1) - np.log(len(P))


def minority_share(Xtr, ytr, Q, k=5, self_idx=None):
    """Share of minority points among the k nearest training points of the rows of Q."""
    nn = NearestNeighbors().fit(Xtr)
    if self_idx is None:
        idx = nn.kneighbors(Q, n_neighbors=k, return_distance=False)
    else:
        from .common import knn_excl_self
        idx = knn_excl_self(nn, Q, k, self_idx)[1]
    return ytr[idx].mean(1)


def sample_quality(Xtr, ytr, Z, Xho=None, rng=None, max_pts=2000, k=5):
    rng = rng or np.random.default_rng(0)
    if len(Z) > max_pts:
        Z = Z[rng.choice(len(Z), max_pts, replace=False)]
    P, Nm = Xtr[ytr == 1], Xtr[ytr == 0]
    out = {}
    has_ho = Xho is not None and len(Xho) >= 3
    nnP = NearestNeighbors(n_neighbors=1).fit(P)
    nnN = NearestNeighbors(n_neighbors=1).fit(Nm)
    dZP = nnP.kneighbors(Z)[0][:, 0]
    dZN = nnN.kneighbors(Z)[0][:, 0]
    out["nn_min_med"] = float(np.median(dZP))
    out["dup_frac"] = float(np.mean(dZP < 1e-8))
    out["prec"], out["rec"] = improved_pr(P, Z, 3)
    out["sd_per_dim"] = float(np.mean(Z.std(0)) / max(np.mean(P.std(0)), 1e-12))     # spread relative to real minority
    h = max(float(np.median(_kth_radius(P, 5))), 1e-6)
    sh_z = minority_share(Xtr, ytr, Z, k)
    out.update(share_mean=float(sh_z.mean()), deep_frac=float(np.mean(sh_z == 0)),
               bnd_frac=float(np.mean(binary_entropy(sh_z) >= 0.9)), b_mean=float(binary_entropy(sh_z).mean()),
               maj_med=float(np.median(dZN)))
    sh_tr = minority_share(Xtr, ytr, P, k, self_idx=np.flatnonzero(ytr == 1))
    out.update(share_mean_tr=float(sh_tr.mean()), deep_frac_tr=float(np.mean(sh_tr == 0)),
               bnd_frac_tr=float(np.mean(binary_entropy(sh_tr) >= 0.9)), b_mean_tr=float(binary_entropy(sh_tr).mean()))
    out["maj_med_tr"] = float(np.median(nnN.kneighbors(P)[0][:, 0]))
    if has_ho:
        dHP = nnP.kneighbors(Xho)[0][:, 0]
        out["nn_ratio"] = float(np.median(dZP) / max(np.median(dHP), 1e-12))
        sh_h = minority_share(Xtr, ytr, Xho, k)
        out.update(share_mean_ho=float(sh_h.mean()), deep_frac_ho=float(np.mean(sh_h == 0)),
                   bnd_frac_ho=float(np.mean(binary_entropy(sh_h) >= 0.9)), b_mean_ho=float(binary_entropy(sh_h).mean()))
        out["maj_ratio"] = float(np.median(dZN) / max(np.median(nnN.kneighbors(Xho)[0][:, 0]), 1e-12))
        out["logdens_diff"] = float(log_kde(Z, P, h).mean() - log_kde(Xho, P, h).mean())
        if len(Xho) >= 5:
            bw = _median_bandwidth(Z, Xho, rng)
            out["mmd_ho"] = mmd2_unbiased(Z, Xho, bw)
            out["edist_ho"] = energy_distance(Z, Xho)
    else:
        for key in ("nn_ratio", "maj_ratio", "logdens_diff", "mmd_ho", "edist_ho", "share_mean_ho", "deep_frac_ho", "bnd_frac_ho", "b_mean_ho"):
            out[key] = np.nan
    return out
