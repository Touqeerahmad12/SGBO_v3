"""Name -> sampler factory and the list of methods compared in the benchmark."""
from .baselines import ROS, SMOTE, BorderlineSMOTE, ADASYN, SVMSMOTE, SMOTEENN, KMeansSMOTE, MWMOTE, CCR
from .bdo import BDO
from .sgbo import SGBO

METHODS = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN",
           "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]

_TABLE = {"ROS": ROS, "SMOTE": SMOTE, "B-SMOTE": BorderlineSMOTE, "ADASYN": ADASYN,
          "SVM-SMOTE": SVMSMOTE, "SMOTE-ENN": SMOTEENN, "KM-SMOTE": KMeansSMOTE,
          "MWMOTE": MWMOTE, "CCR": CCR, "BDO": BDO, "SGBO": SGBO}


def make_sampler(name, **kw):
    """Instantiate a sampler by its short name; ``None`` (no resampling) is not a sampler."""
    return _TABLE[name](**kw)
