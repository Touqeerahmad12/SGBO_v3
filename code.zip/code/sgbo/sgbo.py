"""
SGBO -- score-guided boundary oversampling with adaptive entropy.

Stage 1  adaptive, distance-weighted boundary score  b(x) = H2(eta_hat(x)),  soft seed selection
Stage 2  tempered Langevin / mean-shift transport of the seeds along the score of a Gaussian
         kernel density estimate of the minority class
Stage 3  local Gaussian generation with Ledoit-Wolf shrinkage and a posterior acceptance test

Default values reproduce the method as described in the paper.  Every keyword below that
differs from its default switches one component off or changes one parameter; they are used by
the ablation and sensitivity studies (Sections 6.3-6.4) and have no effect unless set.

Component switches
  adaptive_k   False -> k = n+ (the BDO neighbourhood);  k_fixed=int -> constant k
  weighted     False -> uniform neighbour weights in eta_hat (default: exp(-(d_j/d_k)^2))
  seed_mode    "score"   seeds drawn from {b>0} with probability proportional to b  (default)
               "uniform" seeds drawn uniformly from {b>0}
               "sigma"   BDO's hard rule  b > mean + std, uniform draws
  alloc        "score" -> new points allocated to anchors in proportion to the seed score (default)
               "uniform" -> equal shares
  movement     "langevin" (default) | "bdo" (one BDO straight-line step) | "none" (anchors = seeds)
  tau          Langevin temperature; 0 -> deterministic mean-shift ascent
  shrink       False -> plain sample covariance (ddof=1) of the local set
  filter       False -> no posterior acceptance test
(soft=False is kept as shorthand for seed_mode="sigma", alloc="uniform".)

Parameters
  k0, eta, tau, T, k_gen, rho_min        see Algorithm 1
  k_scale      k = min(n+, max(k0, ceil(k_scale * sqrt(n)))); the paper uses k_scale = 1
  h_mult       multiplier of the KDE bandwidth h (default 1)
  k_h          neighbour rank used for h (default 5)
  theta_q      quantile of eta_hat on the minority class that defines the acceptance level
  theta_cap    upper bound of the acceptance level (default 1/2);  theta=<float> fixes it
  rho_fixed    fixed shrinkage intensity instead of the Ledoit-Wolf value
  rounds       maximum number of acceptance rounds (default 5)
  n_new        number of synthetic points (default: n- - n+, i.e. balance)
  record       True -> keep rejected candidates, covariance diagnostics and chain paths

After ``fit_resample``: ``diag_`` (counts of exceptional events, acceptance statistics),
``timing_`` (seconds per stage), ``seeds_``, ``anchors_``, ``steps_``, ``new_``, ``h_``,
``theta_``, ``k_`` and, with ``record=True``, ``paths_``, ``cov_info_``, ``rejected_``.
"""
import time
import numpy as np
from scipy.spatial.distance import cdist
from sklearn.neighbors import NearestNeighbors
from sklearn.covariance import ledoit_wolf
from .common import split, binary_entropy, knn_excl_self


class SGBO:
    name = "SGBO"
    RHO_MIN = 0.01          # default lower bound on the shrinkage intensity (Proposition 3)

    def __init__(self, eta=0.5, tau=0.1, T=30, k0=5, k_gen=5, adaptive_k=True, soft=True,
                 movement="langevin", shrink=True, filter=True, return_info=False,
                 weighted=True, seed_mode=None, alloc=None, h_mult=1.0, k_h=5, theta_q=0.25,
                 theta_cap=0.5, theta=None, rho_min=None, rho_fixed=None, rounds=5, n_new=None,
                 k_fixed=None, k_scale=1.0, record=False):
        self.eta, self.tau, self.T, self.k0, self.k_gen = eta, tau, T, k0, k_gen
        self.adaptive_k, self.soft, self.movement = adaptive_k, soft, movement
        self.shrink, self.filter, self.return_info = shrink, filter, return_info
        self.weighted, self.h_mult, self.k_h = weighted, h_mult, k_h
        self.seed_mode = seed_mode or ("score" if soft else "sigma")
        self.alloc = alloc or ("score" if soft else "uniform")
        self.theta_q, self.theta_cap, self.theta_fixed = theta_q, theta_cap, theta
        self.rho_min = self.RHO_MIN if rho_min is None else rho_min
        self.rho_fixed, self.rounds, self.n_new, self.k_fixed, self.record = rho_fixed, rounds, n_new, k_fixed, record
        self.k_scale = k_scale
        assert self.seed_mode in ("score", "uniform", "sigma") and self.alloc in ("score", "uniform")
        assert movement in ("langevin", "bdo", "none")

    # ---- Stage 1 -----------------------------------------------------------
    def _k(self, n, n_pos):
        if self.k_fixed is not None:
            return int(max(1, min(self.k_fixed, n - 1)))
        if not self.adaptive_k:
            return max(1, min(n_pos, n - 1))
        return int(max(1, min(n_pos, n - 1, max(self.k0, np.ceil(self.k_scale * np.sqrt(n))))))

    def _weights(self, d):
        if not self.weighted:
            return np.ones_like(d)
        dk = np.maximum(d[:, -1:], 1e-12)
        return np.exp(-(d / dk) ** 2)

    def _eta_from(self, d, idx):
        w = self._weights(d)
        return (w * (self.y_[idx] == 1)).sum(1) / w.sum(1)

    def posterior(self, Q):
        """Distance-weighted kNN posterior eta_hat at arbitrary query points."""
        d, idx = self.nn_.kneighbors(Q, n_neighbors=self.k_)
        return self._eta_from(d, idx)

    def posterior_train(self, X):
        """eta_hat at the training points, each excluding itself from its own neighbourhood."""
        d, idx = knn_excl_self(self.nn_, X, self.k_, np.arange(len(X)))
        return self._eta_from(d, idx)

    # ---- Stage 2 -----------------------------------------------------------
    def _mean_shift(self, Z):
        D2 = cdist(Z, self.Xp_, "sqeuclidean") / (2 * self.h_ ** 2)
        D2 -= D2.min(1, keepdims=True)
        W = np.exp(-D2)
        W /= W.sum(1, keepdims=True)
        return W @ self.Xp_

    def _move(self, S, rng):
        Z = S.copy()
        if self.movement == "none":
            return Z, np.zeros(len(Z), int)
        if self.movement == "bdo":
            out = []
            for x0 in Z:
                ball_c = self.Xp_[np.argmin(np.linalg.norm(self.Xp_ - x0, axis=1))]
                r = np.linalg.norm(ball_c - x0)
                Pi = self.Xp_[np.linalg.norm(self.Xp_ - ball_c, axis=1) <= r + 1e-12]
                dij = np.linalg.norm(Pi - x0, axis=1)
                w = np.exp(-(dij - dij.min())); w /= w.sum()
                g = (w[:, None] * (Pi - x0)).sum(0)
                out.append(x0 + g)   # alpha * t_max = 1 in the original setting
            return np.array(out), np.full(len(Z), 1000)
        active = np.ones(len(Z), bool)
        steps = np.zeros(len(Z), int)
        sd = self.h_ * np.sqrt(2 * self.eta * self.tau)
        if self.record:
            self.paths_ = [Z.copy()]
        for t in range(self.T):
            if not active.any():
                break
            idx = np.flatnonzero(active)
            Za = Z[idx]
            Za = Za + self.eta * (self._mean_shift(Za) - Za) + sd * rng.standard_normal(Za.shape)
            Z[idx] = Za
            steps[idx] += 1
            done = self.posterior(Za) >= self.theta_
            active[idx[done]] = False
            if self.record:
                self.paths_.append(Z.copy())
        return Z, steps

    # ---- Stage 3 -----------------------------------------------------------
    def _cov(self, L):
        """Local covariance with the safeguards of Section 3.3: a single point or a zero-trace
        set gives h^2 I; the shrinkage intensity is Ledoit-Wolf, clipped to [rho_min, 1]
        (or fixed to rho_fixed)."""
        d = L.shape[1]
        info = dict(m=len(L), rho=np.nan, kind="")
        if len(L) < 2:
            self.diag_["cov_single"] += 1
            C = (self.h_ ** 2) * np.eye(d); info["kind"] = "single"
        elif self.shrink:
            S = np.atleast_2d(np.cov(L, rowvar=False, bias=True))
            nu = np.trace(S) / d
            if nu <= 1e-12:
                self.diag_["cov_zero_trace"] += 1
                C = (self.h_ ** 2) * np.eye(d); info["kind"] = "zero_trace"
            elif self.rho_fixed is not None:
                rho = float(self.rho_fixed)
                C = (1 - rho) * S + rho * nu * np.eye(d); info.update(rho=rho, kind="fixed")
            else:
                C, rho = ledoit_wolf(L)
                if rho < self.rho_min:
                    self.diag_["rho_clipped"] += 1
                    rho = self.rho_min
                    C = (1 - rho) * S + rho * nu * np.eye(d)
                info.update(rho=float(rho), kind="lw")
        else:
            C = np.atleast_2d(np.cov(L, rowvar=False)); info["kind"] = "sample"
        if self.record:
            ev = np.linalg.eigvalsh((C + C.T) / 2)
            info["lam_min"], info["lam_max"] = float(ev[0]), float(ev[-1])
            info["cond"] = float(ev[-1] / ev[0]) if ev[0] > 0 else np.inf
            info["rank"] = int(np.sum(ev > 1e-10 * max(ev[-1], 1e-300)))
            self.cov_info_.append(info)
        return C

    def fit_resample(self, X, y, rng):
        t0 = time.perf_counter()
        Xp, Xn = split(X, y)
        n, n_pos = len(X), len(Xp)
        N = (len(Xn) - n_pos) if self.n_new is None else int(self.n_new)
        self.diag_ = dict(too_few_minority=0, no_candidates=0, chains=0, chains_unfinished=0,
                          cov_single=0, cov_zero_trace=0, rho_clipped=0, n_cand=0, n_acc=0, n_fill=0,
                          rounds_used=0)
        self.timing_ = dict(stage1=0.0, stage2=0.0, stage3=0.0)
        self.cov_info_, self.rejected_ = [], []
        if N <= 0 or n_pos < 2:            # nothing to do / too few minority points to estimate anything
            self.diag_["too_few_minority"] = int(n_pos < 2)
            return X, y
        self.Xp_, self.y_ = Xp, y
        self.k_ = self._k(n, n_pos)
        self.nn_ = NearestNeighbors().fit(X)
        eta_all = self.posterior_train(X)
        b = binary_entropy(eta_all)
        self.b_, self.eta_all_ = b, eta_all
        # bandwidth of the minority KDE: median distance to the k_h-th minority neighbour
        kh = min(self.k_h, n_pos - 1)
        dpp = NearestNeighbors(n_neighbors=kh + 1).fit(Xp).kneighbors(Xp)[0][:, -1]
        self.h_ = max(float(np.median(dpp)), 1e-6) * self.h_mult
        # acceptance level: lower quartile of the minority posterior, capped at 1/2
        if self.theta_fixed is not None:
            self.theta_ = float(self.theta_fixed)
        else:
            self.theta_ = min(self.theta_cap, float(np.quantile(eta_all[y == 1], self.theta_q)))
        neg_idx = np.flatnonzero(y == 0)
        bn = b[neg_idx]
        if self.seed_mode == "sigma":
            cand = neg_idx[bn > bn.mean() + bn.std()]
            wts = np.ones(len(cand))
        else:
            cand = neg_idx[bn > 0]
            wts = b[cand] if self.seed_mode == "score" else np.ones(len(cand))
        if len(cand) == 0:            # perfectly separated data: start from minority points
            self.diag_["no_candidates"] = 1
            cand = np.flatnonzero(y == 1)
            wts = np.ones(len(cand))
        wts = wts / wts.sum()
        M = int(min(len(cand), max(10, N // 4)))
        seeds_idx = rng.choice(cand, size=M, replace=False, p=wts) if M < len(cand) else cand
        seed_w = b[seeds_idx] if self.alloc == "score" else np.ones(len(seeds_idx))
        if seed_w.sum() <= 0:
            seed_w = np.ones(len(seeds_idx))
        S = X[seeds_idx]
        self.seeds_idx_, self.seeds_ = seeds_idx, S
        self.n_seed_cand_ = len(cand)
        t1 = time.perf_counter(); self.timing_["stage1"] = t1 - t0
        A, steps = self._move(S, rng)
        self.anchors_, self.steps_ = A, steps
        self.diag_["chains"] = len(A)
        if self.movement == "langevin":
            self.diag_["chains_unfinished"] = int(np.sum(self.posterior(A) < self.theta_))
        t2 = time.perf_counter(); self.timing_["stage2"] = t2 - t1
        # local generator around every anchor: anchor + its k_gen nearest minority points
        kg = min(self.k_gen, n_pos)
        nbr = NearestNeighbors(n_neighbors=kg).fit(Xp).kneighbors(A, return_distance=False)
        comps = []
        for i in range(len(A)):
            L = np.vstack([A[i][None, :], Xp[nbr[i]]])
            comps.append((L.mean(0), self._cov(L)))
        p_alloc = seed_w / seed_w.sum()

        def draw(cnt):
            lab = rng.choice(len(comps), size=cnt, p=p_alloc)
            out = np.empty((cnt, X.shape[1]))
            for c in np.unique(lab):
                m = lab == c
                mu, C = comps[c]
                out[m] = rng.multivariate_normal(mu, C, size=m.sum(), check_valid="ignore", method="svd")
            return out

        n_cand = n_acc = 0
        if not self.filter:
            new = draw(N)
            n_cand = n_acc = N
        else:
            kept, pool, pool_s = [], [], []
            need = N
            for r in range(self.rounds):
                Z = draw(max(2 * need, 10))
                s = self.posterior(Z)
                ok = s >= self.theta_
                n_cand += len(Z); n_acc += int(ok.sum())
                kept.append(Z[ok][:need]); need -= len(kept[-1])
                pool.append(Z[~ok]); pool_s.append(s[~ok])
                self.diag_["rounds_used"] = r + 1
                if need <= 0:
                    break
            if self.record:
                self.rejected_ = np.vstack(pool) if pool else np.empty((0, X.shape[1]))
            if need > 0:               # fill with the most minority-like rejected candidates
                P = np.vstack(pool); Ps = np.concatenate(pool_s)
                kept.append(P[np.argsort(-Ps)[:need]])
                self.diag_["n_fill"] = int(need)
            new = np.vstack(kept)[:N]
        self.diag_["n_cand"], self.diag_["n_acc"] = int(n_cand), int(n_acc)
        self.new_ = new
        self.timing_["stage3"] = time.perf_counter() - t2
        out = (np.vstack([X, new]), np.concatenate([y, np.ones(len(new), int)]))
        if self.return_info:
            info = dict(seeds=S, anchors=A, steps=steps, new=new, b=b, k=self.k_,
                        h=self.h_, theta=self.theta_, n_cand=n_cand, n_acc=n_acc,
                        n_seed_cand=len(cand), n_seeds=len(S), N=N)
            return out + (info,)
        return out
