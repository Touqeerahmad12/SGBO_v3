"""
Statistical comparison of oversampling methods over independent data sources.

Experimental unit = independent data source.  Related tasks of one source (e.g. several
imbalance ratios of the same data) are averaged first, then repetitions and folds, and for the
pooled analysis also the four classifiers (``unit_matrix``).  Tests:

  friedman           Friedman chi-square and the Iman-Davenport F statistic, average ranks, Nemenyi
                     critical difference (studentized range, alpha = 0.05)
  posthoc            SGBO against every other method: Wilcoxon signed-rank test, Holm correction
                     over the comparisons, mean and median difference, cluster-bootstrap 95% CI over
                     units, matched-pairs rank-biserial correlation, wins / losses
  boot_ci            percentile bootstrap interval of a mean
  paired_summary     mean paired difference with bootstrap CI and win/loss counts (ablation tables)
"""
import numpy as np, pandas as pd
from scipy import stats
from scipy.stats import studentized_range

METHODS = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN",
           "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
METRICS = ["aucpr", "mcc", "f1", "gmean", "auc"]
CLFS = ["RF", "SVM", "kNN", "LR"]


def unit_matrix(df, metric, clf=None, methods=METHODS, datasets=None):
    d = df if clf is None else df[df.clf == clf]
    if datasets is not None:
        d = d[d.dataset.isin(datasets)]
    t = d.groupby(["source", "dataset", "clf", "method"])[metric].mean()      # over reps and folds
    t = t.groupby(["source", "clf", "method"]).mean()                          # over related tasks of a source
    t = t.groupby(["source", "method"]).mean().unstack("method")              # over classifiers
    return t[methods]


def friedman(M):
    R = M.rank(axis=1, ascending=False).values
    N, k = R.shape
    Rbar = R.mean(0)
    chi2 = 12 * N / (k * (k + 1)) * (np.sum(Rbar ** 2) - k * (k + 1) ** 2 / 4)
    FF = (N - 1) * chi2 / (N * (k - 1) - chi2)
    q = studentized_range.ppf(0.95, k, 1e6) / np.sqrt(2)
    return dict(N=N, k=k, ranks=dict(zip(M.columns, Rbar)), chi2=chi2, p_chi2=stats.chi2.sf(chi2, k - 1),
                FF=FF, p_FF=stats.f.sf(FF, k - 1, (k - 1) * (N - 1)),
                Fcrit=stats.f.ppf(0.95, k - 1, (k - 1) * (N - 1)), q05=q, cd=q * np.sqrt(k * (k + 1) / (6 * N)))


def boot_ci(d, B=10000, seed=0):
    rng = np.random.default_rng(seed)
    d = np.asarray(d, float)
    idx = rng.integers(0, len(d), size=(B, len(d)))
    m = d[idx].mean(1)
    return float(np.quantile(m, 0.025)), float(np.quantile(m, 0.975))


def posthoc(M, control="SGBO"):
    rows = []
    for m in M.columns:
        if m == control:
            continue
        d = (M[control] - M[m]).values
        nz = d[np.abs(d) > 1e-12]
        if len(nz) == 0:
            p, rrb = 1.0, 0.0
        else:
            p = float(stats.wilcoxon(M[control], M[m], zero_method="wilcox").pvalue)
            rk = stats.rankdata(np.abs(nz))
            Wp, Wm = rk[nz > 0].sum(), rk[nz < 0].sum()
            rrb = float((Wp - Wm) / (Wp + Wm))
        lo, hi = boot_ci(d)
        rows.append(dict(method=m, mean=float(d.mean()), median=float(np.median(d)), ci_lo=lo, ci_hi=hi,
                         wins=int((d > 1e-12).sum()), losses=int((d < -1e-12).sum()), p=p, r_rb=rrb))
    rows.sort(key=lambda r: r["p"])
    k = len(rows); prev = 0.0
    for i, r in enumerate(rows):
        adj = min(1.0, max(prev, (k - i) * r["p"])); r["p_holm"] = adj; prev = adj
        r["reject"] = adj < 0.05
    return {r["method"]: r for r in rows}


def paired_summary(M, ref, others=None, seed=0):
    """Mean paired difference (other - ref) over the units (rows of M), bootstrap CI, wins/losses of `other`, Wilcoxon p."""
    out = {}
    for v in (others or [c for c in M.columns if c != ref]):
        d = (M[v] - M[ref]).values
        lo, hi = boot_ci(d, seed=seed)
        nz = d[np.abs(d) > 1e-12]
        p = float(stats.wilcoxon(M[v], M[ref], zero_method="wilcox").pvalue) if len(nz) else 1.0
        out[v] = dict(mean=float(d.mean()), lo=lo, hi=hi, wins=int((d > 1e-12).sum()), losses=int((d < -1e-12).sum()), p=p)
    return out


def holm(pvals):
    """Holm step-down adjusted p-values (same order as input)."""
    p = np.asarray(pvals, float); order = np.argsort(p); adj = np.empty_like(p); prev = 0.0
    for i, j in enumerate(order):
        prev = max(prev, (len(p) - i) * p[j]); adj[j] = min(1.0, prev)
    return adj
