"""Named SGBO variants used by the ablation studies (each differs from the full method in one component)."""
from .sgbo import SGBO

ORDER = ["SGBO", "k = n+ (no adaptive k)", "uniform weights", "k = n+, uniform (BDO score)", "uniform seeds",
         "uniform allocation", "sigma-rule seeds, uniform alloc.", "no noise (tau=0)", "BDO movement", "no movement",
         "no shrinkage", "no acceptance test"]


def ablation_variants(record=False):
    r = lambda **kw: (lambda: SGBO(record=record, **kw))
    return {
        "SGBO": r(),
        "k = n+ (no adaptive k)": r(adaptive_k=False),
        "uniform weights": r(weighted=False),
        "k = n+, uniform (BDO score)": r(adaptive_k=False, weighted=False),
        "uniform seeds": r(seed_mode="uniform"),
        "uniform allocation": r(alloc="uniform"),
        "sigma-rule seeds, uniform alloc.": r(soft=False),
        "no noise (tau=0)": r(tau=0.0),
        "BDO movement": r(movement="bdo"),
        "no movement": r(movement="none"),
        "no shrinkage": r(shrink=False),
        "no acceptance test": r(filter=False),
    }
