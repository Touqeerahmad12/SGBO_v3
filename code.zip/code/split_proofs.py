"""Move the full proofs of c_method_full.tex to the supplement: c_method.tex keeps the statements and a proof outline;
supp_proofs.tex holds statement + full proof (labels from the main text are replaced by their numbers at assembly time)."""
import re, os
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "manuscript_v3", "parts")
src = open(os.path.join(P, "c_method_full.tex")).read()
OUT = {
 "thm:props": "Each item follows from the properties of $\\Hb$ listed in \\cref{sec:prelim} (zero only at $0$ and $1$, equal to $1$ only at $1/2$, symmetric, strictly monotone on $[1/2,1]$) and from $w_j>0$.",
 "thm:consistency": "A Hoeffding bound shows that $k_n=\\bar k_n$ with probability tending to one, so a deterministic $\\bar k_n\\to\\infty$ with $\\bar k_n/n\\to0$ may be assumed. The error then splits into a bias term, which vanishes because the neighbourhood shrinks and $\\eta$ is continuous, and a conditional variance term of order $e/(4\\bar k_n)$, because the weights are at most $e/\\bar k_n$ after normalisation. The BDO rule violates $k_n/n\\to0$.",
 "prop:meanshift": "Differentiate the kernel density estimate and divide by it; the exponential profile and the associated set give the BDO gradient.",
 "prop:segment": "The increment is the same at every step, which gives the segment by induction; expanding the square in the stopping test gives the threshold $s^\\star$.",
 "thm:ascent": "The profile $e^{-r/2h^2}$ is convex, so a first-order lower bound of the density at the new point yields the inequality; summation and boundedness give the remaining claims.",
 "thm:stationary": "The Jacobian of $m_h$ is a weighted covariance and is bounded, so the drift is globally Lipschitz; the stationary Fokker--Planck equation is verified directly for $\\hat p_+^{1/\\tau}$, which has a Gaussian tail.",
 "prop:shrink": "The eigenvalues of $\\Sigma_\\rho$ are at least $\\rho\\nu$ and at most $(1-\\rho)d\\nu+\\rho\\nu$, and the resulting bound decreases in $\\rho$.",
 "prop:termination": "Count the steps and the draws; the candidate pool is never smaller than the remaining need, and the fall-back fills the rest.",
}
pat = re.compile(r"(\\begin\{(theorem|proposition)\}(?:\[[^\]]*\])?\\label\{([^}]*)\}.*?\\end\{\2\})\s*\\begin\{proof\}(.*?)\\end\{proof\}", re.S)
supp = []
def rep(m):
    stmt, env, lab, proof = m.group(1), m.group(2), m.group(3), m.group(4)
    supp.append((lab, stmt, proof.strip()))
    return stmt + "\n\\begin{proof}[Proof outline]" + OUT[lab] + " The complete proof is in Supplement~\\ref{S:proofs}.\\end{proof}"
main = pat.sub(rep, src)
assert len(supp) == len(OUT), (len(supp), [s[0] for s in supp])
open(os.path.join(P, "c_method.tex"), "w").write(main)
open(os.path.join(P, "supp_proofs.tex"), "w").write("\n\n".join(f"%%LAB:{l}\n{s}\n\\begin{{proof}}{p}\\end{{proof}}" for l, s, p in supp))
print(len(src), "->", len(main))
