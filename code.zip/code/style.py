"""Shared figure style: Computer Modern text, muted palette, vector output."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["cmr10", "DejaVu Serif"],
    "mathtext.fontset": "cm",
    "axes.formatter.use_mathtext": True,
    "axes.unicode_minus": False,
    "font.size": 9,
    "axes.titlesize": 9.5,
    "axes.labelsize": 9,
    "legend.fontsize": 7.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "axes.linewidth": 0.7,
    "xtick.major.width": 0.6,
    "ytick.major.width": 0.6,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "axes.spines.top": True,
    "axes.spines.right": True,
    "savefig.bbox": "tight",
    "savefig.pad_inches": 0.02,
    "pdf.fonttype": 42,
    "figure.dpi": 150,
})

# method colours: neutral greys for classics, two accents for BDO and SGBO
COL = {
    "None": "#9e9e9e", "ROS": "#b8b8b8", "SMOTE": "#7f9fb8", "B-SMOTE": "#5f86a6",
    "ADASYN": "#9bb79a", "SVM-SMOTE": "#6f9a6e", "SMOTE-ENN": "#c2a878",
    "KM-SMOTE": "#8e7cc3", "MWMOTE": "#4a7c8c", "CCR": "#a0522d",
    "BDO": "#d08c3c", "SGBO": "#b2182b",
}
NEG, POS, NEW, ANC = "#8fb3d9", "#c0392b", "#7d3c98", "#1b1b1b"
METHODS = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "BDO", "SGBO"]
METHODS12 = ["None", "ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN",
             "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]
MLAB = {"gmean": "G-mean", "f1": "F1", "aucpr": "AUC-PR", "mcc": "MCC", "auc": "AUC"}
FIG = "../manuscript_v3/figures"


def save(fig, name, folder=None):
    import os
    folder = folder or FIG
    os.makedirs(folder, exist_ok=True)
    fig.savefig(f"{folder}/{name}.pdf")
    fig.savefig(f"{folder}/{name}.png", dpi=170)
    plt.close(fig)
