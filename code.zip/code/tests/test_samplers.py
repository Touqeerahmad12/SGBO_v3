"""Edge-case and invariance tests for SGBO, BDO and the baselines.
Run from code/:  python -m unittest discover -s tests -v"""
import _threads  # noqa: F401
import os, sys, unittest
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from sgbo import SGBO, BDO, make_sampler
from sgbo.common import knn_excl_self, binary_entropy
from sklearn.neighbors import NearestNeighbors

ALL = ["ROS", "SMOTE", "B-SMOTE", "ADASYN", "SVM-SMOTE", "SMOTE-ENN", "KM-SMOTE", "MWMOTE", "CCR", "BDO", "SGBO"]


def blobs(n_neg=300, n_pos=20, d=3, shift=1.2, seed=0):
    r = np.random.default_rng(seed)
    X = np.vstack([r.normal(0, 1, (n_neg, d)), r.normal(shift, 0.6, (n_pos, d))])
    y = np.r_[np.zeros(n_neg, int), np.ones(n_pos, int)]
    return X, y


class TestBalanceAndValidity(unittest.TestCase):
    def test_all_methods_return_valid_output(self):
        X, y = blobs()
        X0, y0 = X.copy(), y.copy()
        for name in ALL:
            Xr, yr = make_sampler(name).fit_resample(X, y, np.random.default_rng(1))[:2]
            self.assertTrue(np.isfinite(Xr).all(), name)
            self.assertTrue(set(np.unique(yr)) <= {0, 1}, name)
            self.assertEqual(Xr.shape[1], X.shape[1])
            self.assertEqual(len(Xr), len(yr))
            self.assertTrue(np.array_equal(X, X0) and np.array_equal(y, y0), f"{name} modified its input")
            if name not in ("SMOTE-ENN", "CCR"):            # cleaning methods change the size on purpose
                self.assertEqual((yr == 1).sum(), (yr == 0).sum(), name)

    def test_sgbo_bdo_exact_balance_and_original_rows_kept(self):
        X, y = blobs()
        for name in ("SGBO", "BDO"):
            Xr, yr = make_sampler(name).fit_resample(X, y, np.random.default_rng(2))[:2]
            self.assertEqual(len(yr), 2 * (y == 0).sum())
            self.assertTrue(np.array_equal(Xr[:len(X)], X))

    def test_determinism(self):
        X, y = blobs()
        for name in ("SGBO", "BDO", "SMOTE", "MWMOTE"):
            a = make_sampler(name).fit_resample(X, y, np.random.default_rng(5))[0]
            b = make_sampler(name).fit_resample(X, y, np.random.default_rng(5))[0]
            self.assertTrue(np.array_equal(a, b), name)

    def test_n_new(self):
        X, y = blobs()
        for name in ("SGBO", "BDO", "SMOTE", "ROS", "B-SMOTE", "ADASYN", "KM-SMOTE", "MWMOTE"):
            s = make_sampler(name); s.n_new = 57
            Xr, yr = s.fit_resample(X, y, np.random.default_rng(3))[:2]
            self.assertEqual((yr == 1).sum() - (y == 1).sum(), 57, name)


class TestSgboEdgeCases(unittest.TestCase):
    def test_too_few_minority_points(self):
        r = np.random.default_rng(0)
        for npos in (0, 1):
            X = r.normal(size=(50 + npos, 2)); y = np.r_[np.zeros(50, int), np.ones(npos, int)]
            for name in ("SGBO", "BDO"):
                Xr, yr = make_sampler(name).fit_resample(X, y, np.random.default_rng(0))[:2]
                self.assertEqual(len(yr), len(y), f"{name} npos={npos}")

    def test_two_minority_points_extreme_imbalance(self):
        r = np.random.default_rng(1)
        X = np.vstack([r.normal(size=(400, 4)), r.normal(2, 0.1, (2, 4))]); y = np.r_[np.zeros(400, int), [1, 1]]
        smp = SGBO(); Xr, yr = smp.fit_resample(X, y, np.random.default_rng(0))
        self.assertEqual((yr == 1).sum(), 400); self.assertTrue(np.isfinite(Xr).all())

    def test_already_balanced_or_minority_larger(self):
        X, y = blobs(n_neg=30, n_pos=30)
        Xr, yr = SGBO().fit_resample(X, y, np.random.default_rng(0))
        self.assertEqual(len(yr), 60)
        X, y = blobs(n_neg=20, n_pos=30)
        Xr, yr = SGBO().fit_resample(X, y, np.random.default_rng(0))
        self.assertEqual(len(yr), 50)

    def test_perfectly_separated_classes_no_candidates(self):
        r = np.random.default_rng(0)
        X = np.vstack([r.normal(0, 0.3, (200, 2)), r.normal(20, 0.3, (10, 2))]); y = np.r_[np.zeros(200, int), np.ones(10, int)]
        s = SGBO(); Xr, yr = s.fit_resample(X, y, np.random.default_rng(0))
        self.assertEqual(s.diag_["no_candidates"], 1)
        self.assertEqual((yr == 1).sum(), 200); self.assertTrue(np.isfinite(Xr).all())

    def test_identical_minority_points_zero_trace(self):
        r = np.random.default_rng(0)
        X = np.vstack([r.normal(size=(100, 3)), np.tile([9.0, 9.0, 9.0], (8, 1))]); y = np.r_[np.zeros(100, int), np.ones(8, int)]
        for kw in (dict(), dict(movement="none")):
            s = SGBO(**kw); Xr, yr = s.fit_resample(X, y, np.random.default_rng(0))
            self.assertTrue(np.isfinite(Xr).all(), kw); self.assertEqual((yr == 1).sum(), 100, kw)
            self.assertGreater(s.diag_["cov_zero_trace"], 0, kw)       # separated + identical minority -> h^2 I fallback

    def test_constant_feature_and_one_dimension(self):
        X, y = blobs(d=3)
        X[:, 1] = 0.0
        Xr, yr = SGBO().fit_resample(X, y, np.random.default_rng(0)); self.assertTrue(np.isfinite(Xr).all())
        X1, y1 = blobs(d=1)
        Xr, yr = SGBO().fit_resample(X1, y1, np.random.default_rng(0)); self.assertTrue(np.isfinite(Xr).all())
        self.assertEqual((yr == 1).sum(), (yr == 0).sum())

    def test_duplicates_everywhere(self):
        X, y = blobs(n_neg=100, n_pos=10)
        X = np.vstack([X, X[:50], X[-10:]]); y = np.r_[y, y[:50], y[-10:]]
        for name in ("SGBO", "BDO"):
            Xr, yr = make_sampler(name).fit_resample(X, y, np.random.default_rng(0))[:2]
            self.assertTrue(np.isfinite(Xr).all(), name)

    def test_unfinished_chains_are_reported_and_harmless(self):
        X, y = blobs()
        s = SGBO(T=1, eta=0.01); Xr, yr = s.fit_resample(X, y, np.random.default_rng(0))
        self.assertGreater(s.diag_["chains_unfinished"], 0)
        self.assertEqual((yr == 1).sum(), (yr == 0).sum()); self.assertTrue(np.isfinite(Xr).all())

    def test_impossible_acceptance_level_falls_back(self):
        X, y = blobs()
        s = SGBO(theta=1.01); Xr, yr = s.fit_resample(X, y, np.random.default_rng(0))
        N = (y == 0).sum() - (y == 1).sum()
        self.assertEqual(s.diag_["n_fill"], N); self.assertEqual(s.diag_["n_acc"], 0)
        self.assertEqual(s.diag_["rounds_used"], 5); self.assertEqual(len(s.new_), N)

    def test_degenerate_tiny_bandwidth_and_huge_step(self):
        X, y = blobs()
        for kw in (dict(h_mult=1e-3), dict(h_mult=1e3), dict(eta=1.99, tau=2.0), dict(tau=0.0, T=200)):
            Xr, yr = SGBO(**kw).fit_resample(X, y, np.random.default_rng(0))
            self.assertTrue(np.isfinite(Xr).all(), kw); self.assertEqual((yr == 1).sum(), (yr == 0).sum(), kw)

    def test_switches_equivalences(self):
        X, y = blobs()
        a = SGBO(soft=False).fit_resample(X, y, np.random.default_rng(4))[0]
        b = SGBO(seed_mode="sigma", alloc="uniform").fit_resample(X, y, np.random.default_rng(4))[0]
        self.assertTrue(np.array_equal(a, b))
        a = SGBO(shrink=True, rho_min=0.01).fit_resample(X, y, np.random.default_rng(4))[0]
        b = SGBO().fit_resample(X, y, np.random.default_rng(4))[0]
        self.assertTrue(np.array_equal(a, b))

    def test_every_switch_runs(self):
        X, y = blobs()
        for kw in (dict(adaptive_k=False), dict(weighted=False), dict(seed_mode="uniform"), dict(alloc="uniform"),
                   dict(movement="bdo"), dict(movement="none"), dict(tau=0.0), dict(shrink=False), dict(filter=False),
                   dict(rho_fixed=0.5), dict(k_fixed=7), dict(theta_q=0.5), dict(rounds=1), dict(k_gen=2), dict(record=True)):
            Xr, yr = SGBO(**kw).fit_resample(X, y, np.random.default_rng(0))
            self.assertTrue(np.isfinite(Xr).all(), kw); self.assertEqual((yr == 1).sum(), (yr == 0).sum(), kw)


class TestHelpers(unittest.TestCase):
    def test_knn_excl_self_with_duplicates(self):
        r = np.random.default_rng(0)
        X = r.normal(size=(40, 2)); X = np.vstack([X, X[:15], X[:15]])          # several exact triplicates
        nn = NearestNeighbors().fit(X)
        d, idx = knn_excl_self(nn, X, 5, np.arange(len(X)))
        self.assertFalse((idx == np.arange(len(X))[:, None]).any())
        self.assertEqual(idx.shape, (len(X), 5))
        self.assertTrue(np.all(d[:15, 0] == 0))                                 # a duplicate is a legitimate neighbour
        # subset queries
        q = np.array([3, 7, 50])
        d2, idx2 = knn_excl_self(nn, X[q], 4, q)
        self.assertFalse((idx2 == q[:, None]).any())

    def test_binary_entropy(self):
        p = np.array([0, 1, .5, .25, .75]); h = binary_entropy(p)
        np.testing.assert_allclose(h, [0, 0, 1, 0.8112781244591328, 0.8112781244591328])


if __name__ == "__main__":
    unittest.main()
