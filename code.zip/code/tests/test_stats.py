"""Unit tests of the statistics module against scipy / closed forms."""
import _threads  # noqa: F401
import os, sys, unittest
import numpy as np, pandas as pd
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from scipy import stats
from sgbo.stats import friedman, posthoc, boot_ci, holm


class TestStats(unittest.TestCase):
    def setUp(self):
        r = np.random.default_rng(0)
        self.M = pd.DataFrame(r.normal(size=(20, 5)) + np.arange(5) * 0.3, columns=list("ABCDE"))

    def test_friedman_matches_scipy(self):
        fr = friedman(self.M)
        chi2, p = stats.friedmanchisquare(*[(-self.M[c]).values for c in self.M.columns])
        self.assertAlmostEqual(fr["chi2"], chi2, places=8); self.assertAlmostEqual(fr["p_chi2"], p, places=10)
        # ranks: rank 1 = largest value
        R = self.M.rank(axis=1, ascending=False).mean()
        for c in self.M.columns:
            self.assertAlmostEqual(fr["ranks"][c], R[c])
        # Iman-Davenport statistic from the closed form
        N, k = fr["N"], fr["k"]
        self.assertAlmostEqual(fr["FF"], (N - 1) * fr["chi2"] / (N * (k - 1) - fr["chi2"]))

    def test_nemenyi_critical_difference(self):
        # classical table value q_0.05 for k = 5 (Demsar 2006) is 2.728
        fr = friedman(self.M)
        self.assertAlmostEqual(fr["q05"], 2.728, delta=0.002)
        self.assertAlmostEqual(fr["cd"], 2.728 * np.sqrt(5 * 6 / (6 * 20)), delta=0.005)

    def test_holm_matches_statsmodels_definition(self):
        p = np.array([0.01, 0.04, 0.03, 0.005])
        a = holm(p)
        np.testing.assert_allclose(a, [0.03, 0.06, 0.06, 0.02])

    def test_posthoc_wilcoxon_and_holm(self):
        ph = posthoc(self.M, control="E")
        for m, r in ph.items():
            self.assertAlmostEqual(r["p"], stats.wilcoxon(self.M["E"], self.M[m]).pvalue, places=10)
            self.assertGreaterEqual(r["p_holm"], r["p"] - 1e-15)
            self.assertTrue(-1 <= r["r_rb"] <= 1)
        # Holm adjusted values are non-decreasing in p
        ps = sorted(ph.values(), key=lambda r: r["p"])
        self.assertTrue(all(a["p_holm"] <= b["p_holm"] + 1e-15 for a, b in zip(ps, ps[1:])))

    def test_bootstrap_interval_covers_mean(self):
        d = np.random.default_rng(1).normal(0.5, 1, 40)
        lo, hi = boot_ci(d, B=4000)
        self.assertLess(lo, d.mean()); self.assertGreater(hi, d.mean())


if __name__ == "__main__":
    unittest.main()
