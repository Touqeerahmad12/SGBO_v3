"""
Numerical verification of the mathematical statements of the paper (Theorems 1, 3, 4,
Propositions 1-4 and Examples 1-3).  Theorem 2 (consistency) is checked in run_components.py.

    python verify_theory.py          # -> results/theory_checks.json
Every check draws random instances and reports the number of instances and the worst case.
"""
import _threads  # noqa: F401
import os, sys, json, time
import numpy as np
from scipy.spatial.distance import cdist
from scipy import stats
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from sgbo import SGBO
from sgbo.common import binary_entropy

RES = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
rng = np.random.default_rng(2024)
OUT = {}


def kde(x, P, h):
    d = P.shape[1]
    return np.mean(np.exp(-np.sum((x - P) ** 2, 1) / (2 * h * h))) * (2 * np.pi * h * h) ** (-d / 2)


def mean_shift(x, P, h):
    lw = -np.sum((x - P) ** 2, 1) / (2 * h * h); w = np.exp(lw - lw.max()); w /= w.sum()
    return w @ P


# ---- Theorem 1 ---------------------------------------------------------------------------
def thm1(n=20000):
    worst = dict(range=0.0, zero=0, one=0, mono=0, bdo=0.0); bad = 0
    for _ in range(n):
        k = int(rng.integers(1, 40)); d = np.sort(rng.exponential(1, k)) + 1e-9
        lab = rng.integers(0, 2, k)
        if rng.random() < 0.15: lab[:] = lab[0]
        w = np.exp(-(d / d[-1]) ** 2); eta = (w * lab).sum() / w.sum(); b = float(binary_entropy(np.array([eta]))[0])
        if not (0 <= b <= 1 + 1e-12): bad += 1
        if (b == 0) != bool(np.all(lab == lab[0])): bad += 1
        eta_u = lab.mean(); b_u = float(binary_entropy(np.array([eta_u]))[0])         # uniform weights = BDO degree
        worst["bdo"] = max(worst["bdo"], abs(b_u - float(binary_entropy(np.array([lab.sum() / k]))[0])))
    # (iv) strict monotonicity in |eta-1/2|
    g = np.linspace(0, 1, 100001); h = binary_entropy(g)
    ok_mono = bool(np.all(np.diff(h[:50001]) > 0) and np.all(np.diff(h[50000:]) < 0))
    OUT["thm1"] = dict(instances=n, violations=bad, monotone_in_abs_dev=ok_mono, h2_at_half=float(binary_entropy(np.array([.5]))[0]))


# ---- Proposition 1 -----------------------------------------------------------------------
def prop1(n=3000):
    worst = 0.0
    for _ in range(n):
        d = int(rng.choice([1, 2, 5, 20])); m = int(rng.integers(2, 30)); h = float(rng.uniform(0.2, 2))
        P = rng.normal(size=(m, d)); x = rng.normal(size=d) * 1.5
        g = (mean_shift(x, P, h) - x) / h ** 2
        eps = 1e-5; fd = np.zeros(d)
        # log-density via log-sum-exp for numerical safety
        def logp(z):
            lw = -np.sum((z - P) ** 2, 1) / (2 * h * h); mx = lw.max(); return mx + np.log(np.exp(lw - mx).mean())
        for j in range(d):
            e = np.zeros(d); e[j] = eps; fd[j] = (logp(x + e) - logp(x - e)) / (2 * eps)
        worst = max(worst, np.max(np.abs(fd - g)) / max(1.0, np.max(np.abs(g))))
    # BDO gradient is the same map with profile exp(-r)
    xs = np.array([0.0, 0.0]); Pi = np.array([[1.0, 0.0], [1.0, 1.0]]); dd = np.linalg.norm(Pi - xs, axis=1)
    w = np.exp(-dd); w /= w.sum(); g = (w[:, None] * (Pi - xs)).sum(0)
    OUT["prop1"] = dict(instances=n, max_rel_error_vs_finite_difference=float(worst), example2_g=g.tolist())


# ---- Proposition 2 (BDO segment and stopping time) ----------------------------------------
def prop2(n=4000, alpha=1e-3, tmax=1000):
    worst_t = 0; mism = 0; n_eff = 0; worst_seg = 0.0; ties = 0
    for _ in range(n):
        d = int(rng.choice([2, 3, 6])); m = int(rng.integers(1, 6))
        x0 = rng.normal(size=d); Pi = x0 + rng.normal(size=(m, d)) * rng.uniform(0.3, 1.5) + rng.normal(size=d) * 0.5
        dij = np.linalg.norm(x0 - Pi, axis=1); w = np.exp(-(dij - dij.min())); w /= w.sum(); g = (w[:, None] * (Pi - x0)).sum(0)
        xt = x0.copy(); t = 0
        while t < tmax:
            if np.all(np.linalg.norm(xt - Pi, axis=1) < np.linalg.norm(xt - x0)): break
            xt = xt + alpha * g; t += 1
        ip = (Pi - x0) @ g
        if np.all(ip > 0):
            sstar = np.max(np.sum((x0 - Pi) ** 2, 1) / (2 * ip)); tpred = min(tmax, int(np.floor(sstar / alpha)) + 1)
        else:
            tpred = tmax
        # exact ties s*/alpha = integer (always the case for a single associated point, s* = 1/2) are decided
        # by floating-point rounding; they are counted separately
        tie = np.all(ip > 0) and abs(sstar / alpha - round(sstar / alpha)) < 1e-6
        if t != tpred:
            if tie: ties += 1
            else: mism += 1
        n_eff += 1
        # aided point on the segment [x0, x0+g]
        s = (xt - x0) @ g / max(g @ g, 1e-300); worst_seg = max(worst_seg, np.linalg.norm(xt - (x0 + s * g)))
    OUT["prop2"] = dict(instances=n_eff, stopping_time_mismatches=mism, mismatches_at_exact_ties=ties, max_distance_to_segment=float(worst_seg))


# ---- Theorem 3 (monotone ascent) ----------------------------------------------------------
def thm3(n=20000):
    worst_gap = np.inf; viol = 0; chain_viol = 0; chains = 0; cnt_bound = 0
    for _ in range(n):
        d = int(rng.choice([1, 2, 5, 10])); m = int(rng.integers(2, 25)); h = float(rng.uniform(0.3, 2)); eta = float(rng.uniform(0.02, 1.98))
        P = rng.normal(size=(m, d)) * rng.uniform(0.5, 2); x = rng.normal(size=d) * 2
        p0 = kde(x, P, h); ms = mean_shift(x, P, h); x1 = x + eta * (ms - x)
        lhs = kde(x1, P, h) - p0; rhs = eta * (2 - eta) / (2 * h * h) * p0 * np.sum((ms - x) ** 2)
        gap = lhs - rhs; worst_gap = min(worst_gap, gap / max(p0, 1e-300))
        if gap < -1e-12 * max(p0, 1e-300) - 1e-300: viol += 1
        if rng.random() < 0.05:                                    # whole chain
            chains += 1; z = x.copy(); prev = p0; ssum = 0.0
            for _t in range(60):
                m_ = mean_shift(z, P, h); nz = z + eta * (m_ - z); pz = kde(nz, P, h)
                ssum += eta * (2 - eta) / (2 * h * h) * kde(z, P, h) * np.sum((m_ - z) ** 2)
                if pz < prev * (1 - 1e-12): chain_viol += 1
                prev, z = pz, nz
            if ssum <= (2 * np.pi * h * h) ** (-d / 2) - p0 + 1e-12: cnt_bound += 1
    OUT["thm3"] = dict(instances=n, inequality_violations=viol, min_relative_slack=float(worst_gap), chains=chains,
                       chain_monotonicity_violations=chain_viol, chains_satisfying_summability_bound=cnt_bound)


# ---- Theorem 4 (invariant law, continuous-time statement; discretisation bias) ------------
def thm4(M=40000):
    P = np.array([[-1.0], [0.2], [1.6]]); h = 0.45; res = {}
    grid = np.linspace(-6, 6, 24001)
    for tau in (0.25, 1.0):
        dens = np.array([kde(np.array([g]), P, h) for g in grid]) ** (1 / tau)
        cdf = np.cumsum(dens); cdf /= cdf[-1]
        for eta in (0.5, 0.1, 0.02):
            gam = eta * h * h; steps = int(40 / gam) if eta < 0.3 else int(max(400, 40 / gam))
            steps = min(steps, 4000)
            x = rng.normal(0, 1.5, size=(M, 1))
            ms = lambda Z: (np.exp(-(Z - P.T) ** 2 / (2 * h * h)) @ P) / np.exp(-(Z - P.T) ** 2 / (2 * h * h)).sum(1, keepdims=True)
            sd = h * np.sqrt(2 * eta * tau)
            for _ in range(steps):
                x = x + eta * (ms(x) - x) + sd * rng.standard_normal(x.shape)
            xs = np.sort(x[:, 0]); ecdf = np.arange(1, M + 1) / M
            F = np.interp(xs, grid, cdf)
            res[f"tau={tau},eta={eta}"] = dict(ks=float(np.max(np.abs(F - ecdf))), steps=steps, ks_crit_5pct=float(1.358 / np.sqrt(M)))
    OUT["thm4"] = res


# ---- Proposition 3 (conditioning) ---------------------------------------------------------
def prop3(n=6000):
    worst_ratio = 0.0; viol = 0; sing = 0; total = 0; notpd = 0
    for _ in range(n):
        d = int(rng.choice([2, 5, 10, 30, 100])); m = int(rng.integers(2, 8))
        Xp = rng.normal(size=(40, d)); s = SGBO(); s.record = True; s.h_ = 0.5; s.cov_info_ = []
        s.diag_ = dict(cov_single=0, cov_zero_trace=0, rho_clipped=0)
        L = Xp[:m] * rng.choice([1e-6, 1e-2, 1, 1e3]) + rng.normal(size=d) * 3
        if rng.random() < 0.1: L = np.tile(L[0], (m, 1))
        C = s._cov(L); ev = np.linalg.eigvalsh(C); total += 1
        if ev[0] <= 0: notpd += 1
        info = s.cov_info_[-1]
        bound = 1 + (1 - s.rho_min) * d / s.rho_min
        if info["kind"] == "lw":
            if info["cond"] > bound * (1 + 1e-9): viol += 1
            worst_ratio = max(worst_ratio, info["cond"] / bound)
        S = np.cov(L, rowvar=False, bias=True)
        if len(L) <= d and np.linalg.matrix_rank(S) < d: sing += 1
    # Example 3
    Lx = np.array([[0.2, 1.0, -0.4, 0.6], [0.8, 0.6, 0, 0.9], [0.5, 1.4, -0.2, 0.3]])
    S = np.cov(Lx, rowvar=False, bias=True); nu = np.trace(S) / 4
    Sr = 0.7 * S + 0.3 * nu * np.eye(4)
    from sklearn.covariance import ledoit_wolf
    OUT["prop3"] = dict(instances=total, not_positive_definite=notpd, bound_violations=viol, max_cond_over_bound=float(worst_ratio),
                        sample_cov_singular_when_m_le_d=sing,
                        example3=dict(eig_S=np.sort(np.linalg.eigvalsh(S))[::-1].round(3).tolist(), nu=float(nu),
                                      eig_shrunk=np.sort(np.linalg.eigvalsh(Sr))[::-1].round(3).tolist(),
                                      cond=float(np.linalg.cond(Sr)), bound=1 + 0.7 * 4 / 0.3, rho_lw=float(ledoit_wolf(Lx)[1])))


# ---- Proposition 4 (termination and balance) ----------------------------------------------
def prop4(n=400):
    bad = 0; fills = 0; kinds = 0
    for i in range(n):
        d = int(rng.choice([1, 2, 5, 20])); npos = int(rng.integers(2, 25)); nneg = int(npos + rng.integers(1, 300))
        sep = rng.choice([0.0, 0.5, 3.0, 30.0]); X = np.vstack([rng.normal(size=(nneg, d)), rng.normal(sep, rng.choice([0.0, 0.3, 1.0]), (npos, d))])
        y = np.r_[np.zeros(nneg, int), np.ones(npos, int)]
        kw = rng.choice([0, 1, 2])
        s = SGBO(theta=1.5) if kw == 1 else (SGBO(T=1) if kw == 2 else SGBO())
        Xr, yr = s.fit_resample(X, y, np.random.default_rng(i))
        ok = (len(yr) == 2 * nneg) and np.isfinite(Xr).all() and (yr == 1).sum() == nneg
        bad += int(not ok); fills += int(s.diag_["n_fill"] > 0)
    OUT["prop4"] = dict(instances=n, violations=bad, instances_using_fallback=fills)


# ---- Examples -----------------------------------------------------------------------------
def examples():
    d = np.array([1, 1.2, 1.5, 2, 2.5]); lab = np.array([1, 0, 1, 0, 0]); w = np.exp(-(d / d[-1]) ** 2)
    eta = (w * lab).sum() / w.sum(); b = float(binary_entropy(np.array([eta]))[0])
    eta_u = lab.mean(); bu = float(binary_entropy(np.array([eta_u]))[0])
    ex1 = dict(w=w.round(3).tolist(), sum_w=float(w.sum()), pos_mass=float((w * lab).sum()), eta=float(eta), b=b, eta_uniform=float(eta_u), b_uniform=bu)
    # Example 2
    x0 = np.zeros(2); Pi = np.array([[1.0, 0.0], [1.0, 1.0]]); dij = np.linalg.norm(Pi, axis=1)
    ww = np.exp(-dij); ww /= ww.sum(); g = (ww[:, None] * Pi).sum(0)
    ip = Pi @ g; sstar = np.max(np.sum(Pi ** 2, 1) / (2 * ip)); tstar = int(np.floor(sstar / 1e-3)) + 1
    xa = x0 + 1e-3 * tstar * g
    h, eta2 = 0.5, 0.5; z = x0.copy(); its = [z.copy()]; dens = [kde(z, Pi, h)]
    for _ in range(3):
        z = z + eta2 * (mean_shift(z, Pi, h) - z); its.append(z.copy()); dens.append(kde(z, Pi, h))
    ex2 = dict(g=g.round(3).tolist(), sstar=float(sstar), tstar=tstar, aided=xa.round(3).tolist(), iterates=np.array(its).round(3).tolist(), density=np.round(dens, 3).tolist())
    OUT["examples"] = dict(ex1=ex1, ex2=ex2)


if __name__ == "__main__":
    for f in (thm1, prop1, prop2, thm3, prop3, prop4, examples, thm4):
        t0 = time.time(); f(); print(f.__name__, "done", round(time.time() - t0, 1), "s", flush=True)
    json.dump(OUT, open(os.path.join(RES, "theory_checks.json"), "w"), indent=1, default=float)
    print(json.dumps(OUT, indent=1, default=float))
